import cv2

def find_camera():
    for i in range(10):  # Check indices 0 to 9
        cap = cv2.VideoCapture(i)
        if cap.isOpened():
            print(f"Camera found at index {i}")
            cap.release()
        else:
            print(f"No camera found at index {i}")

find_camera()