import cv2
import numpy as np
from ultralytics import YOLO
from flask import Flask, Response, jsonify
from flask_cors import CORS
import threading
import time

model = YOLO(r'C:\Users\ioliv\Desktop\Fontys\Sem3.2\Group Project\fontys-s3-group4-iodigital\best.pt')


app = Flask(__name__)

# Enable CORS for all routes
CORS(app)

# Use the default webcam (index 0)
VIDEO_SOURCE = 1

# Shared data for averaging
person_counts = []
average_person_count = 0
lock = threading.Lock()

def calculate_average():
    global average_person_count
    while True:
        time.sleep(10)  # Calculate every 10 seconds
        with lock:
            if person_counts:
                average_person_count = sum(person_counts) / len(person_counts)
                person_counts.clear()
            else:
                average_person_count = 0

# Start the averaging thread
threading.Thread(target=calculate_average, daemon=True).start()

def generate_frames():
    global average_person_count
    cap = cv2.VideoCapture(VIDEO_SOURCE)
    
    while cap.isOpened():
        success, frame = cap.read()
        if not success:
            break

        results = model(frame)

        person_count = 0
        
        for result in results:
            for box in result.boxes:
                label = box.cls.item()
                
                if label == 0:  # Assuming '0' is the label for person
                    person_count += 1
                    
                    x1, y1, x2, y2 = box.xyxy[0].cpu().numpy().astype(int)
                    # Draw a bounding box and label for each detected person
                    cv2.putText(frame, 'Person detected', (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 0, 255), 2)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)

        # Add indicators for "Person Detected", "Person Count", and "Average Count" at the top left
        detection_status = "Yes" if person_count > 0 else "No"
        cv2.putText(frame, f'Person Detected: {detection_status}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        cv2.putText(frame, f'Person Count: {person_count}', (10, 70), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (0, 255, 0), 2)
        cv2.putText(frame, f'10-sec Average: {average_person_count:.2f}', (10, 110), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 0, 0), 2)

        # Update shared person count list
        with lock:
            person_counts.append(person_count)

        # Encode the frame to JPEG for streaming
        ret, buffer = cv2.imencode('.jpg', frame)
        frame = buffer.tobytes()

        yield (b'--frame\r\n'
            b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap.release()

@app.route('/video_feed')
def video_feed():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/api/detection', methods=['GET'])
def get_detection():
    cap = cv2.VideoCapture(VIDEO_SOURCE)
    ret, frame = cap.read()
    detection_data = {'person_detected': False, 'person_count': 0}

    if ret:
        results = model(frame)
        
        person_count = 0
        for result in results:
            for box in result.boxes:
                label = box.cls.item()
                
                if label == 0:  # Assuming '0' is the label for person
                    detection_data['person_detected'] = True
                    person_count += 1

        detection_data['person_count'] = person_count

    cap.release()
    return jsonify(detection_data)

@app.route('/api/average_presence', methods=['GET'])
def get_average_presence():
    global average_person_count
    return jsonify({'average_person_count': average_person_count})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
