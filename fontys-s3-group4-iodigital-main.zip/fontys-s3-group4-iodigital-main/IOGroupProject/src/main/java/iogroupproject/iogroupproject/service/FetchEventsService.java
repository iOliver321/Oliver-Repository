package iogroupproject.iogroupproject.service;

import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;

@Service
public class FetchEventsService {

    private final TokenService tokenService;

    public FetchEventsService(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    public List<Map<String, Object>> getCalendarEvents() {
        String accessToken = tokenService.getAccessToken();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<String> response = restTemplate.exchange(
                "https://graph.microsoft.com/v1.0/users/Testruimte4.eindhoven@iodigital.com/calendar/events",
                HttpMethod.GET,
                entity,
                String.class
        );

        try {
            // Parse the response body
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode root = objectMapper.readTree(response.getBody());
            JsonNode values = root.get("value");

            List<Map<String, Object>> calendarEvents = new ArrayList<>();

            if (values.isArray()) {
                for (JsonNode event : values) {
                    Map<String, Object> eventData = new HashMap<>();

                    // Extracting relevant event details
                    eventData.put("organizerName", event.get("organizer").get("emailAddress").get("name").asText());
                    eventData.put("organizerEmail", event.get("organizer").get("emailAddress").get("address"));
                    eventData.put("start", event.get("start").get("dateTime").asText());
                    eventData.put("end", event.get("end").get("dateTime").asText());
                    eventData.put("id", event.get("id").asText());

                    calendarEvents.add(eventData);
                }
            }

            return calendarEvents;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Failed to fetch calendar events", e);
        }
    }
}
