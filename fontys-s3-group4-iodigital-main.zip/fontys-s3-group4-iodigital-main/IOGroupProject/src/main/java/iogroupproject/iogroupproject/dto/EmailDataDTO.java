package iogroupproject.iogroupproject.dto;

import lombok.Data;

import java.util.Date;

@Data
public class EmailDataDTO {
    private String recipient;
    private String subject;
    private String roomName;
    private int maxCapacity;
    private int currentOccupants;
    private Date sentDateTime;
}
