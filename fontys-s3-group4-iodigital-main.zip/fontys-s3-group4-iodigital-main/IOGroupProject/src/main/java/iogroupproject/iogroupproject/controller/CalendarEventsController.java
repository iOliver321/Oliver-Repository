package iogroupproject.iogroupproject.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import iogroupproject.iogroupproject.service.FetchEventsService;
import iogroupproject.iogroupproject.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class CalendarEventsController {

    private final FetchEventsService fetchEventsService;

    public CalendarEventsController(FetchEventsService fetchEventsService) {
        this.fetchEventsService = fetchEventsService;
    }

    @GetMapping("/calendar/events")
    public ResponseEntity<List<Map<String, Object>>> getCalendarEvents() {
        try {
            List<Map<String, Object>> calendarEvents = fetchEventsService.getCalendarEvents();
            return ResponseEntity.ok(calendarEvents);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).build();
        }
    }
}