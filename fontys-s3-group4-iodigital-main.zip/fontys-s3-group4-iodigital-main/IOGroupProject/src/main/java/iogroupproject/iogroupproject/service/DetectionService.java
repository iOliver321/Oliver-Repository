package iogroupproject.iogroupproject.service;

import iogroupproject.iogroupproject.dto.DetectionDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class DetectionService {

    private final RestTemplate restTemplate;

    public Optional<DetectionDTO> getLiveDetection() {
        String pythonApiUrl = "http://localhost:5001/api/average_presence";

        try {
            ResponseEntity<DetectionDTO> response = restTemplate.getForEntity(pythonApiUrl, DetectionDTO.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                return Optional.ofNullable(response.getBody());
            } else {
                System.err.println("Non-success status code: " + response.getStatusCode());
                return Optional.empty();
            }
        } catch (Exception e) {
            System.err.println("Error fetching detection data: " + e.getMessage());
            return Optional.empty();
        }
    }
}