package iogroupproject.iogroupproject.util;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Base64;
import java.util.Map;

public class JwtUtils {

    public static boolean isTokenExpired(String token) {
        try {
            String[] parts = token.split("\\.");
            if (parts.length < 3) {
                throw new IllegalArgumentException("Invalid JWT token");
            }

            String payload = new String(Base64.getDecoder().decode(parts[1]));

            ObjectMapper objectMapper = new ObjectMapper();
            Map<String, Object> payloadMap = objectMapper.readValue(payload, Map.class);

            Long exp = ((Number) payloadMap.get("exp")).longValue();

            long currentTimeInSeconds = System.currentTimeMillis() / 1000;

            return currentTimeInSeconds > exp;
        } catch (Exception e) {
            throw new RuntimeException("Failed to parse JWT token", e);
        }
    }
}