package iogroupproject.iogroupproject.service;

import iogroupproject.iogroupproject.util.JwtUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.*;
import java.util.HashMap;
import java.util.Map;

@Service
public class TokenService {

    @Value("${microsoft.client-id}")
    private String clientId;

    @Value("${microsoft.client-secret}")
    private String clientSecret;

    @Value("${microsoft.tenant-id}")
    private String tenantId;

    @Value("${microsoft.token-url}")
    private String tokenUrl;

    @Value("${microsoft.scope}")
    private String scope;

    private String accessToken;

    public String getAccessToken() {
        if (accessToken == null || JwtUtils.isTokenExpired(accessToken)) {
            fetchNewAccessToken();
        }
        return accessToken;
    }

    private void fetchNewAccessToken() {
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_FORM_URLENCODED);

        LinkedMultiValueMap<String, String> body = new LinkedMultiValueMap<>();
        body.add("grant_type", "client_credentials");
        body.add("client_id", clientId);
        body.add("client_secret", clientSecret);
        body.add("scope", scope);

        HttpEntity<LinkedMultiValueMap<String, String>> entity = new HttpEntity<>(body, headers);

        ResponseEntity<Map> response = restTemplate.exchange(
                tokenUrl,
                HttpMethod.POST,
                entity,
                Map.class
        );

        if (response.getStatusCode() == HttpStatus.OK) {
            Map<String, Object> responseBody = response.getBody();
            if (responseBody != null) {
                accessToken = (String) responseBody.get("access_token");
            }
        } else {
            throw new RuntimeException("Failed to fetch access token: " + response.getStatusCode());
        }
    }
}