package iogroupproject.iogroupproject.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import iogroupproject.iogroupproject.service.EmailService;
import iogroupproject.iogroupproject.service.TokenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@CrossOrigin("*")
public class RoomsController {

    @Autowired
    private TokenService tokenService;

    @Autowired
    private EmailService emailService;

    private List<Map<String, Object>> getRoomEvents(String roomEmail, String accessToken) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);
        RestTemplate restTemplate = new RestTemplate();

        String url = "https://graph.microsoft.com/v1.0/users/" + roomEmail + "/calendar/events";

        try {
            ResponseEntity<String> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode root = objectMapper.readTree(response.getBody());
            JsonNode values = root.get("value");

            List<Map<String, Object>> events = new ArrayList<>();

            if (values != null && values.isArray()) {
                for (JsonNode event : values) {
                    Map<String, Object> eventData = new HashMap<>();

                    eventData.put("start", event.get("start").get("dateTime").asText());
                    eventData.put("end", event.get("end").get("dateTime").asText());
                    eventData.put("organizer", event.get("organizer").get("emailAddress").get("name").asText());



                    events.add(eventData);
                }
            }

            return events;
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    @GetMapping("/rooms")
    public ResponseEntity<List<Map<String, Object>>> getEindhovenRooms() {
        String accessToken = tokenService.getAccessToken();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();

        ResponseEntity<String> response = restTemplate.exchange(
                "https://graph.microsoft.com/v1.0/places/microsoft.graph.room",
                HttpMethod.GET,
                entity,
                String.class
        );

        try {
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode root = objectMapper.readTree(response.getBody());
            JsonNode values = root.get("value");

            List<Map<String, Object>> eindhovenRooms = new ArrayList<>();

            if (values.isArray()) {
                for (JsonNode room : values) {
                    String nickname = room.get("nickname").asText();
                    if (nickname.contains("Campus Eindhoven")) {
                        Map<String, Object> roomData = new HashMap<>();

                        String[] parts = nickname.split(" - ");
                        int floorNumber = parts.length > 1 ? Integer.parseInt(parts[1]) : -1;
                        String roomName = parts.length > 2 ? parts[2] : nickname;

                        roomData.put("nickname", roomName);
                        roomData.put("floorNumber", floorNumber);
                        roomData.put("capacity", room.get("capacity").isNull() ? null : room.get("capacity").asInt());
                        String roomEmail = room.get("emailAddress").asText();
                        roomData.put("emailAddress", roomEmail);

                        // Fetch events for this room
                        List<Map<String, Object>> events = getRoomEvents(roomEmail, accessToken);
                        roomData.put("events", events);

                        eindhovenRooms.add(roomData);
                    }
                }
            }

            return ResponseEntity.ok(eindhovenRooms);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/rooms/{placeId}")
    public ResponseEntity<Map<String, Object>> getRoomById(@PathVariable String placeId) {
        String accessToken = tokenService.getAccessToken();

        HttpHeaders headers = new HttpHeaders();
        headers.set("Authorization", "Bearer " + accessToken);

        HttpEntity<String> entity = new HttpEntity<>(headers);

        RestTemplate restTemplate = new RestTemplate();

        try {
            String url = "https://graph.microsoft.com/v1.0/places/" + placeId + "/microsoft.graph.room";

            ResponseEntity<String> response = restTemplate.exchange(
                    url,
                    HttpMethod.GET,
                    entity,
                    String.class
            );

            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode roomNode = objectMapper.readTree(response.getBody());

            Map<String, Object> roomData = new HashMap<>();
            String nickname = roomNode.get("nickname").asText();
            String[] parts = nickname.split(" - ");
            int floorNumber = parts.length > 1 ? Integer.parseInt(parts[1]) : -1;
            String roomName = parts.length > 2 ? parts[2] : nickname;

            roomData.put("nickname", roomName);
            roomData.put("floorNumber", floorNumber);
            roomData.put("capacity", roomNode.get("capacity").isNull() ? null : roomNode.get("capacity").asInt());
            String roomEmail = roomNode.get("emailAddress").asText();
            roomData.put("emailAddress", roomEmail);

            // Fetch events for this room
            List<Map<String, Object>> events = getRoomEvents(roomEmail, accessToken);
            roomData.put("events", events);

            return ResponseEntity.ok(roomData);

        } catch (Exception e) {
            e.printStackTrace();
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to fetch room details: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}