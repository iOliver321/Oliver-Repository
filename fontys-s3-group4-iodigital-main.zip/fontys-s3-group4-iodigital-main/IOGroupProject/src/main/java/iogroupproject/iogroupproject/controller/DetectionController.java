package iogroupproject.iogroupproject.controller;

import iogroupproject.iogroupproject.dto.DetectionDTO;
import iogroupproject.iogroupproject.service.DetectionService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@CrossOrigin("*")
public class DetectionController {

    private final DetectionService detectionService;

    @GetMapping("/detection")
    public ResponseEntity<DetectionDTO> getLiveDetection() {
        Optional<DetectionDTO> detectionData = detectionService.getLiveDetection();
        if (detectionData.isPresent()) {
            return ResponseEntity.ok(detectionData.get());
        } else {
            return ResponseEntity.status(503).build();
        }
    }
}