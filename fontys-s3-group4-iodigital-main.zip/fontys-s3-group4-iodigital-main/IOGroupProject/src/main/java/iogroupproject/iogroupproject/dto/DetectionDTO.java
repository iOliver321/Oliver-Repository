package iogroupproject.iogroupproject.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class DetectionDTO {

    @JsonProperty("person_detected")
    private boolean personDetected;

    @JsonProperty("person_count")
    private int personCount;
}