package iogroupproject.iogroupproject.service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

@Service
public class EmailService {

    private final JavaMailSender mailSender;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendRoomOccupancyAlert(String to, String roomName, LocalDateTime startDateTime, LocalDateTime endDateTime, int currentOccupancy, int maxOccupancy) {
        System.out.println("Running `sendRoomOccupancyAlert()`...");

        // Define formatter to display date, hours, and minutes
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
        String formattedStart = startDateTime.format(formatter);
        String formattedEnd = endDateTime.format(formatter);

        System.out.println("Constructing email...");
        String subject = "Room Underutilization Alert";
        String text = String.format("""
                Hello,
                
                Your ongoing booking for room '%s' from %s to %s currently has only %d occupant(s).
                The room capacity is %d. Please consider releasing the room or resizing the meeting.
                
                
                Best regards,
                iO Digital Room Occupancy Alert system
                
                P.S.:
                If the information in this email is incorrect, please contact the system administrator.
                """,
                roomName, formattedStart, formattedEnd, currentOccupancy, maxOccupancy
        );

        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(System.getenv("EMAIL_USERNAME"));
        message.setTo(to);
        message.setSubject(subject);
        message.setText(text);

        System.out.println("Email constructed.");

        System.out.println("Sending email...");
        mailSender.send(message);
        System.out.println("Email sent.");
    }
}
