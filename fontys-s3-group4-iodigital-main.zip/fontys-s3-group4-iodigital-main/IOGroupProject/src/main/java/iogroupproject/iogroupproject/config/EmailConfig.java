package iogroupproject.iogroupproject.config;
import jakarta.mail.Folder;
import jakarta.mail.MessagingException;
import jakarta.mail.Session;
import jakarta.mail.Store;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Properties;

@Configuration
public class EmailConfig {

    @Bean
    public Store emailStore() throws MessagingException {
        Properties props = new Properties();
        props.put("mail.store.protocol", "imap");
        props.put("mail.imap.host", "imap.gmail.com");
        props.put("mail.imap.port", "993");
        props.put("mail.imap.ssl.enable", "true");

        Session session = Session.getInstance(props);
        Store store = session.getStore("imap");
        store.connect(System.getenv("EMAIL_USERNAME"), System.getenv("EMAIL_PASSWORD"));
        return store;
    }

    @Bean
    public Folder sentMailFolder(Store store) throws MessagingException {
        return store.getFolder("[Gmail]/Sent Mail");
    }
}
