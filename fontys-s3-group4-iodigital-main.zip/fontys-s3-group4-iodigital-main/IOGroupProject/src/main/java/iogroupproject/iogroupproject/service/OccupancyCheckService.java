package iogroupproject.iogroupproject.service;
import com.fasterxml.jackson.databind.JsonNode;
import iogroupproject.iogroupproject.dto.DetectionDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.scheduling.TaskScheduler;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Service
@EnableScheduling
@RequiredArgsConstructor
public class OccupancyCheckService {
    // Keeps track of event IDs that have already been scheduled to prevent duplicates.
    final Set<String> scheduledEventIds = ConcurrentHashMap.newKeySet();
    private final Map<String, LocalDateTime> successfullySentAlerts = new ConcurrentHashMap<>();

    private final TaskScheduler taskScheduler;
    private final FetchEventsService fetchEventsService;
    private final DetectionService detectionService;
    private final EmailService emailService;

    @Scheduled(cron = "0 0 * * * *")
    public void clearSentEmailsList() {
        successfullySentAlerts.clear();
        System.out.println("List of successful alerts has been cleared.");
    }


    @Scheduled(cron = "0 */5 * * * *")
    public void scheduleChecksForNewEvents() {
        try {
            System.out.println("--------------------");
            System.out.println("--------------------");
            System.out.println("--------------------");
            System.out.println("Fetching calendar events...");
            List<Map<String, Object>> events = fetchEventsService.getCalendarEvents();
            System.out.println("Events fetched: " + events);

            for (Map<String, Object> event : events) {
                processEvent(event);
            }
        } catch (Exception e) {
            System.out.println("Exception occurred while scheduling checks: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void processEvent(Map<String, Object> event) {
        System.out.println("Processing event: " + event);
        Optional<String> eventIdOpt = parseEventId(event);
        if (eventIdOpt.isEmpty()) return;
        String eventId = eventIdOpt.get();

        if (scheduledEventIds.contains(eventId)) {
            System.out.println("Event skipped - Already scheduled: " + eventId);
            return;
        }

        Optional<LocalDateTime> startDateTimeOpt = parseDateTimeField(event, "start");
        Optional<LocalDateTime> endDateTimeOpt = parseDateTimeField(event, "end");
        if (startDateTimeOpt.isEmpty() || endDateTimeOpt.isEmpty()) return;

        LocalDateTime startDateTime = startDateTimeOpt.get();
        LocalDateTime endDateTime = endDateTimeOpt.get();

        if (startDateTime.plusMinutes(30).isBefore(LocalDateTime.now())) {
            System.out.println("Event skipped - Already started more than 10 minutes ago.");
            return;
        }

        // Attempt to retrieve and store organizer email
        String organizerEmail = getOrganizerEmail(event);
        if (organizerEmail != null) {
            // Store the email in the event data for later use
            event.put("organizerEmail", organizerEmail);
        }

        scheduledEventIds.add(eventId);
        System.out.println("Event scheduled: " + eventId);
        scheduleOccupancyCheck(eventId, startDateTime, endDateTime, event);
    }


    private Optional<String> parseEventId(Map<String, Object> event) {
        if (!(event.get("id") instanceof String eventId)) {
            System.out.println("Event skipped - Invalid or missing ID.");
            return Optional.empty();
        }
        return Optional.of(eventId);
    }

    /**
     * General method to parse and convert a given datetime field ("start" or "end") from the event.
     * Assumes the datetime is in UTC and converts it to local time.
     */
    private Optional<LocalDateTime> parseDateTimeField(Map<String, Object> event, String fieldName) {
        Object timeObj = event.get(fieldName);
        if (timeObj == null) {
            System.out.println("Event skipped - Missing or invalid '" + fieldName + "' field.");
            return Optional.empty();
        }

        String dateTimeString;
        if (timeObj instanceof Map<?, ?> timeMap) {
            Object dtObj = timeMap.get("dateTime");
            if (!(dtObj instanceof String)) {
                System.out.println("Event skipped - Missing or invalid '" + fieldName + ".dateTime' field.");
                return Optional.empty();
            }
            dateTimeString = (String) dtObj;
        } else if (timeObj instanceof String) {
            dateTimeString = (String) timeObj;
        } else {
            System.out.println("Event skipped - Missing or invalid '" + fieldName + "' field.");
            return Optional.empty();
        }

        try {
            LocalDateTime utcDateTime = LocalDateTime.parse(dateTimeString);
            // Convert UTC time to system local time.
            ZonedDateTime utcZoned = utcDateTime.atZone(ZoneOffset.UTC);
            LocalDateTime localDateTime = utcZoned.withZoneSameInstant(ZoneId.systemDefault()).toLocalDateTime();
            return Optional.of(localDateTime);
        } catch (Exception e) {
            System.out.println("Event skipped - Failed to parse " + fieldName + " datetime: " + dateTimeString);
            return Optional.empty();
        }
    }

    private void scheduleOccupancyCheck(String eventId, LocalDateTime startDateTime, LocalDateTime endDateTime, Map<String, Object> eventData) {
        // Initial scheduling at 10 minutes after start.
        LocalDateTime initialRunTime = startDateTime.plusMinutes(10).plusSeconds(30);
        scheduleNext(eventId, startDateTime, initialRunTime, endDateTime, eventData);
    }

    private void scheduleNext(String eventId, LocalDateTime startDateTime, LocalDateTime nextRunTime, LocalDateTime endDateTime, Map<String, Object> eventData) {
        System.out.println("Scheduling occupancy check for event: " + eventId + " at " + nextRunTime);
        Instant triggerTime = nextRunTime.atZone(ZoneId.systemDefault()).plusMinutes(10).toInstant();

        taskScheduler.schedule(() -> {
            System.out.println("Running occupancy check for event: " + eventId);
            boolean emailSent = doOccupancyCheck(eventData, eventId, startDateTime, endDateTime);

            if (emailSent) {
                scheduledEventIds.remove(eventId);
                System.out.println("Event removed from scheduled list: " + eventId);
            } else {
                if (LocalDateTime.now().isBefore(endDateTime) && !successfullySentAlerts.containsKey(eventId)) {
                    System.out.println("Rescheduling email check for event: " + eventId + " in 1 minute.");
                    scheduleNext(eventId, startDateTime, LocalDateTime.now().plusMinutes(1), endDateTime, eventData);
                } else if(LocalDateTime.now().isAfter(endDateTime)) {
                    scheduledEventIds.remove(eventId);
                    System.out.println("Event removed from scheduled list after end time: " + eventId);
                }
            }
        }, triggerTime);
    }

    /**
     * Checks occupancy and attempts to send an email if occupancy is below half capacity.
     * Returns true if email was sent successfully, false otherwise.
     */
    boolean doOccupancyCheck(Map<String, Object> eventData, String eventId, LocalDateTime startDateTime, LocalDateTime endDateTime) {
        System.out.println("Starting occupancy check...");

        // Skip check if email was already sent for this event within the last hour
        if (successfullySentAlerts.containsKey(eventId)) {
            System.out.println("Email already sent for event: " + eventId + " within the last hour. Skipping.");
            return false;
        }

        Optional<DetectionDTO> detectionOpt = detectionService.getLiveDetection();

        if (detectionOpt.isEmpty()) {
            System.out.println("Detection data not available. Skipping occupancy check.");
            return false;
        }

        int occupantCount = detectionOpt.get().getPersonCount();
        System.out.println("Occupant count: " + occupantCount);

        int maxOccupancy = 5;
        if (occupantCount <= maxOccupancy / 2.0) {
            System.out.println("Occupancy is below half capacity. Preparing to send email...");

            String organizerEmail = extractOrganizerEmail(eventData);
            if (organizerEmail != null) {
                if (attemptToSendEmail(organizerEmail, startDateTime, endDateTime, occupantCount, maxOccupancy)) {
                    // Record that an email has been successfully sent for this event
                    System.out.println("Adding event to the list of successful alerts.");
                    successfullySentAlerts.put(eventId, LocalDateTime.now());
                    return true;
                }
            } else {
                System.out.println("Organizer's email not found. Skipping email sending.");
            }
        } else {
            System.out.println("Occupancy is sufficient. No email will be sent.");
        }

        return false;
    }

    private String extractOrganizerEmail(Map<String, Object> eventData) {
        Object emailObj = eventData.get("organizerEmail");
        String organizerEmail = null;
        if (emailObj instanceof String) {
            organizerEmail = (String) emailObj;
        } else if (emailObj instanceof JsonNode) {
            organizerEmail = ((com.fasterxml.jackson.databind.JsonNode) emailObj).asText();
        } else if (emailObj != null) {
            organizerEmail = emailObj.toString();
        }
        return organizerEmail;
    }

    private boolean attemptToSendEmail(String organizerEmail, LocalDateTime startDateTime, LocalDateTime endDateTime, int occupantCount, int maxOccupancy) {
        try {
            System.out.println("Sending email to: " + organizerEmail);
            emailService.sendRoomOccupancyAlert(
                    organizerEmail,
                    "Campus Eindhoven - 2 - Testruimte4",
                    startDateTime,
                    endDateTime,
                    occupantCount,
                    maxOccupancy
            );
            System.out.println("Email sent successfully to: " + organizerEmail);
            return true;
        } catch (Exception e) {
            System.out.println("Failed to send email: " + e.getMessage());
            // Will trigger retry logic in caller
        }
        return false;
    }

    String getOrganizerEmail(Map<String, Object> eventData) {
        System.out.println("Retrieving organizer email...");
        Object organizerObj = eventData.get("organizerEmail");

        if (organizerObj == null) {
            System.out.println("Organizer email field is missing.");
            return null;
        }

        // Case 1: Organizer is a simple string that might be an email.
        if (organizerObj instanceof String organizerStr) {
            if (organizerStr.contains("@")) {
                System.out.println("Organizer email retrieved from string: " + organizerStr);
                return organizerStr;
            } else {
                System.out.println("Organizer string does not appear to be a valid email: " + organizerStr);
                return null;
            }
        }

        // New case: Organizer is a Jackson TextNode.
        if (organizerObj instanceof com.fasterxml.jackson.databind.node.TextNode textNode) {
            String organizerStr = textNode.asText();
            if (organizerStr.contains("@")) {
                System.out.println("Organizer email retrieved from TextNode: " + organizerStr);
                return organizerStr;
            } else {
                System.out.println("Organizer TextNode does not appear to be a valid email: " + organizerStr);
                return null;
            }
        }

        // Case 2: Organizer is a nested map.
        if (organizerObj instanceof Map<?, ?> organizer) {
            Object emailAddressObj = organizer.get("emailAddress");
            if (emailAddressObj instanceof Map<?, ?> emailAddress) {
                Object address = emailAddress.get("address");
                if (address instanceof String email) {
                    System.out.println("Organizer email retrieved: " + email);
                    return email;
                } else {
                    System.out.println("Email address is missing or invalid.");
                    return null;
                }
            } else {
                System.out.println("EmailAddress field missing or invalid.");
                return null;
            }
        }

        // Fallback
        System.out.println("Organizer field structure not recognized: " + organizerObj.getClass());
        return null;
    }

}

