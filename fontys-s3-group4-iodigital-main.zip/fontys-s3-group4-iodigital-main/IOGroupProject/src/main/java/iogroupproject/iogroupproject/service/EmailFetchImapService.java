package iogroupproject.iogroupproject.service;

import iogroupproject.iogroupproject.dto.EmailDataDTO;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import lombok.Setter;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Setter
@Service
public class EmailFetchImapService {

    private static final String DEFAULT_FOLDER = "[Gmail]/Sent Mail";
    private String folderName = DEFAULT_FOLDER;

    public List<EmailDataDTO> fetchSentEmails() {
        System.out.println("Fetching sent emails started...");
        List<EmailDataDTO> emailDataList = new ArrayList<>();
        Store store = null;
        Folder emailFolder = null;

        String emailUsername = System.getenv("EMAIL_USERNAME");
        String emailPassword = System.getenv("EMAIL_PASSWORD");

        try {
            store = connectToStore(emailUsername, emailPassword);
            emailFolder = openFolder(store, folderName);
            if (emailFolder != null) {
                emailDataList = processMessages(emailFolder);
            } else {
                System.err.println("Error: Folder " + folderName + " not found.");
            }
        } catch (Exception e) {
            System.err.println("Error fetching emails: " + e.getMessage());
        } finally {
            closeResources(emailFolder, store);
            System.out.println("Finished fetching emails.");
        }

        return emailDataList;
    }

    private Store connectToStore(String username, String password) throws MessagingException {
        System.out.println("Connecting to IMAP store...");
        Properties props = new Properties();
        props.put("mail.store.protocol", "imaps");
        Session session = Session.getInstance(props);
        Store store = session.getStore("imaps");
        store.connect("imap.gmail.com", 993, username, password);
        System.out.println("Connected to IMAP store.");
        return store;
    }

    private Folder openFolder(Store store, String folderName) throws MessagingException {
        System.out.println("Accessing folder: " + folderName);
        Folder folder = store.getFolder(folderName);
        if (folder.exists()) {
            folder.open(Folder.READ_ONLY);
            System.out.println("Opened folder: " + folder.getFullName());
            return folder;
        }
        return null;
    }

    private List<EmailDataDTO> processMessages(Folder folder) throws MessagingException, IOException {
        List<EmailDataDTO> emailDataList = new ArrayList<>();
        Message[] messages = folder.getMessages();
        System.out.println("Number of messages retrieved: " + messages.length);

        for (Message message : messages) {
            EmailDataDTO emailData;
            if (message instanceof MimeMessage mimeMessage) {
                emailData = extractEmailDataDTO(mimeMessage);
                if (emailData == null) {
                    emailData = new EmailDataDTO();
                    emailData.setSubject(message.getSubject());
                }
            } else {
                emailData = new EmailDataDTO();
                emailData.setSubject(message.getSubject());
            }
            emailDataList.add(emailData);
        }
        return emailDataList;
    }

    private void closeResources(Folder folder, Store store) {
        if (folder != null && folder.isOpen()) {
            try {
                folder.close(false);
                System.out.println("Closed folder: " + folder.getFullName());
            } catch (Exception e) {
                System.err.println("Error closing folder: " + e.getMessage());
            }
        }
        if (store != null && store.isConnected()) {
            try {
                store.close();
                System.out.println("Closed email store.");
            } catch (Exception e) {
                System.err.println("Error closing store: " + e.getMessage());
            }
        }
    }

    private EmailDataDTO extractEmailDataDTO(MimeMessage message) {
        try {
            EmailDataDTO emailDataDTO = new EmailDataDTO();

            // 1. Recipient
            Address[] recipients = message.getRecipients(Message.RecipientType.TO);
            if (recipients != null && recipients.length > 0) {
                emailDataDTO.setRecipient(((InternetAddress) recipients[0]).getAddress());
            }

            // 2. Subject
            emailDataDTO.setSubject(message.getSubject());

            // 3. Sent DateTime
            Date sentDate = message.getSentDate();
            emailDataDTO.setSentDateTime(sentDate);

            // 4. Parse Body
            Object content = message.getContent();
            String text = extractTextContent(content);
            extractBodyDetails(text, emailDataDTO);

            return emailDataDTO;
        } catch (Exception e) {
            System.err.println("Error extracting email data: " + e.getMessage());
        }
        return null;
    }

    private String extractTextContent(Object content) throws MessagingException, IOException {
        if (content instanceof String s) {
            return s;
        } else if (content instanceof Multipart multipart) {
            return getTextFromMultipart(multipart);
        } else {
            return "";
        }
    }

    private String getTextFromMultipart(Multipart multipart) throws MessagingException, IOException {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < multipart.getCount(); i++) {
            BodyPart bodyPart = multipart.getBodyPart(i);

            if (bodyPart.isMimeType("text/plain") || bodyPart.isMimeType("text/html")) {
                sb.append(bodyPart.getContent().toString());
            } else if (bodyPart.getContent() instanceof Multipart) {
                sb.append(getTextFromMultipart((Multipart) bodyPart.getContent()));
            }
        }
        return sb.toString();
    }

    private void extractBodyDetails(String body, EmailDataDTO emailDataDTO) {
        Pattern roomNamePattern = Pattern.compile("room '([^']+)'");
        Pattern currentOccupantsPattern = Pattern.compile("currently has only (\\d+) occupant");
        Pattern maxCapacityPattern = Pattern.compile("capacity is (\\d+)");

        Matcher roomNameMatcher = roomNamePattern.matcher(body);
        Matcher currentOccupantsMatcher = currentOccupantsPattern.matcher(body);
        Matcher maxCapacityMatcher = maxCapacityPattern.matcher(body);

        if (roomNameMatcher.find()) {
            emailDataDTO.setRoomName(roomNameMatcher.group(1));
        } else {
            emailDataDTO.setRoomName("Unknown");
        }
        if (currentOccupantsMatcher.find()) {
            emailDataDTO.setCurrentOccupants(Integer.parseInt(currentOccupantsMatcher.group(1)));
        } else {
            emailDataDTO.setCurrentOccupants(0);
        }
        if (maxCapacityMatcher.find()) {
            emailDataDTO.setMaxCapacity(Integer.parseInt(maxCapacityMatcher.group(1)));
        } else {
            emailDataDTO.setMaxCapacity(0);
        }
    }
}
