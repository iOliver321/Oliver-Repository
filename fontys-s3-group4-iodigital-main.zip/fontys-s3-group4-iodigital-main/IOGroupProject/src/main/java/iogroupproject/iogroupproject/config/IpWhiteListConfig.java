package iogroupproject.iogroupproject.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.IpAddressMatcher;

@Configuration
public class IpWhiteListConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {

        http
                .authorizeHttpRequests(auth -> auth
                        // Whitelist only localhost (127.0.0.1 and 0:0:0:0:0:0:0:1 for IPv6)
                        .requestMatchers(request ->
                                new IpAddressMatcher("127.0.0.1").matches(request) ||
                                        new IpAddressMatcher("0:0:0:0:0:0:0:1").matches(request)
                        ).permitAll() // Allow all requests coming from localhost

                        // Any other request should be blocked
                        .anyRequest().denyAll() // Deny all other requests
                )
                .formLogin(form -> form.permitAll()) // Allow form login for localhost
                .csrf(csrf -> csrf.disable()); // Disable CSRF if necessary
        return http.build();
    }
}