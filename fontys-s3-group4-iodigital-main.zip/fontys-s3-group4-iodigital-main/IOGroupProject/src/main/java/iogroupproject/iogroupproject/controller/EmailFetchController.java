package iogroupproject.iogroupproject.controller;

import iogroupproject.iogroupproject.dto.EmailDataDTO;
import iogroupproject.iogroupproject.service.EmailFetchImapService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/strikes")
@CrossOrigin("*")
public class EmailFetchController {

    private final EmailFetchImapService emailFetchImapService;

    public EmailFetchController(EmailFetchImapService emailFetchImapService) {
        this.emailFetchImapService = emailFetchImapService;
    }

    @GetMapping
    public List<EmailDataDTO> getSentEmails() {
        System.out.println("Endpoint for fetching emails called.");
        return emailFetchImapService.fetchSentEmails();
    }
}
