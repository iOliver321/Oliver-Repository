package iogroupproject.iogroupproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IoGroupProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(IoGroupProjectApplication.class, args);
	}

}
