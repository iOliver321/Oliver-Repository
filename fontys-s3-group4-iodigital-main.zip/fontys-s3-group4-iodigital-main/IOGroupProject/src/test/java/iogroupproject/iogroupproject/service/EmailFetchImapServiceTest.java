package iogroupproject.iogroupproject.service;

import iogroupproject.iogroupproject.dto.EmailDataDTO;
import jakarta.mail.*;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Date;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for EmailFetchImapService.
 * - We do NOT connect to real Gmail IMAP here.
 * - We use Mockito to mock MimeMessage, Multipart, and other mail classes.
 * - We confirm that internal logic (regex parsing, multi-part handling, etc.) works as intended.
 */
@ExtendWith(MockitoExtension.class)
class EmailFetchImapServiceTest {

    @InjectMocks
    private EmailFetchImapService emailFetchImapService;

    @Mock
    private MimeMessage mockMimeMessage;  // We'll mock a MimeMessage

    @BeforeEach
    void setup() {
        System.out.println("--------------------");
        System.out.println("Running `setup()`...");
        // If you need any setup before each test, do it here
        // e.g., emailFetchImapService.setFolderName("SomeFolder");
        System.out.println("`setup()` complete.");
        System.out.println("--------------------");
    }

    @Test
    @DisplayName("extractBodyDetails() should parse roomName, occupant, capacity from text (happy path)")
    void testExtractBodyDetails_fullMatch() {
        System.out.println("--------------------");
        System.out.println("Running test: `testExtractBodyDetails_fullMatch()`...");

        // Given a typical email body
        String body = String.format("""
                Hello,
                
                Your ongoing booking for room '%s' currently has only %d occupant(s).
                The room capacity is %d. Please consider releasing the room or resizing the meeting.
                
                
                Best regards,
                iO Digital Room Occupancy Alert system
                
                P.S.:
                If the information in this email is incorrect, please contact the system administrator.
                """,
                "Big Conference Room", 2, 5);

        EmailDataDTO dto = new EmailDataDTO();
        // We call the private method indirectly or reflectively;
        // Or you can make the method package-private if you prefer testable design.
        // For demonstration, let's call it reflectively:
        try {
            var method = EmailFetchImapService.class
                    .getDeclaredMethod("extractBodyDetails", String.class, EmailDataDTO.class);
            method.setAccessible(true);
            method.invoke(emailFetchImapService, body, dto);
        } catch (Exception e) {
            fail("Reflection call failed: " + e.getMessage());
        }

        // Then we expect parsed fields
        assertEquals("Big Conference Room", dto.getRoomName());
        assertEquals(2, dto.getCurrentOccupants());
        assertEquals(5, dto.getMaxCapacity());

        System.out.println("testExtractBodyDetails_fullMatch() complete.");
        System.out.println("--------------------");
    }

    @Test
    @DisplayName("extractBodyDetails() should handle partial or missing occupant/capacity info")
    void testExtractBodyDetails_partial() {
        System.out.println("--------------------");
        System.out.println("Running test: `testExtractBodyDetails_partial()`...");

        // e.g. the occupant line is missing
        String body = "Hello, your booking for room 'TestRoom' is ongoing. capacity is 10. -Regards";
        EmailDataDTO dto = new EmailDataDTO();
        try {
            var method = EmailFetchImapService.class
                    .getDeclaredMethod("extractBodyDetails", String.class, EmailDataDTO.class);
            method.setAccessible(true);
            method.invoke(emailFetchImapService, body, dto);
        } catch (Exception e) {
            fail("Reflection call failed: " + e.getMessage());
        }

        // occupant wasn't found, so it should default to 0
        assertEquals("TestRoom", dto.getRoomName());
        assertEquals(0, dto.getCurrentOccupants());
        assertEquals(10, dto.getMaxCapacity());

        System.out.println("testExtractBodyDetails_partial() complete.");
        System.out.println("--------------------");
    }

    @Test
    @DisplayName("extractEmailDataDTO() should populate subject, recipient, sentDate, and parse body as text")
    void testExtractEmailDataDTO_textPlain() throws Exception {
        System.out.println("--------------------");
        System.out.println("Running test: `testExtractEmailDataDTO_textPlain()`...");

        // Mock a simple text/plain message
        when(mockMimeMessage.getSubject()).thenReturn("Subject: Underutilization Alert");
        Address[] to = {new InternetAddress("someuser@example.com")};
        when(mockMimeMessage.getRecipients(Message.RecipientType.TO)).thenReturn(to);
        Date sentDate = new Date();
        when(mockMimeMessage.getSentDate()).thenReturn(sentDate);

        // The body content is a String (text/plain scenario)
        String body = "Some body text here. room 'TestRoomA' currently has only 3 occupant(s). The room capacity is 6.";
        when(mockMimeMessage.getContent()).thenReturn(body);

        // Now call the private method via reflection or re-architect to make it testable
        var method = EmailFetchImapService.class.getDeclaredMethod("extractEmailDataDTO", MimeMessage.class);
        method.setAccessible(true);
        EmailDataDTO result = (EmailDataDTO) method.invoke(emailFetchImapService, mockMimeMessage);

        // Verify results
        assertNotNull(result);
        assertEquals("Subject: Underutilization Alert", result.getSubject());
        assertEquals("someuser@example.com", result.getRecipient());
        assertEquals(sentDate, result.getSentDateTime());
        // And the body-based fields
        assertEquals("TestRoomA", result.getRoomName());
        assertEquals(3, result.getCurrentOccupants());
        assertEquals(6, result.getMaxCapacity());

        System.out.println("testExtractEmailDataDTO_textPlain() complete.");
        System.out.println("--------------------");
    }

    @Test
    @DisplayName("extractEmailDataDTO() should handle multipart message and combine text")
    void testExtractEmailDataDTO_multipart() throws Exception {
        System.out.println("--------------------");
        System.out.println("Running test: `testExtractEmailDataDTO_multipart()`...");

        // 1) Mock a multipart scenario
        when(mockMimeMessage.getSubject()).thenReturn("Multipart Subject");
        Address[] to = {new InternetAddress("anotheruser@example.com")};
        when(mockMimeMessage.getRecipients(Message.RecipientType.TO)).thenReturn(to);
        Date sentDate = new Date();
        when(mockMimeMessage.getSentDate()).thenReturn(sentDate);

        // 2) Build a fake Multipart with 2 parts:
        // Part A: text/plain
        // Part B: text/html
        var mockPartA = mock(BodyPart.class);
        var mockPartB = mock(BodyPart.class);
        var mockMultipart = mock(Multipart.class);

        when(mockMultipart.getCount()).thenReturn(2);
        when(mockMultipart.getBodyPart(0)).thenReturn(mockPartA);
        when(mockMultipart.getBodyPart(1)).thenReturn(mockPartB);

        when(mockPartA.isMimeType("text/plain")).thenReturn(true);
        when(mockPartA.getContent()).thenReturn("Hello from text/plain. room 'MultiRoom' currently has only 1 occupant(s). ");

        when(mockPartB.isMimeType("text/plain")).thenReturn(false);
        when(mockPartB.isMimeType("text/html")).thenReturn(true);
        when(mockPartB.getContent()).thenReturn("<html><body>And the room capacity is 4.</body></html>");

        // 3) The message content is this mocked Multipart
        when(mockMimeMessage.getContent()).thenReturn(mockMultipart);

        // 4) invoke extractEmailDataDTO via reflection
        var method = EmailFetchImapService.class.getDeclaredMethod("extractEmailDataDTO", MimeMessage.class);
        method.setAccessible(true);
        EmailDataDTO result = (EmailDataDTO) method.invoke(emailFetchImapService, mockMimeMessage);

        // 5) Verify
        assertNotNull(result);
        assertEquals("Multipart Subject", result.getSubject());
        assertEquals("anotheruser@example.com", result.getRecipient());
        assertEquals(sentDate, result.getSentDateTime());
        // Body-based fields
        // combined text is "Hello from text/plain. room 'MultiRoom' currently has only 1 occupant(s). <html>...capacity is 4..."
        // The code's regex should parse:
        assertEquals("MultiRoom", result.getRoomName());
        assertEquals(1, result.getCurrentOccupants());
        assertEquals(4, result.getMaxCapacity());

        System.out.println("testExtractEmailDataDTO_multipart() complete.");
        System.out.println("--------------------");
    }

    @Nested
    @DisplayName("Misc corner cases or negative scenarios")
    class NegativeScenarios {

        @Test
        @DisplayName("extractEmailDataDTO() returns null if an exception occurs")
        void testExtractEmailDataDTO_exception() throws Exception {
            System.out.println("--------------------");
            System.out.println("Running test: `testExtractEmailDataDTO_exception()`...");

            // Let's say getSubject() throws an exception
            when(mockMimeMessage.getSubject()).thenThrow(new MessagingException("fake error"));

            var method = EmailFetchImapService.class.getDeclaredMethod("extractEmailDataDTO", MimeMessage.class);
            method.setAccessible(true);
            EmailDataDTO result = (EmailDataDTO) method.invoke(emailFetchImapService, mockMimeMessage);

            assertNull(result, "Should return null if an exception is thrown.");

            System.out.println("testExtractEmailDataDTO_exception() complete.");
            System.out.println("--------------------");
        }
    }

}
