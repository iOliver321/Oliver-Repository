package iogroupproject.iogroupproject.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;

public class EmailServiceTest {

    private JavaMailSender mailSender;
    private EmailService emailService;

    @BeforeEach
    void init() {
        mailSender = Mockito.mock(JavaMailSender.class);
        emailService = new EmailService(mailSender);
    }

    @Test
    void testSendRoomOccupancyAlert() {
        String toEmail = "rastislav.kajan@gmail.com";
        String roomName = "Test Room";
        int currentOccupancy = 2;
        int maxOccupancy = 5;

        emailService.sendRoomOccupancyAlert(toEmail, roomName, , , currentOccupancy, maxOccupancy);

        // Capture the argument sent to the JavaMailSender
        ArgumentCaptor<SimpleMailMessage> messageCaptor = ArgumentCaptor.forClass(SimpleMailMessage.class);
        Mockito.verify(mailSender, Mockito.times(1)).send(messageCaptor.capture());

        // Extract captured message
        SimpleMailMessage capturedMessage = messageCaptor.getValue();

        assertEquals(System.getenv("EMAIL_USERNAME"), capturedMessage.getFrom());
        // Check if the 'to' field is not null and has at least one recipient
        assertNotNull(capturedMessage.getTo(), "The 'to' field should not be null");
        assertTrue(capturedMessage.getTo().length > 0, "The 'to' field should contain at least one recipient");
        assertEquals(toEmail, capturedMessage.getTo()[0]); // Safe access

        assertEquals("Room Underutilization Alert", capturedMessage.getSubject());
        assertEquals(String.format("""
                Hello,
                
                Your ongoing booking for room '%s' currently has only %d occupant(s).
                The room capacity is %d. Please consider releasing the room or resizing the meeting.
                
                
                Best regards,
                iO Digital Room Occupancy Alert system
                
                P.S.:
                If the information in this email is incorrect, please contact the system administrator.
                """,
                roomName, currentOccupancy, maxOccupancy), capturedMessage.getText());
    }
}