package iogroupproject.iogroupproject.config;

import jakarta.mail.Session;
import jakarta.mail.Store;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import java.util.Properties;

@Configuration
public class EmailTestConfig {

    @Bean
    public Store testImapStore() throws Exception {
        // Read credentials from environment variables
        final String username = System.getenv("EMAIL_USERNAME");
        final String password = System.getenv("EMAIL_PASSWORD");
        if (username == null || password == null) {
            throw new IllegalStateException("EMAIL_USERNAME or EMAIL_PASSWORD environment variable not set");
        }

        Properties props = new Properties();
        props.put("mail.store.protocol", "imaps");
        props.put("mail.imaps.ssl.enable", "true");
        props.put("mail.imaps.ssl.trust", "*");
        // If you want to see the debug logs, uncomment this:
        // props.put("mail.debug", "true");

        Session session = Session.getInstance(props);
        Store store = session.getStore("imaps");

        // Connect to Gmail IMAP.
        // For Gmail: host is "imap.gmail.com", port default for SSL is 993
        store.connect("imap.gmail.com", 993, username, password);

        return store;
    }

    @Bean
    public JavaMailSender javaMailSender() {
        JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
        // Set default properties if needed; they might be overridden by application.properties
        mailSender.setHost("localhost");
        mailSender.setPort(3025);
        return mailSender;
    }
}
