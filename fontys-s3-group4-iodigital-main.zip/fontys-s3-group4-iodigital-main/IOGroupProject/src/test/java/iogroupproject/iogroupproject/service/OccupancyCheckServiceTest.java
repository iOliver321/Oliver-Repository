package iogroupproject.iogroupproject.service;

import iogroupproject.iogroupproject.dto.DetectionDTO;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.scheduling.TaskScheduler;

import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class OccupancyCheckServiceTest {

    @Mock
    private TaskScheduler taskScheduler;

    @Mock
    private FetchEventsService fetchEventsService;

    @Mock
    private DetectionService detectionService;

    @Mock
    private EmailService emailService;

    @InjectMocks
    private OccupancyCheckService occupancyCheckService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    /**
     * Tests whether a new event (not yet scheduled) is indeed scheduled.
     */
    @Test
    void testScheduleChecksForNewEvents_NewEvent_SchedulesTask() {
        // Arrange
        Map<String, Object> event = Map.of(
                "id", "event1",
                "start", Map.of("dateTime", LocalDateTime.now().plusMinutes(15).toString()),
                "organizer", Map.of("emailAddress", Map.of("address", "organizer@example.com"))
        );
        when(fetchEventsService.getCalendarEvents()).thenReturn(List.of(event));

        // Act
        occupancyCheckService.scheduleChecksForNewEvents();

        // Assert
        verify(taskScheduler, times(1)).schedule(any(Runnable.class), any(Instant.class));
        // Also check that we added this event ID to scheduledEventIds
        assertTrue(occupancyCheckService.scheduledEventIds.contains("event1"));
    }

    /**
     * Tests that if an event has already been scheduled, we do NOT schedule it again.
     */
    @Test
    void testScheduleChecksForNewEvents_ExistingEvent_DoesNotScheduleTask() {
        // Arrange
        Map<String, Object> event = Map.of(
                "id", "event1",
                "start", Map.of("dateTime", LocalDateTime.now().plusMinutes(15).toString())
        );
        when(fetchEventsService.getCalendarEvents()).thenReturn(List.of(event));

        // Simulate the event already being scheduled
        occupancyCheckService.scheduledEventIds.add("event1");

        // Act
        occupancyCheckService.scheduleChecksForNewEvents();

        // Assert
        verify(taskScheduler, never()).schedule(any(Runnable.class), any(Instant.class));
    }

    /**
     * Tests that if there's no "start" info or a malformed dateTime, the event is ignored.
     */
    @Test
    void testScheduleChecksForNewEvents_MissingStartInfo_DoesNotScheduleTask() {
        // Arrange
        Map<String, Object> event = Map.of(
                "id", "event2"
                // intentionally no "start" field
        );
        when(fetchEventsService.getCalendarEvents()).thenReturn(List.of(event));

        // Act
        occupancyCheckService.scheduleChecksForNewEvents();

        // Assert
        verify(taskScheduler, never()).schedule(any(Runnable.class), any(Instant.class));
        assertFalse(occupancyCheckService.scheduledEventIds.contains("event2"));
    }

    /**
     * Tests doOccupancyCheck when the person count is below half capacity
     * and ensures email is sent to the organizer.
     */
    @Test
    void testDoOccupancyCheck_BelowHalfCapacity_SendsEmail() {
        // Arrange
        Map<String, Object> eventData = Map.of(
                "organizer", Map.of("emailAddress", Map.of("address", "organizer@example.com"))
        );
        DetectionDTO detectionDTO = new DetectionDTO();
        detectionDTO.setPersonCount(2); // Below half of capacity if capacity is 5 or more
        when(detectionService.getLiveDetection()).thenReturn(Optional.of(detectionDTO));

        // Act
        occupancyCheckService.doOccupancyCheck(eventData);

        // Assert
        verify(emailService, times(1))
                .sendRoomOccupancyAlert(eq("organizer@example.com"), anyString(), , , eq(2), eq(5));
    }

    /**
     * Tests doOccupancyCheck when the person count is above half capacity
     * and ensures NO email is sent.
     */
    @Test
    void testDoOccupancyCheck_AboveHalfCapacity_DoesNotSendEmail() {
        // Arrange
        Map<String, Object> eventData = Map.of(
                "organizer", Map.of("emailAddress", Map.of("address", "organizer@example.com"))
        );
        DetectionDTO detectionDTO = new DetectionDTO();
        detectionDTO.setPersonCount(3); // Above half capacity if capacity is 5
        when(detectionService.getLiveDetection()).thenReturn(Optional.of(detectionDTO));

        // Act
        occupancyCheckService.doOccupancyCheck(eventData);

        // Assert
        verify(emailService, never()).sendRoomOccupancyAlert(any(), any(), , , anyInt(), anyInt());
    }

    /**
     * Tests doOccupancyCheck if detectionService returns an empty Optional;
     * ensures the method handles it gracefully (no NullPointerException, no email sent).
     */
    @Test
    void testDoOccupancyCheck_EmptyDetection_NoEmailSent() {
        // Arrange
        Map<String, Object> eventData = Map.of(
                "organizer", Map.of("emailAddress", Map.of("address", "organizer@example.com"))
        );
        when(detectionService.getLiveDetection()).thenReturn(Optional.empty());

        // Act
        occupancyCheckService.doOccupancyCheck(eventData);

        // Assert
        verify(emailService, never()).sendRoomOccupancyAlert(any(), any(), , , anyInt(), anyInt());
    }

    /**
     * Tests getOrganizerEmail for a well-structured event map.
     */
    @Test
    void testGetOrganizerEmail_ValidEvent_ReturnsEmail() {
        // Arrange
        Map<String, Object> eventData = Map.of(
                "organizer", Map.of("emailAddress", Map.of("address", "organizer@example.com"))
        );

        // Act
        String email = occupancyCheckService.getOrganizerEmail(eventData);

        // Assert
        assertEquals("organizer@example.com", email);
    }

    /**
     * Tests getOrganizerEmail for an event that does not have the address key.
     */
    @Test
    void testGetOrganizerEmail_InvalidEvent_ReturnsNull() {
        // Arrange
        Map<String, Object> eventData = Map.of(
                "organizer", Map.of("emailAddress", Map.of("invalidKey", "value"))
        );

        // Act
        String email = occupancyCheckService.getOrganizerEmail(eventData);

        // Assert
        assertNull(email);
    }

    /**
     * Tests whether multiple events are scheduled correctly and
     * whether existing events are not re-scheduled.
     */
    @Test
    void testScheduleChecksForNewEvents_MultipleEvents_SomeAlreadyScheduled() {
        // Arrange
        Map<String, Object> event1 = Map.of(
                "id", "event1",
                "start", Map.of("dateTime", LocalDateTime.now().plusMinutes(10).toString())
        );
        Map<String, Object> event2 = Map.of(
                "id", "event2",
                "start", Map.of("dateTime", LocalDateTime.now().plusMinutes(20).toString())
        );
        Map<String, Object> event3 = Map.of(
                "id", "event3",
                "start", Map.of("dateTime", LocalDateTime.now().plusMinutes(30).toString())
        );

        // Mark event2 as already scheduled
        occupancyCheckService.scheduledEventIds.add("event2");

        when(fetchEventsService.getCalendarEvents()).thenReturn(List.of(event1, event2, event3));

        // Act
        occupancyCheckService.scheduleChecksForNewEvents();

        // Assert
        // event1 and event3 should be scheduled, but event2 should NOT be scheduled again
        verify(taskScheduler, times(2)).schedule(any(Runnable.class), any(Instant.class));
        assertTrue(occupancyCheckService.scheduledEventIds.contains("event1"));
        assertTrue(occupancyCheckService.scheduledEventIds.contains("event2"));
        assertTrue(occupancyCheckService.scheduledEventIds.contains("event3"));
    }

    /**
     * (Optional) Tests a method to remove scheduled events if your service supports it.
     * Adjust this test according to your actual implementation.
     */
    @Test
    void testRemoveScheduledEvent_RemovesId() {
        // Suppose your service has a method removeScheduledEvent(String eventId)
        // This test verifies that it actually removes the ID from the scheduled set.
        occupancyCheckService.scheduledEventIds.add("eventX");

        // Act
        occupancyCheckService.scheduledEventIds.remove("eventX");

        // Assert
        assertFalse(occupancyCheckService.scheduledEventIds.contains("eventX"),
                "Event ID should be removed from the set");
    }
}
