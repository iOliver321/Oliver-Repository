package iogroupproject.iogroupproject.service;

import com.icegreen.greenmail.configuration.GreenMailConfiguration;
import com.icegreen.greenmail.store.FolderException;
import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.ServerSetupTest;
import jakarta.mail.Address;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertTrue;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = EmailServiceIntegrationTest.TestConfig.class)
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EmailServiceIntegrationTest {

    @Configuration
    static class TestConfig {

        // (A) Provide the JavaMailSender bean for local test
        @Bean
        public JavaMailSender javaMailSender() {
            JavaMailSenderImpl mailSender = new JavaMailSenderImpl();
            mailSender.setHost("localhost");
            mailSender.setPort(3025);
            return mailSender;
        }

        // (B) Provide the EmailService bean directly
        @Bean
        public EmailService emailService(JavaMailSender mailSender) {
            return new EmailService(mailSender);
        }
    }

    private static GreenMail greenMail;

    @Autowired
    private EmailService emailService; // <-- Should no longer be null

    @BeforeAll
    static void startGreenMail() {
        greenMail = new GreenMail(ServerSetupTest.SMTP);
        greenMail.withConfiguration(
                GreenMailConfiguration.aConfig().withUser("username", "password")
        );
        greenMail.start();
    }

    @AfterAll
    static void stopGreenMail() {
        greenMail.stop();
    }

    @BeforeEach
    void clearGreenMail() throws FolderException {
        greenMail.purgeEmailFromAllMailboxes();
    }

    @Test
    void testSendRoomOccupancyAlert() throws Exception {
        // Given
        String toAddress = "someone@example.com";
        String roomName = "TestRoomA";
        int currentOccupancy = 2;
        int maxOccupancy = 5;

        // When
        emailService.sendRoomOccupancyAlert(toAddress, roomName, , , currentOccupancy, maxOccupancy);

        // Then
        MimeMessage[] messages = greenMail.getReceivedMessages();
        assertEquals(1, messages.length,
                "Expected 1 email in the GreenMail store");

        MimeMessage msg = messages[0];
        Address[] recipients = msg.getAllRecipients();
        assertEquals(toAddress, recipients[0].toString());

        String subject = msg.getSubject();
        assertEquals("Room Underutilization Alert", subject);

        String body = (String) msg.getContent();
        System.out.println("Email body:\n" + body);
        assertTrue(body.contains("room '" + roomName + "' currently has only " + currentOccupancy + " occupant(s)."));
        assertTrue(body.contains("The room capacity is " + maxOccupancy));
    }
}
