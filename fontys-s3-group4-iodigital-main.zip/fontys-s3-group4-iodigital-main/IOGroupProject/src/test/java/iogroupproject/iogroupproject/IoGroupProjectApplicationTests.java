package iogroupproject.iogroupproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IoGroupProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
