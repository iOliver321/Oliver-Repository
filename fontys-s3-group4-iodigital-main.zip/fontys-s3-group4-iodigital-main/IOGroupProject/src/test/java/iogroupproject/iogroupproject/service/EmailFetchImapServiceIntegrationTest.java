package iogroupproject.iogroupproject.service;

import iogroupproject.iogroupproject.dto.EmailDataDTO;
import jakarta.mail.internet.MimeMessage;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Integration tests for EmailFetchImapService which uses a short-lived Store
 * (opening and closing IMAP connection inside fetchSentEmails()).
 * Prerequisites:
 *   - EMAIL_USERNAME and EMAIL_PASSWORD must be set as environment variables.
 *   - "[Gmail]/Sent Mail" should have at least one message if you want the basic fetch test to pass.
 */
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
class EmailFetchImapServiceIntegrationTest {

    private EmailFetchImapService emailFetchImapService;

    @BeforeAll
    void setUp() {
        System.out.println("--------------------");
        System.out.println("Beginning `setUp()`...");

        // 1. Retrieve credentials from env variables
        String emailUsername = System.getenv("EMAIL_USERNAME");
        String emailPassword = System.getenv("EMAIL_PASSWORD");

        // 2. If these are missing, skip the tests
        Assumptions.assumeTrue(
                emailUsername != null && !emailUsername.isBlank() &&
                        emailPassword != null && !emailPassword.isBlank(),
                "EMAIL_USERNAME and/or EMAIL_PASSWORD env vars are not set. Skipping real IMAP integration tests."
        );

        // 3. Instantiate the service (short-lived store approach)
        //    No constructor arguments, because the service itself calls getEnv() inside fetchSentEmails().
        emailFetchImapService = new EmailFetchImapService();

        System.out.println("`setUp()` complete.");
        System.out.println("--------------------");
    }

    @AfterAll
    void tearDown() {
        System.out.println("--------------------");
        System.out.println("Beginning `tearDown()`...");
        // No store to close manually here, because we use a short-lived store in the service.
        System.out.println("`tearDown()` complete.");
        System.out.println("--------------------");
    }

    @Test
    @DisplayName("Should fetch at least one email from Sent folder (if your mailbox has sent items)")
    void testFetchSentEmails_basic() {
        System.out.println("--------------------");
        System.out.println("Running test: `testFetchSentEmails_basic()`...");

        // By default, fetchSentEmails() uses "[Gmail]/Sent Mail".
        List<EmailDataDTO> emails = emailFetchImapService.fetchSentEmails();

        // If your real mailbox truly has no sent items, this test will fail.
        assertFalse(emails.isEmpty(), "Expected at least one email in the Sent folder, but got none.");
        System.out.println("Fetched " + emails.size() + " emails from Sent folder.");

        System.out.println("testFetchSentEmails_basic() complete.");
        System.out.println("--------------------");
    }

    /**
     * Checks behavior when the folder is set to something invalid.
     */
    @Test
    @DisplayName("Should handle a non-existent folder gracefully (edge case)")
    void testFetchFromNonExistentFolder() {
        System.out.println("--------------------");
        System.out.println("Running test: `testFetchFromNonExistentFolder()`...");

        // Temporarily override folder name to something that won't exist
        emailFetchImapService.setFolderName("NonExistentFolder123");

        List<EmailDataDTO> emails = emailFetchImapService.fetchSentEmails();
        // If the service catches an exception, hopefully it returns an empty list
        assertTrue(emails.isEmpty(), "Expected empty list if the folder does not exist.");

        System.out.println("testFetchFromNonExistentFolder() complete.");
        System.out.println("--------------------");
    }

    /**
     * Illustrates an 'empty mailbox' scenario, if you truly had a folder with zero messages.
     */
    @Test
    @DisplayName("Edge Case: handle empty mailbox (or empty folder)")
    void testEmptyMailbox() {
        System.out.println("--------------------");
        System.out.println("Running test: `testEmptyMailbox()`...");

        // If you actually have an empty folder, use that name here.
        // For demonstration, we just use "EmptyTestFolder123" to show the logic.
        emailFetchImapService.setFolderName("EmptyTestFolder123");

        List<EmailDataDTO> emails = emailFetchImapService.fetchSentEmails();
        assertNotNull(emails, "Should not be null even if the folder is empty/invalid.");
        assertEquals(0, emails.size(), "Should return an empty list if there are no emails in that folder.");

        System.out.println("testEmptyMailbox() complete.");
        System.out.println("--------------------");
    }

    @Nested
    @DisplayName("Tests involving real emails that contain or do not contain the expected body patterns")
    class BodyParsingTests {

        @Test
        @DisplayName("Should parse occupant/capacity data if body follows the expected pattern")
        void testBodyParsing_correctPattern() {
            System.out.println("--------------------");
            System.out.println("Running test: `testBodyParsing_correctPattern()`...");

            // Reset to the default folder (Sent Mail)
            emailFetchImapService.setFolderName("[Gmail]/Sent Mail");
            List<EmailDataDTO> emails = emailFetchImapService.fetchSentEmails();

            // Look for a subject containing "Room Underutilization Alert"
            EmailDataDTO matched = null;
            for (EmailDataDTO dto : emails) {
                if (dto.getSubject() != null && dto.getSubject().contains("Room Underutilization Alert")) {
                    matched = dto;
                    break;
                }
            }

            assertNotNull(matched,
                    "No email found in Sent that contains the 'Room Underutilization Alert' subject. "
                            + "Ensure you have sent such a test email to yourself.");

            // If your real test email body mentions something like:
            //  "room 'TestRoomA' currently has only 2 occupant(s). The room capacity is 5."
            //  then your service's regex extraction should set:
            //      roomName, currentOccupants, maxCapacity
            assertNotNull(matched.getRoomName(), "Expected a roomName to be parsed from the body, but it was null.");
            assertTrue(matched.getCurrentOccupants() > 0, "Expected currentOccupants to be > 0.");
            assertTrue(matched.getMaxCapacity() > 0, "Expected maxCapacity to be > 0.");

            System.out.printf(
                    "Parsed from email: roomName=%s, current=%d, max=%d%n",
                    matched.getRoomName(),
                    matched.getCurrentOccupants(),
                    matched.getMaxCapacity()
            );

            System.out.println("testBodyParsing_correctPattern() complete.");
            System.out.println("--------------------");
        }

        @Test
        @DisplayName("Should handle partial/malformed body that doesn't match all patterns")
        void testBodyParsing_partialPattern() {
            System.out.println("--------------------");
            System.out.println("Running test: `testBodyParsing_partialPattern()`...");

            // Set folder back to the default (or any other you want)
            emailFetchImapService.setFolderName("[Gmail]/Sent Mail");
            List<EmailDataDTO> emails = emailFetchImapService.fetchSentEmails();

            // Suppose we have a partial body email with subject "Partial Body Test"
            EmailDataDTO matched = null;
            for (EmailDataDTO dto : emails) {
                if (dto.getSubject() != null && dto.getSubject().contains("Partial Body Test")) {
                    matched = dto;
                    break;
                }
            }

            assertNotNull(matched,
                    "No email found in Sent that has the subject 'Partial Body Test'. "
                            + "Please send a test email with partial info to yourself.");

            // If the body is missing occupant or capacity info, the code might leave them at 0
            assertEquals(0, matched.getCurrentOccupants(),
                    "If occupant count wasn't in the body, we expect the default 0.");
            assertEquals(0, matched.getMaxCapacity(),
                    "If capacity wasn't in the body, we expect default 0 or some fallback.");

            System.out.println("testBodyParsing_partialPattern() complete.");
            System.out.println("--------------------");
        }
    }

    /**
     * Optional test to demonstrate reflection usage on the private method.
     * This is less relevant now since the method is called inside fetchSentEmails().
     */
    @Test
    @DisplayName("Demonstrate reflection call to private parse method (Optional)")
    void testPrivateParsingMethodViaReflection() throws Exception {
        System.out.println("--------------------");
        System.out.println("Running test: `testPrivateParsingMethodViaReflection()`...");

        // We'll just fetch from Sent folder (short-lived store).
        // Then pick the first message (if any) and reflection-call extractEmailDataDTO(...)
        List<EmailDataDTO> emails = emailFetchImapService.fetchSentEmails();
        if (emails.isEmpty()) {
            System.out.println("No messages found in the Sent folder. Skipping reflection test.");
            return;
        }

        // For reflection, we need an actual MimeMessage to pass in. However, your short-lived approach
        // doesn't store the messages. We'll just demonstrate how you might do it:
        var method = EmailFetchImapService.class.getDeclaredMethod("extractEmailDataDTO", MimeMessage.class);
        method.setAccessible(true);

        // In a real test, you'd have to open the Store again or modify fetchSentEmails to return the raw Message[].
        // We'll do a conceptual example:
        System.out.println("Reflection test is conceptual unless you modify fetchSentEmails() to return a raw MimeMessage.");

        System.out.println("testPrivateParsingMethodViaReflection() complete.");
        System.out.println("--------------------");
    }
}
