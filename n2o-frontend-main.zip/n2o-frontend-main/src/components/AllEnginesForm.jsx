import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import EngineService from "../API/EngineService";
import '../Design/AllEnginesForm.css'; // Import the CSS file

const AllEnginesForm = ({ claims }) => { // Receive claims as props
  const navigate = useNavigate(); // Initialize the navigate function
  const [engines, setEngines] = useState([]);
  const [filters, setFilters] = useState({
    code: "",
    capacity: "",
    cylinders: "",
    fuelType: "",
  });
  const [showAll, setShowAll] = useState(false);

  const fetchEngines = async () => {
    try {
      const response = await EngineService.fetchEngines();
      setEngines(response);
    } catch (error) {
      console.error("Error fetching engines", error);
    }
  };

  useEffect(() => {
    fetchEngines();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const filteredEngines = engines.filter((engine) => {
    return (
      (filters.code ? engine.code.includes(filters.code) : true) &&
      (filters.capacity ? engine.capacity.toString().includes(filters.capacity) : true) &&
      (filters.cylinders ? engine.cylinders.toString().includes(filters.cylinders) : true) &&
      (filters.fuelType ? engine.fuelType.includes(filters.fuelType) : true)
    );
  });

  const handleShowAll = () => {
    setShowAll(!showAll);
  };

  const handleEditClick = (engine) => {
    if (claims && claims.roles.includes('ADMIN')) { // Check if user is an admin
      navigate(`/engine`, { state: { existingEngine: engine } }); // Navigate and pass engine data
    } else {
      alert("You do not have permission to edit engines.");
    }
  };

  return (
    <div className="all-engines-container">
      <div className="all-engines-header">
        <h2>Engine List</h2>
      </div>
      <div className="all-engines-filters">
        <input
          type="text"
          name="code"
          value={filters.code}
          onChange={handleFilterChange}
          placeholder="Filter by Code"
        />
        <input
          type="text"
          name="capacity"
          value={filters.capacity}
          onChange={handleFilterChange}
          placeholder="Filter by Capacity"
        />
        <input
          type="text"
          name="cylinders"
          value={filters.cylinders}
          onChange={handleFilterChange}
          placeholder="Filter by Cylinders"
        />
        <input
          type="text"
          name="fuelType"
          value={filters.fuelType}
          onChange={handleFilterChange}
          placeholder="Filter by Fuel Type"
        />
        <button className="all-engines-button" onClick={handleShowAll}>
          {showAll ? "Hide All Engines" : "Show All Engines"}
        </button>
      </div>
      {showAll && (
        <ul className="engines-list">
          {(filteredEngines.length > 0 ? filteredEngines : engines).map((engine, index) => (
            <li key={index}>
              {engine.code} - {engine.capacity} cc - {engine.cylinders} Cylinders - {engine.fuelType}
              <button onClick={() => handleEditClick(engine)}>Edit</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AllEnginesForm;
