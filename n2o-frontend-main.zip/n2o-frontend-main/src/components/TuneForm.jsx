import React, { useState } from "react";
import TuneService from "../API/TuneService";
import '../Design/TuneForm.css';

const TuneForm = ({ existingTune, onSubmit }) => {
  const [tune, setTune] = useState({
    engineCode: existingTune?.engine?.code || "",
    stockHorsepower: existingTune?.stockHorsepower || "",
    stockTorque: existingTune?.stockTorque || "",
    tunedHorsepower: existingTune?.tunedHorsepower || "",
    tunedTorque: existingTune?.tunedTorque || "",
    price: existingTune?.price || "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setTune((prevTune) => ({
      ...prevTune,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (existingTune) {
        await TuneService.updateTune(tune);
      } else {
        await TuneService.createTune(tune);
      }
      onSubmit();
    } catch (error) {
      console.error("Error submitting the tune form", error);
    }
  };

  return (
    <div className="tune-form-container">
      <div className="tune-form-header">
        <h1>{existingTune ? "Edit Tune" : "Create Tune"}</h1>
      </div>
      <form className="tune-form" onSubmit={handleSubmit}>
        <div>
          <label htmlFor="engineCode">Engine Code:</label>
          <input
            type="text"
            id="engineCode"
            name="engineCode"
            value={tune.engineCode}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="stockHorsepower">Stock Horsepower:</label>
          <input
            type="number"
            id="stockHorsepower"
            name="stockHorsepower"
            value={tune.stockHorsepower}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="stockTorque">Stock Torque:</label>
          <input
            type="number"
            id="stockTorque"
            name="stockTorque"
            value={tune.stockTorque}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="tunedHorsepower">Tuned Horsepower:</label>
          <input
            type="number"
            id="tunedHorsepower"
            name="tunedHorsepower"
            value={tune.tunedHorsepower}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="tunedTorque">Tuned Torque:</label>
          <input
            type="number"
            id="tunedTorque"
            name="tunedTorque"
            value={tune.tunedTorque}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="price">Price:</label>
          <input
            type="number"
            id="price"
            name="price"
            value={tune.price}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">{existingTune ? "Update Tune" : "Create Tune"}</button>
      </form>
    </div>
  );
};

export default TuneForm;
