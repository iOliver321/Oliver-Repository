import React, { useState } from "react";
import CarService from "../API/CarService";
import '../Design/CarForm.css';

const CarForm = ({ existingCar, onSubmit }) => {
  const [car, setCar] = useState({
    brand: existingCar?.brand || "",
    name: existingCar?.name || "",
    year: existingCar?.year || "",
    engineCode: existingCar?.engineCode || "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setCar((prevCar) => ({
      ...prevCar,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (existingCar) {
        await CarService.updateCar(car);
      } else {
        await CarService.createCar(car);
      }
      onSubmit(); // Callback function when submission is successful
    } catch (error) {
      console.error("Error submitting the car form", error);
    }
  };

  return (
    <div className="car-form-container">
      <div className="car-form-header">
        <h1>{existingCar ? "Edit Car" : "Create Car"}</h1>
      </div>
      <form className="car-form" onSubmit={handleSubmit}>
        <div>
          <label htmlFor="brand">Car Brand:</label>
          <input
            type="text"
            id="brand"
            name="brand"
            value={car.brand}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="name">Car Name:</label>
          <input
            type="text"
            id="name"
            name="name"
            value={car.name}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="year">Year:</label>
          <input
            type="number"
            id="year"
            name="year"
            value={car.year}
            onChange={handleChange}
          />
        </div>
        <div>
          <label htmlFor="engineCode">Engine Code:</label>
          <input
            type="text"
            id="engineCode"
            name="engineCode"
            value={car.engineCode}
            onChange={handleChange}
            required
          />
        </div>
        <button type="submit">{existingCar ? "Update Car" : "Create Car"}</button>
      </form>
    </div>
  );
};

export default CarForm;
