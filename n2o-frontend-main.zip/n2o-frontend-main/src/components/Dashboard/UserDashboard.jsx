import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../../Design/UserDashboard.css';

const UserDashboard = ({ handleLogout }) => {
  const navigate = useNavigate();

  const handleSearchCars = () => {
    navigate('/cars'); // Navigate to the AllCarsForm
  };

  return (
    <div className="dashboard-container">
      <div className="dashboard-header">
        <h1>Welcome back, User!</h1>
      </div>
      <div className="dashboard-content">
        <p>This is your dashboard where you can access your features.</p>
        <div className="search-cars">
          <input
            type="text"
            placeholder="Search for your car..."
            onFocus={handleSearchCars} // Navigate to cars when focused
          />
        </div>
      </div>
      <button className="dashboard-button" onClick={handleLogout}>Logout</button>
    </div>
  );
};

export default UserDashboard; 