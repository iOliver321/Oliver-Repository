import React from 'react';
import { useNavigate } from 'react-router-dom';
import '../../Design/AdminDashboard.css';

const AdminDashboard = ({ handleLogout }) => {
  const navigate = useNavigate();

  const handleManageEngines = () => {
    navigate('/engines');
  };

  const handleManageCars = () => {
    navigate('/cars');
  };

  const handleManageTunes = () => {
    navigate('/tunes');
  };

  return (
    <div className="admin-dashboard-container">
      <div className="admin-dashboard-header">
        <h1>You are logged in as an Admin</h1>
      </div>
      <div className="admin-dashboard-content">
        <p>This is your admin dashboard where you can manage users and settings.</p>
        <button className="admin-dashboard-button" onClick={handleLogout}>Logout</button>
        <p>This is where you manage engines:</p>
        <button className="admin-dashboard-button" onClick={handleManageEngines}>
          Manage Engines
        </button>
        <p>This is where you manage cars:</p>
        <button className="admin-dashboard-button" onClick={handleManageCars}>
          Manage Cars
        </button>
        <p>This is where you manage tunes:</p>
        <button className="admin-dashboard-button" onClick={handleManageTunes}>
          Manage Tunes
        </button>
      </div>
    </div>
  );
};

export default AdminDashboard; 