import React, { useState } from "react";
import EngineService from "../API/EngineService";
import '../Design/EngineForm.css';

const EngineForm = ({ existingEngine, onSubmit }) => {
  const [engine, setEngine] = useState({
    code: existingEngine?.code || "",
    capacity: existingEngine?.capacity || "",
    cylinders: existingEngine?.cylinders || "",
    fuelType: existingEngine?.fuelType || "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setEngine((prevEngine) => ({
      ...prevEngine,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      if (existingEngine) {
        await EngineService.updateEngine(engine);
      } else {
        await EngineService.createEngine(engine);
      }
      onSubmit(); // Callback function when submission is successful
    } catch (error) {
      console.error("Error submitting the engine form", error);
    }
  };

  return (
    <div className="engine-form-container">
      <div className="engine-form-header">
        <h1>{existingEngine ? "Edit Engine" : "Create Engine"}</h1>
      </div>
      <form className="engine-form" onSubmit={handleSubmit}>
        <div>
          <label htmlFor="code">Engine Code:</label>
          <input
            type="text"
            id="code"
            name="code"
            value={engine.code}
            onChange={handleChange}
            required
          />
        </div>
        <div>
          <label htmlFor="capacity">Capacity (cc):</label>
          <input
            type="number"
            id="capacity"
            name="capacity"
            value={engine.capacity}
            onChange={handleChange}
          />
        </div>
        <div>
          <label htmlFor="cylinders">Cylinders:</label>
          <input
            type="number"
            id="cylinders"
            name="cylinders"
            value={engine.cylinders}
            onChange={handleChange}
          />
        </div>
        <div>
          <label htmlFor="fuelType">Fuel Type:</label>
          <input
            type="text"
            id="fuelType"
            name="fuelType"
            value={engine.fuelType}
            onChange={handleChange}
          />
        </div>
        <button type="submit">{existingEngine ? "Update Engine" : "Create Engine"}</button>
      </form>
    </div>
  );
};

export default EngineForm;
