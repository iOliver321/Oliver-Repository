import React from 'react';
import { Link } from 'react-router-dom';
import '../Design/NavBar.css';

const NavBar = ({ searchTerm, setSearchTerm }) => {
  const handleSearch = (event) => {
    event.preventDefault();
    console.log("Searching for car:", searchTerm);
    // Implement search functionality here
  };

  return (
    <nav className="navbar">
      <div className="nav-links">
        <Link to="/">Home</Link>
        <Link to="/signup">Sign Up</Link>
        <Link to="/tunes">Available Tunes</Link>
        <Link to="/engines">All Engines</Link>
        <Link to="/cars">All Cars</Link>
      </div>
    </nav>
  );
};

export default NavBar; 