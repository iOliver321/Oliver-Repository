import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom"; // Import useNavigate
import CarService from "../API/CarService";
import '../Design/AllCarsForm.css';

const AllCarsForm = ({ claims }) => {
  const navigate = useNavigate(); // Initialize the navigate function
  const [cars, setCars] = useState([]);
  const [filters, setFilters] = useState({
    brand: "",
    name: "",
    year: "",
  });
  const [showAll, setShowAll] = useState(false);

  const fetchCars = async () => {
    try {
      const response = await CarService.fetchCars();
      setCars(response);
    } catch (error) {
      console.error("Error fetching cars", error);
    }
  };

  useEffect(() => {
    fetchCars();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const filteredCars = cars.filter((car) => {
    return (
      (filters.brand ? car.brand.includes(filters.brand) : true) &&
      (filters.name ? car.name.includes(filters.name) : true) &&
      (filters.year ? car.year.toString().includes(filters.year) : true)
    );
  });

  const handleShowAll = () => {
    setShowAll(!showAll);
  };

  const handleEditClick = (car) => {
    if (claims && claims.roles.includes('ADMIN')) { // Check if user is an admin
      navigate(`/car`, { state: { existingCar: car } }); // Navigate and pass car data
    } else {
      alert("You do not have permission to edit cars.");
    }
  };

  return (
    <div className="all-cars-container">
      <div className="all-cars-header">
        <h2>Car List</h2>
      </div>
      <div className="all-cars-filters">
        <input
          type="text"
          name="brand"
          value={filters.brand}
          onChange={handleFilterChange}
          placeholder="Filter by Brand"
        />
        <input
          type="text"
          name="name"
          value={filters.name}
          onChange={handleFilterChange}
          placeholder="Filter by Name"
        />
        <input
          type="text"
          name="year"
          value={filters.year}
          onChange={handleFilterChange}
          placeholder="Filter by Year"
        />
        <button className="all-cars-button" onClick={handleShowAll}>
          {showAll ? "Hide All Cars" : "Show All Cars"}
        </button>
      </div>
      {showAll && (
        <ul className="cars-list">
          {(filteredCars.length > 0 ? filteredCars : cars).map((car, index) => (
            <li key={index}>
              {car.brand} - {car.name} - {car.year} - Engine: {car.engine.code} ({car.engine.capacity} cc, {car.engine.cylinders} Cylinders, {car.engine.fuelType})
              <button onClick={() => handleEditClick(car)}>Edit</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AllCarsForm;
