import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import TuneService from "../API/TuneService";
import '../Design/AllTunesForm.css';

const AllTunesForm = ({ claims }) => {
  const navigate = useNavigate();
  const [tunes, setTunes] = useState([]);
  const [filters, setFilters] = useState({
    title: "",
    artist: "",
    engineCode: "",
  });
  const [showAll, setShowAll] = useState(false);

  const fetchTunes = async () => {
    try {
      const response = await TuneService.fetchTunes();
      setTunes(response.tuneList);
    } catch (error) {
      console.error("Error fetching tunes", error);
    }
  };

  useEffect(() => {
    fetchTunes();
  }, []);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters({ ...filters, [name]: value });
  };

  const filteredTunes = tunes.filter((tune) => {
    return (
      (filters.title ? tune.title.includes(filters.title) : true) &&
      (filters.artist ? tune.artist.includes(filters.artist) : true) &&
      (filters.engineCode ? tune.engine.code.includes(filters.engineCode) : true)
    );
  });

  const handleShowAll = () => {
    setShowAll(!showAll);
  };

  const handleEditClick = (tune) => {
    if (claims && claims.roles.includes('ADMIN')) {
      navigate(`/tune`, { state: { existingTune: tune } });
    } else {
      alert("You do not have permission to edit tunes.");
    }
  };

  return (
    <div className="all-tunes-container">
      <div className="all-tunes-header">
        <h2>Tune List</h2>
      </div>
      <div className="all-tunes-filters">
        <input
          type="text"
          name="title"
          value={filters.title}
          onChange={handleFilterChange}
          placeholder="Filter by Title"
        />
        <input
          type="text"
          name="artist"
          value={filters.artist}
          onChange={handleFilterChange}
          placeholder="Filter by Artist"
        />
        <input
          type="text"
          name="engineCode"
          value={filters.engineCode}
          onChange={handleFilterChange}
          placeholder="Filter by Engine Code"
        />
        <button className="all-tunes-button" onClick={handleShowAll}>
          {showAll ? "Hide All Tunes" : "Show All Tunes"}
        </button>
      </div>
      {showAll && (
        <ul className="tunes-list">
          {(filteredTunes.length > 0 ? filteredTunes : tunes).map((tune, index) => (
            <li key={index}>
              Engine: {tune.engine.code} - Stock HP: {tune.stockHorsepower} - Tuned HP: {tune.tunedHorsepower} - Price: ${tune.price}
              <button onClick={() => handleEditClick(tune)}>Edit</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default AllTunesForm;
