import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import TokenManager from '../API/TokenManager';
import AuthAPI from '../API/AuthAPI';
import SignUpAPI from '../API/SignUpAPI';
import { toast, ToastContainer } from 'react-toastify';
import NavBar from './NavBar';
import AdminDashboard from './Dashboard/AdminDashboard';
import UserDashboard from './Dashboard/UserDashboard';
import SignUpForm from './Auth/SignUpForm';
import LoginForm from './Auth/LoginForm';
import AllEnginesForm from './AllEnginesForm';
import EngineForm from './EngineForm';
import AllCarsForm from './AllCarsForm';
import CarForm from './CarForm';
import AllTunesForm from './AllTunesForm';
import TuneForm from './TuneForm';
import { Client } from '@stomp/stompjs';
import '../Design/app.css';

const App = () => {
  const [claims, setClaims] = useState(TokenManager.getClaims());
  const [searchTerm, setSearchTerm] = useState('');
  let stompClient = null;

  useEffect(() => {
    const setupStompClient = () => {
      const client = new Client({
        brokerURL: 'ws://localhost:8080/ws',
        reconnectDelay: 5000,
        heartbeatIncoming: 4000,
        heartbeatOutgoing: 4000,
      });

      client.onConnect = () => {
        client.subscribe('/update', (message) => {
            const notification = JSON.parse(message.body);
            toast.info(notification.text); // Display the notification
        });
    };

      client.activate();
      stompClient = client;
      console.log("STOMP client activated");
       
    };

    setupStompClient();

    const storedToken = TokenManager.getAccessToken();
    if (storedToken) {
      TokenManager.setAccessToken(storedToken);
      const storedClaims = JSON.parse(sessionStorage.getItem('claims'));
      setClaims(storedClaims);
    }

    return () => {
      if (stompClient) {
        stompClient.deactivate();
      }
    };
  }, []);

  const handleLogin = async (username, password) => {
    try {
      const claims = await AuthAPI.login(username, password);
      setClaims(claims);
    } catch (error) {
      alert("Login failed!");
      console.error(error);
    }
  };

  const handleSignUp = async (username, password, postalcode) => {
    try {
      await SignUpAPI.signup(username, password, postalcode);
      alert("Signup successful!");
    } catch (error) {
      console.error("Signup failed:", error);
      alert("Signing up Failed. Check Postal Code!");
    }
  };

  const handleLogout = () => {
    TokenManager.clear();
    setClaims(null);
  };

  return (
    <div className="container">
      <NavBar searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
      <Routes>
        <Route path="/" element={claims ? (claims.roles.includes('ADMIN') ? <AdminDashboard handleLogout={handleLogout} /> : <UserDashboard handleLogout={handleLogout} />) : <LoginForm onLogin={handleLogin} />} />
        <Route path="/signup" element={<SignUpForm onSignUp={handleSignUp} />} />
        <Route path="/engines" element={<AllEnginesForm claims={claims} />} />
        <Route path="/engine" element={<EngineForm />} />
        <Route path="/cars" element={<AllCarsForm claims={claims} />} />
        <Route path="/car" element={<CarForm claims={claims} />} />
        <Route path="/tunes" element={<AllTunesForm claims={claims} />} />
        <Route path="/tune" element={<TuneForm claims={claims} />} />
      </Routes>
      <ToastContainer />
    </div>
  );
};

export default App; 