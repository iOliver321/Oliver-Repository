import axios from "axios";
import TokenManager from "./TokenManager";

const AuthAPI = {
  login: async (username, password) => {
    const response = await axios.post('http://localhost:8080/tokens', { username, password });
    return TokenManager.setAccessToken(response.data.accessToken);
  },
  isAuthenticated: () => !!TokenManager.getAccessToken(),
  getStoredToken: () => TokenManager.getAccessToken(),
  logout: () => TokenManager.clear(),
};

export default AuthAPI; 