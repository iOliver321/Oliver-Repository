import axios from 'axios';
import TokenManager from './TokenManager.jsx';

const baseURL = 'http://localhost:8080';

class CarService {
    static async fetchCars() {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: {
                     Authorization: `Bearer ${token}` 
                },
            };
            const response = await axios.get(`${baseURL}/car`, config);
            return response.data; // Adjust based on your API response structure
        } catch (error) {
            console.error('Error getting the Cars', error);
            throw error;
        }
    }

    static async createCar(newCar) {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: { Authorization: `Bearer ${token}` },
            };
            const response = await axios.post(`${baseURL}/car`, newCar, config);
            return response.data;
        } catch (error) {
            console.error("Error creating car", error);
            throw error;
        }
    }

    static async updateCar(updatedCar) {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: { Authorization: `Bearer ${token}` },
            };
            const response = await axios.put(`${baseURL}/car`, updatedCar, config);
            return response.data;
        } catch (error) {
            console.error("Error updating car", error);
            throw error;
        }
    }
}

export default CarService;
