import axios from 'axios';
import TokenManager from "./TokenManager.jsx";

const baseURL = "http://localhost:8080";

class EngineService{
    static async createEngine(newEngine){
        try{
            const token = TokenManager.getAccessToken();
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };

            const response = await axios.post(baseURL + "/engine", newEngine, config);
            return response.data;
        }catch(error){
            console.error("Error creating Engine", error);
            throw error;
        }
    }

    static async updateEngine(updatedEngine){
        try{

            const token = TokenManager.getAccessToken();
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };

            const response = await axios.put(baseURL + "/engine", updatedEngine, config);
            return response.data;            

        }catch(error){
            console.error("Error updating engine");
        }
    }

    static async fetchEngines() {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: { Authorization: `Bearer ${token}` },
            };
            const response = await axios.get(baseURL + "/engine", config);
            console.log("Fetched engine list:", response.data.engineList); // Check if engineList is an array
            return response.data.engineList;
        } catch (error) {
            console.error("Error getting the Engines", error);
            throw error;
        }
    }
    
    
}
 export default EngineService;