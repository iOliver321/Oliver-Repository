import axios from 'axios';
import TokenManager from './TokenManager.jsx';

const baseURL = 'http://localhost:8080';

class TuneService {
    static async fetchTunes() {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: {
                    Authorization: `Bearer ${token}` 
                },
            };
            const response = await axios.get(`${baseURL}/tune`, config);
            return response.data;
        } catch (error) {
            console.error('Error getting the Tunes', error);
            throw error;
        }
    }

    static async createTune(newTune) {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: { Authorization: `Bearer ${token}` },
            };
            const response = await axios.post(`${baseURL}/tune`, newTune, config);
            return response.data;
        } catch (error) {
            console.error("Error creating tune", error);
            throw error;
        }
    }

    static async updateTune(updatedTune) {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: { Authorization: `Bearer ${token}` },
            };
            const response = await axios.put(`${baseURL}/tune`, updatedTune, config);
            return response.data;
        } catch (error) {
            console.error("Error updating tune", error);
            throw error;
        }
    }

    static async deleteTune(code) {
        try {
            const token = TokenManager.getAccessToken();
            const config = {
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            };

            const response = await axios.delete(`${baseURL}/tune/${code}`, config);
            return response.data;
        } catch (error) {
            console.error('Error deleting tune', error);
            throw error;
        }
    }
}

export default TuneService;
