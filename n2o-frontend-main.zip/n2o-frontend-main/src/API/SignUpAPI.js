import axios from "axios";

const SignUpAPI = {
  signup: async (username, password, postalcode) => {
    const response = await axios.post('http://localhost:8080/signup', { username, password, postalcode });
    return response.data;
  },
};

export default SignUpAPI; 