import jwt_decode from "jwt-decode";

const storageKey = "accessToken";

const TokenManager = {
  getAccessToken: () => sessionStorage.getItem(storageKey),
  setAccessToken: (token) => {
    sessionStorage.setItem(storageKey, token);
    return jwt_decode(token);
  },
  getClaims: () => {
    const token = TokenManager.getAccessToken();
    return token ? jwt_decode(token) : null;
  },
  clear: () => sessionStorage.removeItem(storageKey),
};

export default TokenManager; 