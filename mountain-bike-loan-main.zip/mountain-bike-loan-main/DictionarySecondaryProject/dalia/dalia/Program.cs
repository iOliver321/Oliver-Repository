﻿using System;
using System.ComponentModel;

namespace ProgramDalia
{
    public class Bicicleta
    {
        string marime;
        bool suspensie;
        string frane;

        public Bicicleta(string marime, bool suspensie, string frane)
        {
            this.marime = marime;
            this.suspensie = suspensie;
            this.frane = frane;
        }

        public string Marime()
        {
            return this.marime;
        }

        public bool Suspensie()
        {
            return this.suspensie;
        }

        public string Frane()
        {
            return this.frane;
        }
    }

    public class Program
    {
        public static void Main(string[] args)
        {
            List<string> list_de_nume = new List<string>();

            list_de_nume.Add("Dalia");
            list_de_nume.Add("Oliver");
            list_de_nume.Add("Petrica");
            list_de_nume.Add("Vasile");

            foreach (string nume in list_de_nume)
            {
                Console.WriteLine(nume);
            }
            
        }
    }
}
