﻿using System;
using System.Text.RegularExpressions;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Enter an email address:");
        string input = Console.ReadLine();

        // Define regular expression pattern for email addresses
        string emailPattern = @"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b";

        // Create a Regex object with the pattern
        Regex emailRegex = new Regex(emailPattern);

        // Check if the input matches the email pattern
        bool isValidEmail = emailRegex.IsMatch(input);

        // Display the result
        if (isValidEmail)
        {
            Console.WriteLine("Valid email address.");
        }
        else
        {
            Console.WriteLine("Invalid email address.");
        }
    }
}
