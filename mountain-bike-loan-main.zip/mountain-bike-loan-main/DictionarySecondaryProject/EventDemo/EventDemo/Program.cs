﻿using System;

namespace EventDemo
{
    public class InputEventArgs : EventArgs
    {
        public string Input { get; }

        public InputEventArgs(string input)
        {
            Input = input;
        }
    }

    public class Teacher
    {
        public event EventHandler<InputEventArgs> InputReceived;

        public void Teach()
        {
            Console.WriteLine("Teaching in progress...");
            Console.WriteLine("Enter your input:");

            string input = Console.ReadLine();

            OnInputReceived(new InputEventArgs(input));

            Console.WriteLine("Teaching done!");
        }

        protected virtual void OnInputReceived(InputEventArgs e)
        {
            InputReceived?.Invoke(this, e);
        }
    }

    public class Program
    {
        private static void Teacher_InputReceived(object sender, InputEventArgs e)
        {
            Console.WriteLine("Input received: " + e.Input);
        }

        public static void Main(string[] args)
        {
            Teacher teacher = new Teacher();
            teacher.InputReceived += Teacher_InputReceived;

            teacher.Teach();

            Console.ReadLine();
        }
    }
}
