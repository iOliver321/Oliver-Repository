namespace Dictionary
{
    public partial class Form1 : Form
    {
        Dictionary cmd = new Dictionary();
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.Clear();
            Dictionary<string, int> ages = cmd.return_ages();
            foreach (string name in ages.Keys)
            {
                comboBox1.Items.Add(name);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dictionary<string, int> ages = cmd.return_ages();
            int age = ages[comboBox1.SelectedItem.ToString()];
            MessageBox.Show(Convert.ToString(age));
        }
    }
}