﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionary
{
    class Dictionary
    {
        Dictionary<string, int> ages = new Dictionary<string, int>();

        public Dictionary()
        {
            ages["John"] = 25;
            ages["Alice"] = 30;
            ages["Bob"] = 35;
        }

        public Dictionary<string, int> return_ages()
        {
            return ages;
        }
    }
}
