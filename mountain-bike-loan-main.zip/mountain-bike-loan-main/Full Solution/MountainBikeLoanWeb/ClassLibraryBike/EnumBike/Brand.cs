﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Classes.EnumBike
{
    public enum Brand
    {
        SANTA_CRUZ,
        CANYON,
        TREK,
        CANNONDALE,
        PIVOT,
        YT_INDUSTRIES,
        GT_BIKES,

        //for unit testing:
        Brand1,
        Brand2,
        Brand3,
    }
}
