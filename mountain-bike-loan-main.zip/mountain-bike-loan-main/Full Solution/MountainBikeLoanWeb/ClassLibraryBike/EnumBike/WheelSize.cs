﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Classes.EnumBike
{
    public enum WheelSize
    {
        SIZE26,
        SIZE27_5,
        SIZE29,

        //for unit testing:
        Size1,
        Size2,
        Size3,
    }
}
