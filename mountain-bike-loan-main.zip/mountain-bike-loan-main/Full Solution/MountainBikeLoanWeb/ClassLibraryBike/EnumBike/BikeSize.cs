﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Classes.EnumBike
{
    public enum BikeSize
    {
        XS,
        S,
        M,
        L,
        XL,

        //for unit testing:
        Size1,
        Size2,
        Size3,
    }
}
