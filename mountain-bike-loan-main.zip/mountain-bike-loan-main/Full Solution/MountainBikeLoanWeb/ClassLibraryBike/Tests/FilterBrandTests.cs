﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Interfaces;
using BusinessLayer.Managers.Filters;
using BusinessLayer.Object;
using NUnit.Framework;
using System.Collections.Generic;

namespace BusinessLayer.Tests
{
    [TestFixture]
    public class FilterBrandTests
    {
        [Test]
        public void ReturnFilteredBikes_ShouldReturnFilteredBikesByBrand()
        {
            // Arrange
            IBikeDataInterface bikeData = new FakeDependency();

            var bikes = bikeData.GetXCList();
            bikes.AddRange(bikeData.GetDownhillList());
            bikes.AddRange(bikeData.GetTrailList());
            bikes.AddRange(bikeData.GetEnduroList());

            var filter = new filter_brand(bikeData, "TREK");
            var expectedBike = bikes[2];

            // Act
            var filteredBikes = filter.return_filtered_bikes();

            // Assert
            Assert.AreEqual(1, filteredBikes.Count);
            Assert.AreEqual(expectedBike, filteredBikes[0]);
        }
    }

    public class FakeDependency : IBikeDataInterface
    {
        public List<Bike> GetDownhillList()
        {
            List<Bike> bikes = new List<Bike>();
            Bike bike1 = new Bike
            {
                ID = 1,
                status = "Available",
                b = Brand.SANTA_CRUZ,
                s = BikeSize.M,
                wheels = WheelSize.SIZE27_5,
                name = "Bike 1",
                price = 1000
            };
            bikes.Add(bike1);

            return bikes;
        }
        public List<Bike> GetEnduroList()
        {
            List<Bike> bikes = new List<Bike>();

            Bike bike3 = new Bike
            {
                ID = 3,
                status = "Available",
                b = Brand.TREK,
                s = BikeSize.S,
                wheels = WheelSize.SIZE29,
                name = "Bike 3",
                price = 1200
            };
            bikes.Add(bike3);

            return bikes;
        }
        public List<Bike> GetTrailList()
        {
            List<Bike> bikes = new List<Bike>();

            Bike bike2 = new Bike
            {
                ID = 2,
                status = "Booked",
                b = Brand.CANYON,
                s = BikeSize.L,
                wheels = WheelSize.SIZE29,
                name = "Bike 2",
                price = 1500
            };
            bikes.Add(bike2);

            return bikes;
        }
        public List<Bike> GetXCList()
        {
            List<Bike> bikes = new List<Bike>();

            var bike4 = new Bike
            {
                ID = 4,
                status = "Available",
                b = Brand.Brand3,
                s = BikeSize.S,
                wheels = WheelSize.SIZE29,
                name = "Bike 4",
                price = 1200
            };
            bikes.Add(bike4);  

            return bikes;
        }

        public bool CreateBike(string type, string brand, int bikesize, int wheelsize, string name, int price, bool yesus)
        {
            return true;
        }

        public bool UpdateBikeStatus(int bike_id, string status)
        {
            return true;
        }

        public bool UpdateBikePrice(int bike_id, int price)
        {
            return true;
        }

    }

    //var bike1 = new Bike
    //{
    //    ID = 1,
    //    status = "Available",
    //    b = Brand.SANTA_CRUZ,
    //    s = BikeSize.M,
    //    wheels = WheelSize.SIZE27_5,
    //    name = "Bike 1",
    //    price = 1000
    //};

    //var bike2 = new Bike
    //{
    //    ID = 2,
    //    status = "Booked",
    //    b = Brand.CANYON,
    //    s = BikeSize.L,
    //    wheels = WheelSize.SIZE29,
    //    name = "Bike 2",
    //    price = 1500
    //};

    //var bike3 = new Bike
    //{
    //    ID = 3,
    //    status = "Available",
    //    b = Brand.TREK,
    //    s = BikeSize.S,
    //    wheels = WheelSize.SIZE29,
    //    name = "Bike 3",
    //    price = 1200
    //};
}
