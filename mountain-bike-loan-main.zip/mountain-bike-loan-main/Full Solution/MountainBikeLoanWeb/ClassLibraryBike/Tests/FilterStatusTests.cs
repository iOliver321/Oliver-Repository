﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Interfaces;
using BusinessLayer.Managers.Filters;
using BusinessLayer.Object;
using NUnit.Framework;
using System.Collections.Generic;

namespace BusinessLayer.Tests
{
    [TestFixture]
    public class FilterStatusTests
    {
        [Test]
        public void ReturnFilteredBikes_ShouldReturnFilteredBikesByStatus()
        {
            // Arrange
            IBikeDataInterface bikeData = new FakeDependency();

            var bikes = bikeData.GetXCList();
            bikes.AddRange(bikeData.GetDownhillList());
            bikes.AddRange(bikeData.GetTrailList());
            bikes.AddRange(bikeData.GetEnduroList());
            var filter = new filter_status(bikeData, "Available");
            var expectedBikes = new List<Bike> { bikes[0], bikes[2] };

            // Act
            var filteredBikes = filter.return_filtered_bikes();

            // Assert
            CollectionAssert.AreEquivalent(expectedBikes, filteredBikes);
        }
    }
}
