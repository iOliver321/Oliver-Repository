﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Interfaces;
using BusinessLayer.Managers.Filters;
using BusinessLayer.Object;
using NUnit.Framework;
using System.Collections.Generic;

namespace BusinessLayer.Tests
{
    [TestFixture]
    public class FilterIdTests
    {
        [Test]
        public void ReturnFilteredBikes_ShouldReturnFilteredBikeById()
        {
            // Arrange
            IBikeDataInterface bikeData = new FakeDependency();

            var bikes = bikeData.GetXCList();
            bikes.AddRange(bikeData.GetDownhillList());
            bikes.AddRange(bikeData.GetTrailList());
            bikes.AddRange(bikeData.GetEnduroList());
            var filter = new filter_id(bikeData, 2);
            var expectedBike = bikes[1];

            // Act
            var filteredBikes = filter.return_filtered_bikes();

            // Assert
            Assert.AreEqual(1, filteredBikes.Count);
            Assert.AreEqual(expectedBike, filteredBikes[0]);
        }      
    }
}

