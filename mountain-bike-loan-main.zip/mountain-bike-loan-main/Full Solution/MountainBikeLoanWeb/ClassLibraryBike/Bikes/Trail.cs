﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Object;

namespace BusinessLayer.Classes.Bikes
{
    public class TrailBike : Bike
    {
        public bool dropper;
        public TrailBike(Brand B, BikeSize S, WheelSize W, string Name, int Price, string Status, int ID, bool dropper)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
            this.status = Status;
            this.ID = ID;
            this.dropper = dropper;
        }
        public bool return_dropper()
        {
            return this.dropper;
        }
        public override string return_type()
        {
            return "Trail";
        }
        /*public override string Difficulty()
        {
            return "Easy";
        }

        public override string Weight()
        {
            return "Pretty light";
        }

        public override string Trail()
        {
            return "All Around trails. This bike is good for everything";
        }
        */
    }
}
