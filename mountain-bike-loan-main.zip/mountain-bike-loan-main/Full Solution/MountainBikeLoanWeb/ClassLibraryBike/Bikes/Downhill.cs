﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Classes.Bikes
{
    public class Downhill : Bike
    {
        public bool long_frame;
        public Downhill(Brand B, BikeSize S, WheelSize W, string Name, int Price, string Status, int ID, bool long_frame)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
            this.status = Status;
            this.ID = ID;
            this.long_frame = long_frame;
        }
        public bool return_long_frame()
        {
            return this.long_frame;
        }
        public override string return_type()
        {
            return "Downhill";
        }
        /*public override string Difficulty()
        {
            return "Hard";
        }

        public override string Weight()
        {
            return "Heavy";
        }

        public override string Trail()
        {
            return "The harshest and most difficult trails.";
        }*/

    }
}
