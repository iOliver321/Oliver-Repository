﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Object;

namespace BusinessLayer.Classes.Bikes
{
    public class XC : Bike
    {
        public bool axs_transmission;
        public XC(Brand B, BikeSize S, WheelSize W, string Name, int Price, string Status, int ID, bool axs_transmission)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
            this.status = Status;
            this.ID = ID;
            this.axs_transmission = axs_transmission;
        }
        public bool return_axs_transmission()
        {
            return axs_transmission;
        }

        public override string return_type()
        {
            return "XC";
        }
        /*public override string Difficulty()
        {
            return "Easy";
        }

        public override string Weight()
        {
            return "Lightweight";
        }

        public override string Trail()
        {
            return "Any gravel and easy trails. Not recomended above blue trails";
        }*/

    }
}