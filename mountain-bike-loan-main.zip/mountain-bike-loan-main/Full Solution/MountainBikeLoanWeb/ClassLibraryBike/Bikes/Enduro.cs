﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Classes.Bikes
{
    public class Enduro : Bike
    {
        public bool race_frame;
        public Enduro(Brand B, BikeSize S, WheelSize W, string Name, int Price, string Status, int ID, bool race_frame)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
            this.status = Status;
            this.ID = ID;
            this.race_frame = race_frame;
        }

        public bool return_race_frame()
        {
            return this.race_frame;
        }

        public override string return_type()
        {
            return "Enduro";
        }
        /*public override string Difficulty()
        {
            return "Medium";
        }

        public override string Weight()
        {
            return "Medium Weight";
        }

        public override string Trail()
        {
            return "Very good for harsh terrains and some light climbing.";
        }*/

    }
}
