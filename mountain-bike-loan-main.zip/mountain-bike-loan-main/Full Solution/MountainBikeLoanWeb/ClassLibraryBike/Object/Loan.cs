﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Object
{
    public class Loan
    {
        int ID;
        string username;
        int bike_id;
        DateTime loan_date;
        DateTime return_date = DateTime.MinValue;
        DateTime expected_return_date;

        public Loan(int iD, string username, int bike_id, DateTime loan_date, DateTime return_date, DateTime expected_return_date)
        {
            ID = iD;
            this.username = username;
            this.bike_id = bike_id;
            this.loan_date = loan_date;
            this.return_date = return_date;
            this.expected_return_date = expected_return_date;
        }

        public Loan(int iD, string username, int bike_id, DateTime loan_date, DateTime expected_return_date)
        {
            ID = iD;
            this.username = username;
            this.bike_id = bike_id;
            this.loan_date = loan_date;
            this.expected_return_date = expected_return_date;
        }

        public bool message_return_bike()
        {
            if (expected_return_date < DateTime.Now)
            {
                return true;
            }
            return false;
        }

        public int return_id()
        {
            return ID;
        }

        public string return_username()
        {
            return username;
        }

        public int return_bike_id()
        {
            return bike_id;
        }

        public DateTime return_loan_date()
        {
            return loan_date;
        }

        public DateTime return_return_date()
        {
            return return_date;
            /*if (this.return_date != DateTime.MinValue)
            {
                return this.return_date;
            }
            else return DateTime.MinValue;*/
        }

        public DateTime return_expected_return_date()
        {
            return expected_return_date;
        }

    }
}
