﻿using System.ComponentModel.DataAnnotations;

namespace BusinessLayer.Object
{
    public class Account
    {
        public int ID { get; set; }
        [Required]
        [StringLength(16, ErrorMessage = "Must be between 3 and 16 characters", MinimumLength = 3)]
        public string Username { get; set; }
        [Required]
        [StringLength(16, ErrorMessage = "Must be between 3 and 16 characters", MinimumLength = 3)]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }
}
