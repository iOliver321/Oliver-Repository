﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Object
{
    public class Book
    {
        public int ID;
        public string username;
        public int bike_id;
        public DateTime book_date;

        public Book(int iD, string username, int bike_id, DateTime book_date)
        {
            ID = iD;
            this.username = username;
            this.bike_id = bike_id;
            this.book_date = book_date;
        }

        public int return_id()
        {
            return ID;
        }

        public string return_username()
        {
            return username;
        }

        public int return_bike_id()
        {
            return bike_id;
        }

        public DateTime return_book_date()
        {
            return book_date;
        }
    }
}
