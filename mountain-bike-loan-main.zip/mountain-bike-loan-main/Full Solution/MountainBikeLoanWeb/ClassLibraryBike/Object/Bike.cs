﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Classes.EnumBike;

namespace BusinessLayer.Object
{
    public class Bike
    {
        public int ID;
        public string status;
        public Brand b;
        public BikeSize s;
        public WheelSize wheels;
        public string name;
        public int price;

        /*public abstract string Trail();
        public abstract string Difficulty();
        public abstract string Weight();*/

        public bool book_bike()
        {
            try
            {
                status = "BOOKED";
                return true;
            }
            catch
            {
                return false;
            }
        }

        public virtual string return_type()
        {
            return "Type";
        }

        public void update_status(string status)
        {
            this.status = status;
        }

        public void update_price(int price)
        {
            this.price = price;
        }

        public string return_name()
        {
            return name;
        }

        public string return_brand()
        {
            return Convert.ToString(b);
        }

        public string return_bike_size()
        {
            return Convert.ToString(s);
        }

        public string return_wheel_size()
        {
            return Convert.ToString(wheels);
        }

        public string return_price()
        {
            return Convert.ToString(price);
        }

        public string return_status()
        {
            return status;
        }

        public int return_id()
        {
            return ID;
        }
    }
}
