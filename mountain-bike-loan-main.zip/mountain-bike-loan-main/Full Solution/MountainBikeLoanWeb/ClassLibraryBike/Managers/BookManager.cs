﻿using BusinessLayer.Classes;
using BusinessLayer.Interfaces;
using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers
{
    public class BookManager
    {
        IBookDataInterface cmd;

        public BookManager(IBookDataInterface aux)
        {
            cmd = aux;
        }
        public List<Book> books = new List<Book>();

        public List<Book> GetBooks()
        {
            List<Book> updated_books = cmd.get_books();
            return updated_books;
        }

        public List<Book> return_username_books(string username)
        {
            List<Book> username_books = new List<Book>();
            books = GetBooks();
            Debug.WriteLine(books.Count);
            foreach (Book book in books)
            {
                if (book.username == username)
                {
                    username_books.Add(book);
                }
            }
            return username_books;
        }

        public bool CreateBook(int id, string username, int bike_id)
        {
            Book book = new Book(id, username, bike_id, DateTime.Now);
            return cmd.add_book(book.return_bike_id(), book.return_username());
        }

        public List<Book> search_engine(string username, int id, int bike_id)
        {
            List<Book> books = GetBooks();
            List<Book> filtered_books = new List<Book>();

            foreach (Book book in books)
            {
                if ((book.return_username() == username || username == "clear") && (book.return_id() == id || id == 0) && (book.return_bike_id() == bike_id || bike_id == 0))
                {
                    filtered_books.Add(book);
                }
            }

            return filtered_books;
        }
    }
}
