﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BusinessLayer.Object;
using BusinessLayer.Interfaces;

namespace BusinessLayer.Managers
{
    public class LoanManager
    {
        ILoanDataInterface cmd;

        public LoanManager(ILoanDataInterface aux)
        {
            cmd = aux;
        }

        List<Loan> loans = new List<Loan>();

        public List<Loan> update_loans()
        {

            List<Loan> loans = cmd.get_loans();

            return loans;
        }

        public List<Loan> return_loans()
        {
            return update_loans();
        }

        public List<Loan> return_active_loans()
        {
            List<Loan> active_loans = new List<Loan>();
            loans = update_loans();

            foreach (Loan loan in loans)
            {
                if (loan.return_return_date() == DateTime.MinValue)
                {
                    active_loans.Add(loan);
                }
            }

            return active_loans;
        }

        public List<Loan> return_past_loans()
        {
            List<Loan> past_loans = new List<Loan>();
            loans = update_loans();

            foreach (Loan loan in loans)
            {
                if (loan.return_return_date() != DateTime.MinValue)
                {
                    past_loans.Add(loan);
                }
            }

            return past_loans;
        }

        public List<Loan> return_active_loans_username(string username)
        {
            List<Loan> active_loans = new List<Loan>();
            loans = update_loans();

            foreach (Loan loan in loans)
            {
                if (loan.return_return_date() == DateTime.MinValue && username == loan.return_username())
                {
                    active_loans.Add(loan);
                }
            }
            return active_loans;
        }

        public List<Loan> return_past_loans_username(string username)
        {
            List<Loan> past_loans = new List<Loan>();
            loans = update_loans();

            foreach (Loan loan in loans)
            {
                if (loan.return_return_date() != DateTime.MinValue && loan.return_username() == username)
                {
                    past_loans.Add(loan);
                }
            }

            return past_loans;
        }

        public bool add_loan(int bike_id, string username, DateTime expected_return_date)
        {
            return cmd.add_loan(bike_id, username, expected_return_date);
        }

        public bool return_bike(int bike_id)
        {
            return cmd.return_bike(bike_id);
        }

        public List<Loan> search_engine(int id, int bike_id, string username)
        {
            List<Loan> filtered_loans = new List<Loan>();
            loans = update_loans();
            foreach (Loan loan in loans)
            {
                if ((loan.return_id() == id || id == 0) && (loan.return_username() == username || username == "clear") && (loan.return_bike_id() == bike_id || bike_id == 0))
                {
                    filtered_loans.Add(loan);
                }
            }

            return filtered_loans;
        }
    }
}
