﻿using BusinessLayer.Interfaces;
using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers.Filters
{
    public class filter_status : IFilter
    {
        List<Bike> bikes;
        List<Bike> filtered_bikes;
        string status;
        IBikeDataInterface bikeDataInterface;

        public filter_status(IBikeDataInterface bikeinterface, string status)
        {
            this.status = status;
            this.filtered_bikes = new List<Bike>();

            bikeDataInterface = bikeinterface;
            bikes = bikeDataInterface.GetTrailList();
            bikes.AddRange(bikeDataInterface.GetDownhillList());
            bikes.AddRange(bikeDataInterface.GetEnduroList());
            bikes.AddRange(bikeDataInterface.GetXCList());
        }

        public void filter_bikes()
        {
            foreach (Bike bike in bikes)
            {
                if (bike.return_status() == status)
                {
                    filtered_bikes.Add(bike);
                }
            }
        }

        public List<Bike> return_filtered_bikes()
        {
            filter_bikes();
            return filtered_bikes;
        }
    }
}
