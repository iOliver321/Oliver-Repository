﻿using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Interfaces;
using BusinessLayer.Interfaces.Filters;
using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Managers.Filters
{
    public class filter_brand : IFilter
    {
        List<Bike> bikes;
        List<Bike> filtered_bikes;
        string brand;
        IBikeDataInterface bikeDataInterface;

        public filter_brand(IBikeDataInterface bikeinterface, string brand)
        {
            this.brand = brand;
            bikeDataInterface = bikeinterface;
            bikes = bikeDataInterface.GetTrailList();
            bikes.AddRange(bikeDataInterface.GetDownhillList());
            bikes.AddRange(bikeDataInterface.GetEnduroList());
            bikes.AddRange(bikeDataInterface.GetXCList());
        }
        

        public void filter_bikes()
        {
            foreach (Bike bike in bikes)
            {
                if (bike.return_brand() == brand)
                {
                    filtered_bikes.Add(bike);
                }
            }
        }

        public List<Bike> return_filtered_bikes()
        {
            filter_bikes();
            return filtered_bikes;
        }
    }
}
