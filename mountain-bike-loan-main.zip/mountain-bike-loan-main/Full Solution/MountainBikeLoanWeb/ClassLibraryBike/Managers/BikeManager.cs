﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BusinessLayer.Classes.Bikes;
using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Interfaces;
using BusinessLayer.Object;

namespace BusinessLayer.Managers
{
    public class BikeManager
    {
        IBikeDataInterface cmd;

        public event BikeAddedEventHandler BikeAdded;

        public BikeManager(IBikeDataInterface aux)
        {
            cmd = aux;
        }

        public List<Bike> bikes = new List<Bike>();

        private List<Bike> get_all_bikes(string type)
        {
            List<Bike> downhill_bikes = cmd.GetDownhillList();
            List<Bike> xc_bikes = cmd.GetXCList();
            List<Bike> trail_bikes = cmd.GetTrailList();
            List<Bike> enduro_bikes = cmd.GetEnduroList();
            List<Bike> all_bikes = new List<Bike>();
            all_bikes.AddRange(downhill_bikes);
            all_bikes.AddRange(xc_bikes);
            all_bikes.AddRange(trail_bikes);
            all_bikes.AddRange(enduro_bikes);

            switch (type)
            {
                case "DOWNHILL":
                    return downhill_bikes;
                case "XC":
                    return xc_bikes;
                case "TRAIL":
                    return trail_bikes;
                case "ENDURO":
                    return enduro_bikes;
                case "":
                    return all_bikes;
                default:
                    return all_bikes;
            }
        }

        public List<Bike> update_bikes()
        {
            return get_all_bikes("");
        }

        /*public List<Bike> get_xc()
        {
            return get_all_bikes("XC");
        }

        public List<Bike> get_trail()
        {
            return get_all_bikes("TRAIL");
        }

        public List<Bike> get_enduro()
        {
            return get_all_bikes("ENDURO");
        }

        public List<Bike> get_downhill()
        {
            return get_all_bikes("DOWNHILL");
        }*/
        public bool update_bike(int id, string status, int price)
        {
            bikes = update_bikes();
            foreach (Bike bike in bikes)
            {
                if (bike.return_id() == id)
                {
                    if (status != bike.return_status())
                    {
                        bike.update_status(status);
                        cmd.UpdateBikeStatus(bike.return_id(), status);
                    }
                    if (price != 0)
                    {
                        bike.update_price(price);
                        cmd.UpdateBikePrice(bike.return_id(), price);
                    }
                    return true;
                }
            }
            return false;
        }
        public int new_id()
        {
            List<Bike> bikes = update_bikes();
            int id = 0;
            foreach (Bike bike in bikes)
            {
                if (bike.return_id() > id)
                {
                    id = bike.return_id();
                }
            }
            return id + 1;
        }
        public void add_bike_xc(Brand brand, BikeSize bikesize, WheelSize wheelsize, string name, int price, bool yesus)
        {
            Bike bike = new XC(brand, bikesize, wheelsize, name, price, "Ready", new_id(), yesus);
            bikes.Add(bike);
            cmd.CreateBike("XC", Convert.ToString(brand), Convert.ToInt32(bikesize), Convert.ToInt32(wheelsize), name, price, yesus);
            BikeAdded?.Invoke(bike);
        }

        public void add_bike_trail(Brand brand, BikeSize bikesize, WheelSize wheelsize, string name, int price, bool yesus)
        {
            Bike bike = new TrailBike(brand, bikesize, wheelsize, name, price, "Ready", new_id(), yesus);
            bikes.Add(bike);
            cmd.CreateBike("Trail", Convert.ToString(brand), Convert.ToInt32(bikesize), Convert.ToInt32(wheelsize), name, price, yesus);
            BikeAdded?.Invoke(bike);
        }

        public void add_bike_enduro(Brand brand, BikeSize bikesize, WheelSize wheelsize, string name, int price, bool yesus)
        {
            Bike bike = new Enduro(brand, bikesize, wheelsize, name, price, "Ready", new_id(), yesus);
            bikes.Add(bike);
            cmd.CreateBike("Enduro", Convert.ToString(brand), Convert.ToInt32(bikesize), Convert.ToInt32(wheelsize), name, price, yesus);
            BikeAdded?.Invoke(bike);
        }
        public void add_bike_downhill(Brand brand, BikeSize bikesize, WheelSize wheelsize, string name, int price, bool yesus)
        {
            Bike bike = new Downhill(brand, bikesize, wheelsize, name, price, "Ready", new_id(), yesus);
            bikes.Add(bike);
            cmd.CreateBike("Downhill", Convert.ToString(brand), Convert.ToInt32(bikesize), Convert.ToInt32(wheelsize), name, price, yesus);
            BikeAdded?.Invoke(bike);
        }

        public List<Bike> return_bikes()
        {
            return update_bikes();
        }


        public List<Bike> search_engine(string status, string name, string brand, int id)
        {
            List<Bike> bikes = update_bikes();
            List<Bike> filtered_bikes = new List<Bike>();

            foreach (Bike bike in bikes)
            {
                if ((bike.return_status() == status || status == "clear") && (bike.return_name() == name || name == "clear") && (bike.return_brand() == brand || brand == "clear") && (bike.return_id() == id || id == 0))
                {
                    filtered_bikes.Add(bike);
                }
            }

            return filtered_bikes;
        }

        public bool book_bike(int bike_id)
        {
            List<Bike> bikes = update_bikes();
            foreach (Bike bike in bikes)
            {
                if (bike.return_id() == bike_id)
                {
                    if (bike.book_bike())
                    {
                        Debug.WriteLine("IT IS UPDATED IN CLASS");
                    }
                    else
                    {
                        Debug.WriteLine("IT IS NOT UPDATED IN CLASS");
                        return false;
                    }

                    if (cmd.UpdateBikeStatus(bike.return_id(), "BOOKED"))
                    {
                        Debug.WriteLine("SQL WORKED");
                    }
                    else
                    {
                        Debug.WriteLine("ERROR ,SQL DIDNT WORK");
                        return false;
                    }
                }
            }
            return true;
        }

    }

    public delegate void BikeAddedEventHandler(Bike bike);
}
