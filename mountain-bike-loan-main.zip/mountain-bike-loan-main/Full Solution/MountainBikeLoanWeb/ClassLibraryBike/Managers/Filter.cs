﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Classes.Bikes;
using BusinessLayer.Classes.EnumBike;
using BusinessLayer.Interfaces;
using BusinessLayer.Object;

namespace BusinessLayer.Managers
{
    public class Filter
    {
        private readonly IFilter _ifilter;
        public Filter(IFilter filter)
        { 
            _ifilter = filter;
        }


        

    }
}
