﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer.Interfaces;
using BusinessLayer.Object;

namespace BusinessLayer.Managers
{
    public class AccountManager
    {
        IAccountDataInterface cmd;

        public AccountManager(IAccountDataInterface aux)
        {
            cmd = aux;
        }

        public List<Account> accounts = new List<Account>();

        public void update_accounts()
        {
            accounts = cmd.accountDTOs();
        }

        public bool check_username(Account aux)
        {
            foreach (Account account in accounts)
            {
                if (account.Username == aux.Username)
                {
                    return false;
                }
            }
            return true;
        }

        public bool check_password(Account aux)
        {
            foreach (Account account in accounts)
            {
                if (account.Password == aux.Password && account.Username == aux.Username)
                {
                    return true;
                }
            }
            return false;
        }
        public bool create_account(Account account)
        {
            accounts.Add(account);
            return cmd.CreateAccount(account.Username, account.Password);
        }
    }
}
