﻿using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IBookDataInterface
    {
        public bool add_book(int bike_id, string username);

        public List<Book> get_books();
    }
}
