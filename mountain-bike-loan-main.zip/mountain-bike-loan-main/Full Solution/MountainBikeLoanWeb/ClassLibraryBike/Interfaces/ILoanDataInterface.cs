﻿using BusinessLayer;
using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface ILoanDataInterface
    {
        public bool add_loan(int bike_id, string username, DateTime expected_return_date);

        public bool return_bike(int bike_id);

        public List<Loan> get_loans();
    }
}
