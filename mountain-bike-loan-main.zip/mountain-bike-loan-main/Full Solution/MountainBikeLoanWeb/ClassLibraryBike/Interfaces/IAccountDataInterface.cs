﻿using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IAccountDataInterface
    {
        public bool CreateAccount(string username, string password);

        public List<Account> get_accounts();

        public List<Account> accountDTOs();
    }
}
