﻿using BusinessLayer.Object;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.Interfaces
{
    public interface IBikeDataInterface
    {
        public List<Bike> GetDownhillList();

        public List<Bike> GetEnduroList();

        public List<Bike> GetTrailList();

        public List<Bike> GetXCList();

        public bool CreateBike(string type, string brand, int bikesize, int wheelsize, string name, int price, bool yesus);

        public bool UpdateBikeStatus(int bike_id, string status);

        public bool UpdateBikePrice(int bike_id, int price);
    }
}
