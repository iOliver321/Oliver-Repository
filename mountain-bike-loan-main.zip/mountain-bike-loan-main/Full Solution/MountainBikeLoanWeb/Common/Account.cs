﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Common
{
    public class Account
    {
        public int ID { get; set; }
        [Required]
        [StringLength(16, ErrorMessage = "Must be between 3 and 16 characters", MinimumLength = 3)]
        public string Username { get; set; }
        [Required]
        [StringLength(16, ErrorMessage = "Must be between 3 and 16 characters", MinimumLength = 3)]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        /*public string create_account_with_validation()
        {
            return cmd.create_account_with_validation(Username, Password);
        }

        public string login_into_account()
        {
            return cmd.IsValidUser(Username, Password);
        }*/
    }
}
