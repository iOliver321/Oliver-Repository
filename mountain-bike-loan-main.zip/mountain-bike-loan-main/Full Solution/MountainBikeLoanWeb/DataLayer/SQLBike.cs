﻿using BusinessLayer.Interfaces;
using BusinessLayer.Object;
using BusinessLayer.Classes.Bikes;
using BusinessLayer.Classes;
using BusinessLayer.Classes.EnumBike;
using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace DataLayer
{
    public class SQLBike : IBikeDataInterface
    {
        SqlCommand cmd;
        SqlDataAdapter adapter;
        SqlDataReader reader;
        private string connection = "Server=mssqlstud.fhict.local;Database=dbi500882_database1;User Id=dbi500882_database1;Password=Oo12345678;";
        
        /*public List<BikeDTO> GetBikeList()
        {
            List<BikeDTO> bikes = new List<BikeDTO> ();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "SELECT ID, TRIM(Status), TRIM(Brand), BikeSize, WheelSize, TRIM(name), price, TRIM(Type) FROM Bike";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int id = Convert.ToInt32(dr[0]);
                string status = Convert.ToString(dr[1]);
                BrandDTO brand = (BrandDTO)Enum.Parse(typeof(BrandDTO), Convert.ToString(dr[2]));
                //BikeSizeDTO bikesize = (BikeSizeDTO)Enum.Parse(typeof(BikeSizeDTO), Convert.ToString(dr[3]));
                BikeSizeDTO bikeSize = (BikeSizeDTO)Convert.ToInt32(dr[3]);
                WheelSizeDTO wheelsize = (WheelSizeDTO)Enum.Parse(typeof (WheelSizeDTO), Convert.ToString(dr[4]));
                string name = Convert.ToString(dr[5]);
                int price = Convert.ToInt32(dr[6]);
                string type = Convert.ToString(dr[7]);

                BikeDTO bike = new BikeDTO(id,status,brand,bikeSize,wheelsize,name,price,type);
                bikes.Add(bike);
            }

            conn.Close();

            return bikes;
        }*/

        public List<Bike> GetDownhillList()
        {
            List<Bike> bikes = new List<Bike>();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "select * from Bike as b join Downhill as d on b.ID = d.ID";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int id = Convert.ToInt32(dr[0]);
                string status = Convert.ToString(dr[6]);
                status = status.Trim();
                Brand brand = (Brand)Enum.Parse(typeof(Brand), Convert.ToString(dr[1]));
                BikeSize bikeSize = (BikeSize)Convert.ToInt32(dr[2]);
                WheelSize wheelsize = (WheelSize)Enum.Parse(typeof(WheelSize), Convert.ToString(dr[3]));
                string name = Convert.ToString(dr[4]).Trim();
                int price = Convert.ToInt32(dr[5]);
                bool long_frame = Convert.ToBoolean(dr[8]);

                Bike bike = new Downhill(brand,bikeSize,wheelsize,name,price,status,id,long_frame);
                bikes.Add(bike);
            }

            conn.Close();

            return bikes;
        }

        public List<Bike> GetEnduroList()
        {
            List<Bike> bikes = new List<Bike>();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "select * from Bike as b join Enduro as e on b.ID = e.ID";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int id = Convert.ToInt32(dr[0]);
                string status = Convert.ToString(dr[6]);
                status = status.Trim();
                Brand brand = (Brand)Enum.Parse(typeof(Brand), Convert.ToString(dr[1]));
                BikeSize bikeSize = (BikeSize)Convert.ToInt32(dr[2]);
                WheelSize wheelsize = (WheelSize)Enum.Parse(typeof(WheelSize), Convert.ToString(dr[3]));
                string name = Convert.ToString(dr[4]).Trim();
                int price = Convert.ToInt32(dr[5]);
                bool race_frame = Convert.ToBoolean(dr[8]);

                Bike bike = new Enduro(brand, bikeSize, wheelsize, name, price, status, id, race_frame);
                bikes.Add(bike);
            }

            conn.Close();

            return bikes;
        }

        public List<Bike> GetTrailList()
        {
            List<Bike> bikes = new List<Bike>();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "select * from Bike as b join Trail as t on b.ID = t.ID";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int id = Convert.ToInt32(dr[0]);
                string status = Convert.ToString(dr[6]);
                status = status.Trim();
                Brand brand = (Brand)Enum.Parse(typeof(Brand), Convert.ToString(dr[1]));
                BikeSize bikeSize = (BikeSize)Convert.ToInt32(dr[2]);
                WheelSize wheelsize = (WheelSize)Enum.Parse(typeof(WheelSize), Convert.ToString(dr[3]));
                string name = Convert.ToString(dr[4]).Trim();
                int price = Convert.ToInt32(dr[5]);
                bool dropper = Convert.ToBoolean(dr[8]);

                Bike bike = new TrailBike(brand, bikeSize, wheelsize, name, price, status, id, dropper);
                bikes.Add(bike);
            }

            conn.Close();

            

            return bikes;
        }

        public List<Bike> GetXCList()
        {
            List<Bike> bikes = new List<Bike>();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "select * from Bike as b join XC on b.ID = XC.ID";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int id = Convert.ToInt32(dr[0]);
                string status = Convert.ToString(dr[6]);
                status = status.Trim();
                Brand brand = (Brand)Enum.Parse(typeof(Brand), Convert.ToString(dr[1]));
                BikeSize bikeSize = (BikeSize)Convert.ToInt32(dr[2]);
                WheelSize wheelsize = (WheelSize)Enum.Parse(typeof(WheelSize), Convert.ToString(dr[3]));
                string name = Convert.ToString(dr[4]).Trim();
                int price = Convert.ToInt32(dr[5]);
                bool axs = Convert.ToBoolean(dr[8]);

                Bike bike = new XC(brand,bikeSize,wheelsize,name,price,status,id,axs);
                bikes.Add(bike);
            }

            conn.Close();

            return bikes;
        }

        public bool CreateBike(string type, string brand, int bikesize, int wheelsize, string name, int price, bool yesus)
        {
            string querry;
            querry = "insert into Bike values((select max(ID) from Bike)+1,@brand,@bikesize,@wheelsize,@name,@price,@status);";
            /*try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@Bike", type);
                    cmd.Parameters.AddWithValue("@brand", brand);
                    cmd.Parameters.AddWithValue("@yesus", yesus);
                    cmd.Parameters.AddWithValue("@bikesize", bikesize);
                    cmd.Parameters.AddWithValue("@wheelsize", wheelsize);
                    cmd.Parameters.AddWithValue("@name", name);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@type", type);
                    cmd.Parameters.AddWithValue("@status", "READY");

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                Debug.WriteLine("FIRST WAS SUCCESSFULL");
                querry = "insert into @bike values ((select max(ID) from Bike), @yesus)";
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@bike", type);
                    cmd.Parameters.AddWithValue("@yesus", yesus);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }*/

            using (SqlConnection conn = new SqlConnection(connection))
            {
                cmd = new SqlCommand(querry, conn);
                cmd.Parameters.AddWithValue("@Bike", type);
                cmd.Parameters.AddWithValue("@brand", brand);
                cmd.Parameters.AddWithValue("@yesus", yesus);
                cmd.Parameters.AddWithValue("@bikesize", bikesize);
                cmd.Parameters.AddWithValue("@wheelsize", wheelsize);
                cmd.Parameters.AddWithValue("@name", name);
                cmd.Parameters.AddWithValue("@price", price);
                cmd.Parameters.AddWithValue("@status", "READY");

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
            Debug.WriteLine("FIRST WAS SUCCESSFULL");

            string query = $"INSERT INTO {type}  VALUES ((SELECT MAX(ID) FROM Bike), @yesus)";

            using (SqlConnection conn = new SqlConnection(connection))
            {
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@yesus", yesus);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }

            Debug.WriteLine("SECOND WAS SUCCESSFULL");
            return true;
        }

        public bool UpdateBikeStatus(int bike_id, string status)
        {
            string querry;
            querry = "update Bike Set Status = @status where id = @id";
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@status",status );
                    cmd.Parameters.AddWithValue("@id", bike_id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch
            {
                Debug.WriteLine("SQL PROBLEM");
                return false;
            }
        }

        public bool UpdateBikePrice(int bike_id, int price)
        {
            string querry;
            querry = "update Bike Set price = @price where id = @id";
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@id", bike_id);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                    return true;
                }
            }
            catch
            {
                Debug.WriteLine("SQL PROBLEM");
                return false;
            }
        }
    }
}
