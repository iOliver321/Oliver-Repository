﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLayer;
using BusinessLayer.Interfaces;
using BusinessLayer.Object;

namespace DataLayer
{
    public class SQLLoan : ILoanDataInterface
    {
        SqlCommand cmd;
        SqlDataAdapter adapter;
        SqlDataReader reader;
        private string connection = "Server=mssqlstud.fhict.local;Database=dbi500882_database1;User Id=dbi500882_database1;Password=Oo12345678;";

        public bool add_loan(int bike_id, string username, DateTime expected_return_date)
        {
            string querry;
            querry = "INSERT INTO Loan (username,bike_id,loan_date, expected_return_date) VALUES (@username, @bike_id, @loan_date,@expected_return_date);";
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@bike_id", bike_id);
                    cmd.Parameters.AddWithValue("@loan_date", DateTime.Now);
                    cmd.Parameters.AddWithValue("@expected_return_date",expected_return_date);


                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public bool return_bike(int bike_id)
        {
            string querry;
            querry = "update Loan set return_date = @return_date where bike_id = @bike_id";
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@return_date", DateTime.Now);
                    cmd.Parameters.AddWithValue("@bike_id", bike_id);


                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Loan> get_loans()
        {
            List<Loan> loans = new List<Loan>();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "SELECT loan_id, TRIM(username), bike_id, loan_date, return_date, expected_return_date  from Loan";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int loan_id = Convert.ToInt32(dr[0]);
                string username = Convert.ToString(dr[1]);
                int bike_id = Convert.ToInt32(dr[2]);
                DateTime loan_date = Convert.ToDateTime(dr[3]);
                DateTime return_date;
                DateTime expected_return_date = Convert.ToDateTime((DateTime)dr[5]);
                if (Convert.ToString(dr[4]) == "")
                {
                    return_date = DateTime.MinValue;
                }
                else
                {
                    return_date = Convert.ToDateTime(dr[4]);
                }

                Loan loan = new Loan(loan_id, username, bike_id, loan_date, return_date, expected_return_date);
                loans.Add(loan);
            }

            conn.Close();

            return loans;
        }


    }
}
