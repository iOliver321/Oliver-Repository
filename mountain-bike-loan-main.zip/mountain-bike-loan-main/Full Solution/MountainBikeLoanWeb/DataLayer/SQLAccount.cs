﻿using System.Data;
using System.Diagnostics.Metrics;
using System.Data.SqlClient;
using System.Data;
using System.Runtime.Intrinsics.X86;
using System.Security.Principal;
using System.ComponentModel.DataAnnotations;
using BusinessLayer.Interfaces;
using BusinessLayer.Object;

namespace DataLayer
{
    public class SQLAccount : IAccountDataInterface
    {
        SqlCommand cmd;
        SqlDataAdapter adapter;
        SqlDataReader reader;
        private string connection = "Server=mssqlstud.fhict.local;Database=dbi500882_database1;User Id=dbi500882_database1;Password=Oo12345678;";
        //Trust Server Certificate=true;

        public bool CreateAccount(string username, string password)
        {
            string querry;
            querry = "insert into Account values(@username,@password)";
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }
        public List<Account> get_accounts()
        {
            List<Account> accounts_number = new List<Account>();
            SqlConnection conn = new SqlConnection(connection);
            string sql = "SELECT TRIM(username), TRIM(password) FROM Account";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                /*string work_type = dr[0].ToString();
                int worked_hours = Convert.ToInt32(dr[1]);
                string assigned_shifts = dr[2].ToString();
                int id = Convert.ToInt32(dr[3]);
                string name = dr[4].ToString();
                string password = dr[5].ToString();
                int age = Convert.ToInt32(dr[6]);
                int emergency_contact = Convert.ToInt32(dr[7]);
                int tax_number = Convert.ToInt32(dr[8]);
                string contract = dr[9].ToString();
                string chat = dr[10].ToString();
                */
                Account account = new Account();
                account.Username = Convert.ToString(dr[0]);
                account.Password = Convert.ToString(dr[1]);
                //List<string> account_details = new List<string>() { work_type, worked_hours.ToString(), assigned_shifts, id.ToString(), name, password, age.ToString(), emergency_contact.ToString(), tax_number.ToString(), contract, chat };
                accounts_number.Add(account);
            }

            conn.Close();
            return accounts_number;
        }
        public List<Account> accountDTOs()
        {
            List<Account> accounts = new List<Account>();
            SqlConnection conn = new SqlConnection(connection);
            string sql = "SELECT TRIM(username), TRIM(password) FROM Account";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                string username = Convert.ToString(dr[0]);
                string password = Convert.ToString(dr[1]);

                Account account = new Account();
                account.Username = username;
                account.Password = password;

                accounts.Add(account);
            }
            conn.Close();
            return accounts;
        }
    }
}
