﻿using BusinessLayer.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using BusinessLayer.Object;

namespace DataLayer
{
    public class SQLBook : IBookDataInterface
    {
        SqlCommand cmd;
        SqlDataAdapter adapter;
        SqlDataReader reader;
        private string connection = "Server=mssqlstud.fhict.local;Database=dbi500882_database1;User Id=dbi500882_database1;Password=Oo12345678;";

        public bool add_book(int bike_id, string username)
        {
            string querry;
            querry = "INSERT INTO Book (username,bike_id,BookDate) VALUES (@username, @bike_id, @BookDate); update Bike Set Status = 'BOOKED' where id = @bike_id";
            try
            {
                using (SqlConnection conn = new SqlConnection(connection))
                {
                    cmd = new SqlCommand(querry, conn);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@bike_id", bike_id);
                    cmd.Parameters.AddWithValue("@BookDate", DateTime.Now);


                    conn.Open();
                    cmd.ExecuteNonQuery();
                    conn.Close();
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public List<Book> get_books()
        {
            List<Book> books = new List<Book>();

            SqlConnection conn = new SqlConnection(connection);
            string sql = "SELECT Id, TRIM(username), bike_id, BookDate from Book";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {

                int id = Convert.ToInt32(dr[0]);
                string username = Convert.ToString(dr[1]);
                int bike_id = Convert.ToInt32(dr[2]);
                DateTime book_date = Convert.ToDateTime(dr[3]);

                Book book = new Book(id, username, bike_id, book_date);
                books.Add(book);
            }

            conn.Close();

            return books;
        }


    }
}
