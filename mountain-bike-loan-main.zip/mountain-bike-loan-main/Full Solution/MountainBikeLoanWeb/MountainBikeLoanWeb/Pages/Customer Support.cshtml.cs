using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MountainBikeLoanWeb.Pages
{
    public class Customer_SupportModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
