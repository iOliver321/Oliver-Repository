using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MountainBikeLoanWeb.Pages
{
    public class Loan_CartModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
