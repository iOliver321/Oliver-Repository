using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MountainBikeLoanWeb.Pages
{
    public class BikesModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
