using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Cryptography;
using DataLayer;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using BusinessLayer.Object;
using BusinessLayer.Managers;
using BusinessLayer.Interfaces;

namespace MountainBikeLoanWeb.Pages
{
    public class LoginModel : PageModel
    {
        IAccountDataInterface IAccount = new SQLAccount();
        AccountManager acc;

        public string Login { get; set; }

        public LoginModel()
        {
            acc = new AccountManager(IAccount);
        }


        [BindProperty]
        public Account Account { get; set; }


        public void OnGet()
        {

        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (ModelState.IsValid)
            {
                acc.update_accounts();
                if (acc.check_password(Account))
                {
                    var claims = new List<Claim>
                    {
                      new Claim(ClaimTypes.Name, Account.Username),
                      new Claim(ClaimTypes.Role, "Client"),
                    };

                    var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);

                    var authProperties = new AuthenticationProperties
                    {
                        //AllowRefresh = <bool>,
                        // Refreshing the authentication session should be allowed.

                        //ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(10),
                        // The time at which the authentication ticket expires. A 
                        // value set here overrides the ExpireTimeSpan option of 
                        // CookieAuthenticationOptions set with AddCookie.

                        //IsPersistent = true,
                        // Whether the authentication session is persisted across 
                        // multiple requests. When used with cookies, controls
                        // whether the cookie's lifetime is absolute (matching the
                        // lifetime of the authentication ticket) or session-based.

                        //IssuedUtc = <DateTimeOffset>,
                        // The time at which the authentication ticket was issued.

                        //RedirectUri = <string>
                        // The full path or absolute URI to be used as an http 
                        // redirect response value.
                    };
                    await HttpContext.SignInAsync(
                        CookieAuthenticationDefaults.AuthenticationScheme, 
                        new ClaimsPrincipal(claimsIdentity), 
                        authProperties);

                    return RedirectToPage("/Bikes");
                }
                else
                {
                    TempData["Message"] = "Invalid Credentials";
                }
                return Page();
            }
            else
            {
                return Page();
            }
        }
    }
}
