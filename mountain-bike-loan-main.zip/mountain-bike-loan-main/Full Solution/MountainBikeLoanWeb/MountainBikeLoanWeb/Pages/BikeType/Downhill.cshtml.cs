using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Connections;
using System.Diagnostics;
using BusinessLayer.Object;
using BusinessLayer.Managers;
using BusinessLayer.Interfaces;
using DataLayer;
using BusinessLayer.Classes.Bikes;

namespace MountainBikeLoanWeb.Pages.Bikes
{
    [Authorize]
    public class DownhillModel : PageModel
    {
        IBikeDataInterface bikeDataInterface = new SQLBike();
        IBookDataInterface bookDataInterface = new SQLBook();
        public BikeManager bcc; //= new BikeManager(bikeDataInterface);
        public BookManager bookcc; //= new BookManager(bookDataInterface);

        public DownhillModel()
        {
            bcc = new BikeManager(bikeDataInterface);
            bookcc = new BookManager(bookDataInterface);
        }

        public List<Bike> Bikes = new List<Bike>();

        public void OnGet()
        {
            List<Bike> aux = bcc.return_bikes();
            foreach (Bike bike in aux)
            {
                if (bike.GetType() == typeof(Downhill))
                {
                    Bikes.Add(bike);
                }
            }
            Debug.WriteLine("Test123");
        }

        public IActionResult OnPost(int bikeId)
        {
            Debug.WriteLine("Test123");
            bool success = bcc.book_bike(bikeId);
            bool success2 = bookcc.CreateBook(1, User.Identity.Name, bikeId);
            if (success2 && success)
            {
                TempData["Message"] = "Bike booked successfully.";
            }
            else
            {
                TempData["Message"] = "Bike could not be booked.";
            }
            return RedirectToPage("/BikeType/Downhill");

        }

    }

}
