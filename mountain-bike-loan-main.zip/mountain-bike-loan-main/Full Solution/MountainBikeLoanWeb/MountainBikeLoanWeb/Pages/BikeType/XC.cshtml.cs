using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using BusinessLayer.Object;
using BusinessLayer.Managers;
using BusinessLayer.Interfaces;
using DataLayer;
using BusinessLayer.Classes.Bikes;

namespace MountainBikeLoanWeb.Pages.Bikes
{
    [Authorize]
    public class XCModel : PageModel
    {
        IBikeDataInterface bikeDataInterface = new SQLBike();
        IBookDataInterface bookDataInterface = new SQLBook();
        public BikeManager bcc;
        public BookManager bookcc;
        public List<Bike> Bikes = new List<Bike>();


        public XCModel()
        {
            bcc = new BikeManager(bikeDataInterface);
            bookcc = new BookManager(bookDataInterface);
        }

        public void OnGet()
        {
            List<Bike> aux = bcc.return_bikes();
            foreach (Bike bike in aux)
            {
                if (bike.GetType() == typeof(XC))
                {
                    Bikes.Add(bike);
                }
            }
        }
        public IActionResult OnPost(int bikeId)
        {
            Debug.WriteLine("Test123");
            bool success = bcc.book_bike(bikeId);
            bool success2 = bookcc.CreateBook(1, User.Identity.Name, bikeId);
            if (success2 && success)
            {
                TempData["Message"] = "Bike booked successfully.";
            }
            else
            {
                TempData["Message"] = "Bike could not be booked.";
            }
            return RedirectToPage("/BikeType/XC");

        }
    }
}
