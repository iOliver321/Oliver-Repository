using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MountainBikeLoanWeb.Pages
{
    public class Best_Bike_For_YouModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
