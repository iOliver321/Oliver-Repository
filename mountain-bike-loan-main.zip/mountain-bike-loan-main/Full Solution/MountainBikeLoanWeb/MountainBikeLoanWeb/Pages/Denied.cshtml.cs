using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace MountainBikeLoanWeb.Pages
{
    public class DeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
