using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Diagnostics;
using BusinessLayer.Object;
using BusinessLayer.Managers;
using BusinessLayer.Interfaces;
using DataLayer;
using System.Threading.Tasks;

namespace MountainBikeLoanWeb.Pages
{
    [Authorize]
    public class AccountModel : PageModel
    {
        private readonly BookManager bookcc;
        private readonly BikeManager bcc;
        private readonly LoanManager loancc;

        private readonly IBookDataInterface IBook = new SQLBook();
        private readonly IBikeDataInterface IBike = new SQLBike();
        private readonly ILoanDataInterface ILoan = new SQLLoan();

        public List<Bike> bikes { get; set; }
        public List<Book> books { get; set; }
        public List<Loan> active_loans { get; set; }
        public List<Loan> past_loans { get; set; }

        public event LoanAddedEventHandler LoanAdded;

        public delegate void LoanAddedEventHandler(object sender, EventArgs e);

        public AccountModel()
        {
            bookcc = new BookManager(IBook);
            bcc = new BikeManager(IBike);
            loancc = new LoanManager(ILoan);

            // Subscribe to the LoanAdded event and specify the event handler method
            LoanAdded += RefreshLoans;
        }

        public async Task<IActionResult> OnGet()
        {
            bikes = bcc.return_bikes();
            books = bookcc.return_username_books(User.Identity.Name);
            active_loans = loancc.return_active_loans_username(User.Identity.Name);
            past_loans = loancc.return_past_loans_username(User.Identity.Name);

            // Raise the LoanAdded event
            LoanAdded?.Invoke(this, EventArgs.Empty);


            return Page();
        }

        public void RefreshLoans(object sender, EventArgs e)
        {
            active_loans = loancc.return_active_loans_username(User.Identity.Name);
            past_loans = loancc.return_past_loans_username(User.Identity.Name);

            ViewData["ActiveLoans"] = active_loans;
            ViewData["PastLoans"] = past_loans;
        }

        public async Task<IActionResult> OnPostLogout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToPage("/Login");
        }
    }
}
