﻿using ClassLibraryBike.Classes.EnumBike;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBike.Classes.Bikes
{
    class Downhill : Bike
    {
        public Downhill(Brand B, BikeSize S, WheelSize W, string Name, int Price)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
        }
        public override string Difficulty()
        {
            return "Hard";
        }

        public override string Weight()
        {
            return "Heavy";
        }

        public override string Trail()
        {
            return "The harshest and most difficult trails.";
        }

    }
}
