﻿using ClassLibraryBike.Classes.EnumBike;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBike.Classes.Bikes
{
    class Enduro : Bike
    {
        public Enduro(Brand B, BikeSize S, WheelSize W, string Name, int Price)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
        }
        public override string Difficulty()
        {
            return "Medium";
        }

        public override string Weight()
        {
            return "Medium Weight";
        }

        public override string Trail()
        {
            return "Very good for harsh terrains and some light climbing.";
        }

    }
}
