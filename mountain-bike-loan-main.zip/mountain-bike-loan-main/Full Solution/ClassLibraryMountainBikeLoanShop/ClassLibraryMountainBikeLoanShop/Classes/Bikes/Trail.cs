﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryBike.Classes.EnumBike;

namespace ClassLibraryBike.Classes.Bikes
{
    class TrailBike : Bike
    {
        public TrailBike(Brand B, BikeSize S, WheelSize W, string Name, int Price)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
        }
        public override string Difficulty()
        {
            return "Easy";
        }

        public override string Weight()
        {
            return "Pretty light";
        }

        public override string Trail()
        {
            return "All Around trails. This bike is good for everything";
        }

    }
}
