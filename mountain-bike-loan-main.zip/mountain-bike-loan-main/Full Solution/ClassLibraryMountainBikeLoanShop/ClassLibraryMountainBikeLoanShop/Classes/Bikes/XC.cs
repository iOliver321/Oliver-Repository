﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryBike.Classes.EnumBike;

namespace ClassLibraryBike.Classes.Bikes
{
    class XC : Bike
    {
        public XC(Brand B, BikeSize S, WheelSize W, string Name, int Price)
        {
            this.b = B;
            this.s = S;
            this.wheels = W;
            this.name = Name;
            this.price = Price;
        }
        public override string Difficulty()
        {
            return "Easy";
        }

        public override string Weight()
        {
            return "Lightweight";
        }

        public override string Trail()
        {
            return "Any gravel and easy trails. Not recomended above blue trails";
        }

    }
}