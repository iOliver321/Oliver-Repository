﻿namespace ClassLibraryBike.Classes
{
	public class Account
	{
		SQL cmd = new SQL();
		public int user_id;
		public string username;
		public string password;

		public Account(string username, string password)
		{
			this.username = username;
			this.password = password;
		}

		public void create_account()
		{
			cmd.Create_Account(username, password);
		}

		public bool Authenticate()
		{
			return false;
		}
	}
}
