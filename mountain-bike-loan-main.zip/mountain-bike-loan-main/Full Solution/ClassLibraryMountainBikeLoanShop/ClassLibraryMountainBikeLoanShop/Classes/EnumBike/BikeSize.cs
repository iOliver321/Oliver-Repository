﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBike.Classes.EnumBike
{
    enum BikeSize
    {
        XS,
        S,
        M,
        L,
        XL,
    }
}
