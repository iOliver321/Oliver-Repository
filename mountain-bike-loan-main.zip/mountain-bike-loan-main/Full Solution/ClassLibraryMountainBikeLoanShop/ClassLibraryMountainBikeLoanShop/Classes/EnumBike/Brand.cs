﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBike.Classes.EnumBike
{
    enum Brand
    {
        SANTA_CRUZ,
        CANYON,
        TREK,
        CANNONDALE,
        PIVOT,
        YT_INDUSTRIES,
        GT_BIKES,
    }
}
