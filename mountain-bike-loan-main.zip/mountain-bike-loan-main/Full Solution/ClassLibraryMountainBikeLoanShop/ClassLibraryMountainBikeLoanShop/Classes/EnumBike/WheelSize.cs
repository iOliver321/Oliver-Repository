﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibraryBike.Classes.EnumBike
{
    enum WheelSize
    {
        size1 = 26,
        size2 = 27,
        size3 = 29,
    }
}
