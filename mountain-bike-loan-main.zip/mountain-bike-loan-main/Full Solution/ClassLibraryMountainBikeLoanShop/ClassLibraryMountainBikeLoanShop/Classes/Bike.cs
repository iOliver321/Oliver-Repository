﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClassLibraryBike.Classes.EnumBike;

namespace ClassLibraryBike.Classes
{
    abstract class Bike
    {
        public int ID;
        public string status;
        public Brand b;
        public BikeSize s;
        public WheelSize wheels;
        public string name;
        public int price;

        public abstract string Trail();
        public abstract string Difficulty();
        public abstract string Weight();
    }
}
