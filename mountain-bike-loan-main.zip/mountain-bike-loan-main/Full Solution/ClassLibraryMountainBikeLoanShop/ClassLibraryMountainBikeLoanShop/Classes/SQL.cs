﻿using System.Data;
using System.Diagnostics.Metrics;
using System.Data.SqlClient;
using System.Data;
using System.Runtime.Intrinsics.X86;

namespace ClassLibraryBike.Classes
{
    public class SQL
    {
        SqlCommand cmd;
        SqlDataAdapter adapter;
        private string connection = "Server=mssqlstud.fhict.local;Database=dbi500882_database1;User Id=dbi500882_database1;Password=Oo12345678;";
        //Trust Server Certificate=true;
        public void Create_Account(string username, string password)
        {
            string querry;
            querry = "insert into Account values(@username,@password,(select max(ID) from Account)+1)";
            using (SqlConnection conn = new SqlConnection(connection))
            {
                cmd = new SqlCommand(querry, conn);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);

                conn.Open();
                cmd.ExecuteNonQuery();
                conn.Close();
            }
        }
    }
}
