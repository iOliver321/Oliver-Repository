﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage1 = new TabPage();
            dataGridView1 = new DataGridView();
            groupBox3 = new GroupBox();
            button3 = new Button();
            label13 = new Label();
            label12 = new Label();
            textBox6 = new TextBox();
            comboBox6 = new ComboBox();
            textBox5 = new TextBox();
            label11 = new Label();
            groupBox2 = new GroupBox();
            label6 = new Label();
            button2 = new Button();
            label10 = new Label();
            comboBox4 = new ComboBox();
            textBox4 = new TextBox();
            label7 = new Label();
            label9 = new Label();
            label8 = new Label();
            textBox3 = new TextBox();
            comboBox5 = new ComboBox();
            groupBox1 = new GroupBox();
            comboBox11 = new ComboBox();
            label29 = new Label();
            comboBox7 = new ComboBox();
            label15 = new Label();
            button1 = new Button();
            textBox1 = new TextBox();
            label1 = new Label();
            label2 = new Label();
            textBox2 = new TextBox();
            label3 = new Label();
            comboBox1 = new ComboBox();
            label4 = new Label();
            comboBox2 = new ComboBox();
            label5 = new Label();
            comboBox3 = new ComboBox();
            tabControl1 = new TabControl();
            tabPage2 = new TabPage();
            dataGridView2 = new DataGridView();
            groupBox4 = new GroupBox();
            textBox9 = new TextBox();
            label18 = new Label();
            label17 = new Label();
            textBox8 = new TextBox();
            button4 = new Button();
            label16 = new Label();
            textBox7 = new TextBox();
            label14 = new Label();
            tabPage3 = new TabPage();
            groupBox7 = new GroupBox();
            button9 = new Button();
            button7 = new Button();
            textBox14 = new TextBox();
            label23 = new Label();
            label24 = new Label();
            textBox15 = new TextBox();
            button8 = new Button();
            label25 = new Label();
            textBox16 = new TextBox();
            label26 = new Label();
            dataGridView3 = new DataGridView();
            groupBox6 = new GroupBox();
            button6 = new Button();
            textBox13 = new TextBox();
            label22 = new Label();
            groupBox5 = new GroupBox();
            label21 = new Label();
            monthCalendar1 = new MonthCalendar();
            button5 = new Button();
            textBox11 = new TextBox();
            label20 = new Label();
            textBox10 = new TextBox();
            label19 = new Label();
            tabPage4 = new TabPage();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox3.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            tabControl1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView2).BeginInit();
            groupBox4.SuspendLayout();
            tabPage3.SuspendLayout();
            groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).BeginInit();
            groupBox6.SuspendLayout();
            groupBox5.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(dataGridView1);
            tabPage1.Controls.Add(groupBox3);
            tabPage1.Controls.Add(groupBox2);
            tabPage1.Controls.Add(groupBox1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(768, 550);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Bike";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(255, 22);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(480, 295);
            dataGridView1.TabIndex = 25;
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(button3);
            groupBox3.Controls.Add(label13);
            groupBox3.Controls.Add(label12);
            groupBox3.Controls.Add(textBox6);
            groupBox3.Controls.Add(comboBox6);
            groupBox3.Controls.Add(textBox5);
            groupBox3.Controls.Add(label11);
            groupBox3.Location = new Point(418, 354);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(317, 158);
            groupBox3.TabIndex = 24;
            groupBox3.TabStop = false;
            groupBox3.Text = "Update Bike";
            // 
            // button3
            // 
            button3.Location = new Point(84, 129);
            button3.Name = "button3";
            button3.Size = new Size(157, 23);
            button3.TabIndex = 22;
            button3.Text = "Update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(6, 83);
            label13.Name = "label13";
            label13.Size = new Size(33, 15);
            label13.TabIndex = 11;
            label13.Text = "Price";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(13, 25);
            label12.Name = "label12";
            label12.Size = new Size(18, 15);
            label12.TabIndex = 23;
            label12.Text = "ID";
            // 
            // textBox6
            // 
            textBox6.Location = new Point(58, 80);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(100, 23);
            textBox6.TabIndex = 12;
            // 
            // comboBox6
            // 
            comboBox6.FormattingEnabled = true;
            comboBox6.Items.AddRange(new object[] { "READY", "BOOKED", "LOANED", "SERVICE" });
            comboBox6.Location = new Point(58, 51);
            comboBox6.Name = "comboBox6";
            comboBox6.Size = new Size(121, 23);
            comboBox6.TabIndex = 22;
            // 
            // textBox5
            // 
            textBox5.Location = new Point(58, 22);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 22;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(5, 55);
            label11.Name = "label11";
            label11.Size = new Size(39, 15);
            label11.TabIndex = 23;
            label11.Text = "Status";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(label6);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(label10);
            groupBox2.Controls.Add(comboBox4);
            groupBox2.Controls.Add(textBox4);
            groupBox2.Controls.Add(label7);
            groupBox2.Controls.Add(label9);
            groupBox2.Controls.Add(label8);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(comboBox5);
            groupBox2.Location = new Point(18, 354);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(383, 158);
            groupBox2.TabIndex = 23;
            groupBox2.TabStop = false;
            groupBox2.Text = "SearchBike";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(6, 17);
            label6.Name = "label6";
            label6.Size = new Size(64, 28);
            label6.TabIndex = 13;
            label6.Text = "Filters";
            // 
            // button2
            // 
            button2.Location = new Point(121, 129);
            button2.Name = "button2";
            button2.Size = new Size(157, 23);
            button2.TabIndex = 12;
            button2.Text = "See Bikes";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click_2;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(218, 86);
            label10.Name = "label10";
            label10.Size = new Size(18, 15);
            label10.TabIndex = 21;
            label10.Text = "ID";
            // 
            // comboBox4
            // 
            comboBox4.FormattingEnabled = true;
            comboBox4.Items.AddRange(new object[] { "", "READY", "BOOKED", "LOANED", "SERVICE" });
            comboBox4.Location = new Point(61, 48);
            comboBox4.Name = "comboBox4";
            comboBox4.Size = new Size(121, 23);
            comboBox4.TabIndex = 14;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(263, 83);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 20;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(8, 52);
            label7.Name = "label7";
            label7.Size = new Size(39, 15);
            label7.TabIndex = 15;
            label7.Text = "Status";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(218, 51);
            label9.Name = "label9";
            label9.Size = new Size(39, 15);
            label9.TabIndex = 19;
            label9.Text = "Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(9, 83);
            label8.Name = "label8";
            label8.Size = new Size(38, 15);
            label8.TabIndex = 16;
            label8.Text = "Brand";
            // 
            // textBox3
            // 
            textBox3.Location = new Point(263, 47);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 18;
            // 
            // comboBox5
            // 
            comboBox5.FormattingEnabled = true;
            comboBox5.Items.AddRange(new object[] { "", "SANTA_CRUZ", "CANYON", "TREK", "CANNONDALE", "PIVOT", "YT_INDUSTRIES", "GT_BIKES" });
            comboBox5.Location = new Point(61, 80);
            comboBox5.Name = "comboBox5";
            comboBox5.Size = new Size(121, 23);
            comboBox5.TabIndex = 17;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox11);
            groupBox1.Controls.Add(label29);
            groupBox1.Controls.Add(comboBox7);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(comboBox3);
            groupBox1.Location = new Point(6, 22);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(224, 304);
            groupBox1.TabIndex = 22;
            groupBox1.TabStop = false;
            groupBox1.Text = "Add Bike";
            // 
            // comboBox11
            // 
            comboBox11.FormattingEnabled = true;
            comboBox11.Items.AddRange(new object[] { "True", "False" });
            comboBox11.Location = new Point(73, 221);
            comboBox11.Name = "comboBox11";
            comboBox11.Size = new Size(121, 23);
            comboBox11.TabIndex = 14;
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(12, 224);
            label29.Name = "label29";
            label29.Size = new Size(36, 15);
            label29.TabIndex = 13;
            label29.Text = "Yesus";
            // 
            // comboBox7
            // 
            comboBox7.FormattingEnabled = true;
            comboBox7.Items.AddRange(new object[] { "XC", "TRAIL", "ENDURO", "DOWNHILL" });
            comboBox7.Location = new Point(78, 122);
            comboBox7.Name = "comboBox7";
            comboBox7.Size = new Size(121, 23);
            comboBox7.TabIndex = 12;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(6, 125);
            label15.Name = "label15";
            label15.Size = new Size(31, 15);
            label15.TabIndex = 11;
            label15.Text = "Type";
            // 
            // button1
            // 
            button1.Location = new Point(41, 254);
            button1.Name = "button1";
            button1.Size = new Size(122, 32);
            button1.TabIndex = 10;
            button1.Text = "Add Bike";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click_2;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(78, 35);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(11, 35);
            label1.Name = "label1";
            label1.Size = new Size(39, 15);
            label1.TabIndex = 1;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 67);
            label2.Name = "label2";
            label2.Size = new Size(33, 15);
            label2.TabIndex = 2;
            label2.Text = "Price";
            // 
            // textBox2
            // 
            textBox2.Location = new Point(78, 64);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 3;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(12, 101);
            label3.Name = "label3";
            label3.Size = new Size(38, 15);
            label3.TabIndex = 4;
            label3.Text = "Brand";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "SANTA_CRUZ", "CANYON", "TREK", "CANNONDALE", "PIVOT", "YT_INDUSTRIES", "GT_BIKES" });
            comboBox1.Location = new Point(78, 93);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(121, 23);
            comboBox1.TabIndex = 5;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(6, 190);
            label4.Name = "label4";
            label4.Size = new Size(49, 15);
            label4.TabIndex = 6;
            label4.Text = "BikeSize";
            // 
            // comboBox2
            // 
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "XS", "S", "M", "L", "XL" });
            comboBox2.Location = new Point(78, 187);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(121, 23);
            comboBox2.TabIndex = 7;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(6, 159);
            label5.Name = "label5";
            label5.Size = new Size(60, 15);
            label5.TabIndex = 8;
            label5.Text = "WheelSize";
            // 
            // comboBox3
            // 
            comboBox3.FormattingEnabled = true;
            comboBox3.Items.AddRange(new object[] { "26", "27", "29" });
            comboBox3.Location = new Point(78, 156);
            comboBox3.Name = "comboBox3";
            comboBox3.Size = new Size(121, 23);
            comboBox3.TabIndex = 9;
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Location = new Point(12, 33);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(776, 578);
            tabControl1.TabIndex = 0;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(dataGridView2);
            tabPage2.Controls.Add(groupBox4);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(768, 550);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Bookings";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            dataGridView2.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView2.Location = new Point(26, 30);
            dataGridView2.Name = "dataGridView2";
            dataGridView2.RowTemplate.Height = 25;
            dataGridView2.Size = new Size(717, 370);
            dataGridView2.TabIndex = 3;
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(textBox9);
            groupBox4.Controls.Add(label18);
            groupBox4.Controls.Add(label17);
            groupBox4.Controls.Add(textBox8);
            groupBox4.Controls.Add(button4);
            groupBox4.Controls.Add(label16);
            groupBox4.Controls.Add(textBox7);
            groupBox4.Controls.Add(label14);
            groupBox4.Location = new Point(35, 424);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(515, 100);
            groupBox4.TabIndex = 2;
            groupBox4.TabStop = false;
            groupBox4.Text = "Bookings";
            // 
            // textBox9
            // 
            textBox9.Location = new Point(399, 24);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(100, 23);
            textBox9.TabIndex = 25;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(345, 27);
            label18.Name = "label18";
            label18.Size = new Size(48, 15);
            label18.TabIndex = 24;
            label18.Text = "Book ID";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(159, 60);
            label17.Name = "label17";
            label17.Size = new Size(43, 15);
            label17.TabIndex = 23;
            label17.Text = "Bike ID";
            // 
            // textBox8
            // 
            textBox8.Location = new Point(239, 56);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(100, 23);
            textBox8.TabIndex = 22;
            // 
            // button4
            // 
            button4.Location = new Point(17, 56);
            button4.Name = "button4";
            button4.Size = new Size(123, 23);
            button4.TabIndex = 1;
            button4.Text = "See Bookings";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click_1;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(159, 30);
            label16.Name = "label16";
            label16.Size = new Size(60, 15);
            label16.TabIndex = 21;
            label16.Text = "Username";
            // 
            // textBox7
            // 
            textBox7.Location = new Point(239, 24);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(100, 23);
            textBox7.TabIndex = 20;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(17, 19);
            label14.Name = "label14";
            label14.Size = new Size(64, 28);
            label14.TabIndex = 14;
            label14.Text = "Filters";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(groupBox7);
            tabPage3.Controls.Add(dataGridView3);
            tabPage3.Controls.Add(groupBox6);
            tabPage3.Controls.Add(groupBox5);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(768, 550);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Rents";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            groupBox7.Controls.Add(button9);
            groupBox7.Controls.Add(button7);
            groupBox7.Controls.Add(textBox14);
            groupBox7.Controls.Add(label23);
            groupBox7.Controls.Add(label24);
            groupBox7.Controls.Add(textBox15);
            groupBox7.Controls.Add(button8);
            groupBox7.Controls.Add(label25);
            groupBox7.Controls.Add(textBox16);
            groupBox7.Controls.Add(label26);
            groupBox7.Location = new Point(6, 280);
            groupBox7.Name = "groupBox7";
            groupBox7.Size = new Size(359, 156);
            groupBox7.TabIndex = 4;
            groupBox7.TabStop = false;
            groupBox7.Text = "Rents";
            // 
            // button9
            // 
            button9.Location = new Point(17, 127);
            button9.Name = "button9";
            button9.Size = new Size(123, 23);
            button9.TabIndex = 27;
            button9.Text = "Past Rents";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // button7
            // 
            button7.Location = new Point(17, 98);
            button7.Name = "button7";
            button7.Size = new Size(123, 23);
            button7.TabIndex = 26;
            button7.Text = "Active Rents";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(236, 118);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(100, 23);
            textBox14.TabIndex = 25;
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(156, 118);
            label23.Name = "label23";
            label23.Size = new Size(47, 15);
            label23.TabIndex = 24;
            label23.Text = "Loan ID";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(156, 89);
            label24.Name = "label24";
            label24.Size = new Size(43, 15);
            label24.TabIndex = 23;
            label24.Text = "Bike ID";
            // 
            // textBox15
            // 
            textBox15.Location = new Point(236, 85);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(100, 23);
            textBox15.TabIndex = 22;
            // 
            // button8
            // 
            button8.Location = new Point(17, 56);
            button8.Name = "button8";
            button8.Size = new Size(123, 23);
            button8.TabIndex = 1;
            button8.Text = "See Rents";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(156, 59);
            label25.Name = "label25";
            label25.Size = new Size(60, 15);
            label25.TabIndex = 21;
            label25.Text = "Username";
            // 
            // textBox16
            // 
            textBox16.Location = new Point(236, 53);
            textBox16.Name = "textBox16";
            textBox16.Size = new Size(100, 23);
            textBox16.TabIndex = 20;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Font = new Font("Segoe UI", 15F, FontStyle.Regular, GraphicsUnit.Point);
            label26.Location = new Point(17, 19);
            label26.Name = "label26";
            label26.Size = new Size(64, 28);
            label26.TabIndex = 14;
            label26.Text = "Filters";
            // 
            // dataGridView3
            // 
            dataGridView3.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView3.Location = new Point(381, 270);
            dataGridView3.Name = "dataGridView3";
            dataGridView3.RowTemplate.Height = 25;
            dataGridView3.Size = new Size(319, 244);
            dataGridView3.TabIndex = 2;
            // 
            // groupBox6
            // 
            groupBox6.Controls.Add(button6);
            groupBox6.Controls.Add(textBox13);
            groupBox6.Controls.Add(label22);
            groupBox6.Location = new Point(484, 22);
            groupBox6.Name = "groupBox6";
            groupBox6.Size = new Size(264, 220);
            groupBox6.TabIndex = 1;
            groupBox6.TabStop = false;
            groupBox6.Text = "Return Bike";
            // 
            // button6
            // 
            button6.Location = new Point(69, 169);
            button6.Name = "button6";
            button6.Size = new Size(75, 23);
            button6.TabIndex = 9;
            button6.Text = "Return Bike";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(97, 99);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(100, 23);
            textBox13.TabIndex = 6;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(42, 102);
            label22.Name = "label22";
            label22.Size = new Size(18, 15);
            label22.TabIndex = 5;
            label22.Text = "ID";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(label21);
            groupBox5.Controls.Add(monthCalendar1);
            groupBox5.Controls.Add(button5);
            groupBox5.Controls.Add(textBox11);
            groupBox5.Controls.Add(label20);
            groupBox5.Controls.Add(textBox10);
            groupBox5.Controls.Add(label19);
            groupBox5.Location = new Point(23, 22);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(436, 220);
            groupBox5.TabIndex = 0;
            groupBox5.TabStop = false;
            groupBox5.Text = "Rent Bike";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(32, 126);
            label21.Name = "label21";
            label21.Size = new Size(150, 15);
            label21.TabIndex = 6;
            label21.Text = "Select expected return date";
            // 
            // monthCalendar1
            // 
            monthCalendar1.Location = new Point(197, 15);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.TabIndex = 5;
            // 
            // button5
            // 
            button5.Location = new Point(97, 179);
            button5.Name = "button5";
            button5.Size = new Size(75, 23);
            button5.TabIndex = 4;
            button5.Text = "Rent Bike ";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(70, 73);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(100, 23);
            textBox11.TabIndex = 3;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(4, 76);
            label20.Name = "label20";
            label20.Size = new Size(60, 15);
            label20.TabIndex = 2;
            label20.Text = "Username";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(30, 32);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(100, 23);
            textBox10.TabIndex = 1;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(6, 32);
            label19.Name = "label19";
            label19.Size = new Size(18, 15);
            label19.TabIndex = 0;
            label19.Text = "ID";
            // 
            // tabPage4
            // 
            tabPage4.Location = new Point(4, 24);
            tabPage4.Name = "tabPage4";
            tabPage4.Padding = new Padding(3);
            tabPage4.Size = new Size(768, 550);
            tabPage4.TabIndex = 3;
            tabPage4.Text = "Accounts";
            tabPage4.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 623);
            Controls.Add(tabControl1);
            Name = "Form1";
            Text = "Form1";
            tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            tabControl1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dataGridView2).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            tabPage3.ResumeLayout(false);
            groupBox7.ResumeLayout(false);
            groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)dataGridView3).EndInit();
            groupBox6.ResumeLayout(false);
            groupBox6.PerformLayout();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabPage1;
        private GroupBox groupBox3;
        private Button button3;
        private Label label13;
        private Label label12;
        private TextBox textBox6;
        private ComboBox comboBox6;
        private TextBox textBox5;
        private Label label11;
        private GroupBox groupBox2;
        private Label label6;
        private Button button2;
        private Label label10;
        private ComboBox comboBox4;
        private TextBox textBox4;
        private Label label7;
        private Label label9;
        private Label label8;
        private TextBox textBox3;
        private ComboBox comboBox5;
        private GroupBox groupBox1;
        private ComboBox comboBox7;
        private Label label15;
        private Button button1;
        private TextBox textBox1;
        private Label label1;
        private Label label2;
        private TextBox textBox2;
        private Label label3;
        private ComboBox comboBox1;
        private Label label4;
        private ComboBox comboBox2;
        private Label label5;
        private ComboBox comboBox3;
        private TabControl tabControl1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private Button button4;
        private GroupBox groupBox4;
        private TextBox textBox9;
        private Label label18;
        private Label label17;
        private TextBox textBox8;
        private Label label16;
        private TextBox textBox7;
        private Label label14;
        private DataGridView dataGridView1;
        private DataGridView dataGridView2;
        private GroupBox groupBox6;
        private GroupBox groupBox5;
        private TextBox textBox10;
        private Label label19;
        private TextBox textBox11;
        private Label label20;
        private Button button6;
        private TextBox textBox13;
        private Label label22;
        private Button button5;
        private Button button7;
        private GroupBox groupBox7;
        private TextBox textBox14;
        private Label label23;
        private Label label24;
        private TextBox textBox15;
        private Button button8;
        private Label label25;
        private TextBox textBox16;
        private Label label26;
        private DataGridView dataGridView3;
        private Button button9;
        private ComboBox comboBox11;
        private Label label29;
        private Label label21;
        private MonthCalendar monthCalendar1;
    }
}