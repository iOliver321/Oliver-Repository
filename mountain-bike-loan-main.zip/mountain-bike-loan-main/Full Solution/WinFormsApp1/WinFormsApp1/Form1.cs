using System.Xml.Linq;
using BusinessLayer.Classes.Bikes;
using BusinessLayer.Classes.EnumBike;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data;
using System.Diagnostics;
using BusinessLayer.Object;
using BusinessLayer.Managers;
using BusinessLayer.Interfaces;
using DataLayer;
using BusinessLayer.Interfaces.Filters;
using BusinessLayer.Managers.Filters;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        IBikeDataInterface bikeDataInterface = new SQLBike();
        IBookDataInterface bookDataInterface = new SQLBook();
        ILoanDataInterface loanDataInterface = new SQLLoan();


        BikeManager bcc;
        BookManager bookcc;
        LoanManager loancc;
        public Form1()
        {
            InitializeComponent();
            bcc = new BikeManager(bikeDataInterface);
            bookcc = new BookManager(bookDataInterface);
            loancc = new LoanManager(loanDataInterface);

            bcc.BikeAdded += Bcc_BikeAdded;

            Load += Form1_Load; //Load event handler
        }

        private void Bcc_BikeAdded(Bike bike)
        {

            DisplayAllBikes();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisplayAllBikes();
        }

        private void DisplayAllBikes()
        {
            List<Bike> bikes = bcc.return_bikes();
            DataTable bikesTable = new DataTable();

            // Add columns to the DataTable
            bikesTable.Columns.Add("ID");
            bikesTable.Columns.Add("Brand");
            bikesTable.Columns.Add("Name");
            bikesTable.Columns.Add("Frame Size");
            bikesTable.Columns.Add("Wheel Size");
            bikesTable.Columns.Add("Price (per day)");
            bikesTable.Columns.Add("Status");

            foreach (Bike bike in bikes)
            {
                string brand_raw = bike.return_brand();
                brand_raw = brand_raw.Replace("_", " ");
                string brand_corrected = "";

                List<char> letters = new List<char>();
                for (int i = 0; i < brand_raw.Length; i++)
                {
                    letters.Add(brand_raw[i]);
                }

                for (int i = 1; i < brand_raw.Count(); i++)
                {
                    if (letters[i - 1] != 32)
                    {
                        letters[i] = Char.ToLower(letters[i]);
                    }
                }
                foreach (char c in letters)
                {
                    brand_corrected = brand_corrected + c;
                }

                DataRow row = bikesTable.NewRow();
                row["ID"] = bike.return_id();
                row["Brand"] = brand_corrected;
                row["Name"] = bike.return_name();
                row["Frame Size"] = bike.return_bike_size();
                row["Wheel Size"] = bike.return_wheel_size();
                row["Price (per day)"] = bike.return_price();
                row["Status"] = bike.return_status();
                bikesTable.Rows.Add(row);
            }

            dataGridView1.DataSource = bikesTable;
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            int price = Convert.ToInt32(textBox2.Text);
            string brand0 = textBox3.Text;
            string wheelsize0 = textBox4.Text;
            string bikesize0 = textBox5.Text;
            Brand brand = (Brand)Enum.Parse(typeof(Brand), brand0);
            WheelSize wheelsize = (WheelSize)Enum.Parse(typeof(WheelSize), wheelsize0);
            BikeSize bikesize = (BikeSize)Enum.Parse(typeof(BikeSize), bikesize0);
            bool yesus = Convert.ToBoolean(comboBox11.Text);
            switch (comboBox7.Text)
            {
                case "Downhill":
                    bcc.add_bike_downhill(brand, bikesize, wheelsize, name, price, yesus);
                    break;
                case "Enduro":
                    bcc.add_bike_enduro(brand, bikesize, wheelsize, name, price, yesus);
                    break;
                case "XC":
                    bcc.add_bike_xc(brand, bikesize, wheelsize, name, price, yesus);
                    break;
                case "Trail":
                    bcc.add_bike_trail(brand, bikesize, wheelsize, name, price, yesus);
                    break;
            }
        }

        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            List<Bike> bikes = bcc.return_bikes();
            //listBox1.Items.Clear();
            foreach (Bike bike in bikes)
            {
                MessageBox.Show(bike.return_name());
                //listBox1.Items.Add(bike.return_brand() + " " + bike.return_name() + " Frame Size: " + bike.return_bike_size() + " Wheel Size: " + bike.return_wheel_size() + " Price (per day): " + bike.return_price() + " Status: " + bike.return_status());
            }

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string status;
            if (comboBox4.Text != "")
            {
                status = comboBox4.Text;
            }
            else
            {
                status = "clear";
            }
            string name;
            if (textBox3.Text != "")
            {
                name = textBox3.Text;
            }
            else
            {
                name = "clear";
            }
            string brand;
            if (comboBox5.Text != "")
            {
                brand = comboBox5.Text;
            }
            else
            {
                brand = "clear";
            }
            int id;
            if (textBox4.Text != "")
            {
                id = Convert.ToInt32(textBox4.Text);
            }
            else
            {
                id = 0;
            }
            List<Bike> bikes = bcc.search_engine(status, name, brand, id);
            //listBox1.Items.Clear();
            foreach (Bike bike in bikes)
            {
                //listBox1.Items.Add(bike.return_brand() + " " + bike.return_name() + " Frame Size: " + bike.return_bike_size() + " Wheel Size: " + bike.return_wheel_size() + " Price (per day): " + bike.return_price() + " Status: " + bike.return_status());
            }
        }

        /*private void button1_Click_1(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            int price;
            Brand brand;
            WheelSize wheelsize;
            BikeSize bikesize;
            bool isValid = true;

            // Check the name input
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("You need a valid name for the Bike");
                isValid = false;
            }

            // Check the price input
            if (!int.TryParse(textBox2.Text, out price))
            {
                MessageBox.Show("You need a valid price for the Bike");
                isValid = false;
            }

            // Check the brand input
            if (!Enum.TryParse<Brand>(comboBox1.Text, out brand))
            {
                MessageBox.Show("You need to select a valid brand for the Bike");
                isValid = false;
            }

            // Check the wheel size input
            if (!Enum.TryParse<WheelSize>(comboBox3.Text, out wheelsize))
            {
                MessageBox.Show("You need to select a valid Wheel Size for the Bike");
                isValid = false;
            }

            // Check the bike size input
            if (!Enum.TryParse<BikeSize>(comboBox2.Text, out bikesize))
            {
                MessageBox.Show("You need to select a valid Frame Size for the Bike");
                isValid = false;
            }

            if (isValid)
            {
                switch (comboBox7.Text)
                {
                    case "DOWNHILL":
                        bcc.add_bike_downhill(brand, bikesize, wheelsize, name, price);
                        break;
                    case "ENDURO":
                        bcc.add_bike_enduro(brand, bikesize, wheelsize, name, price);
                        break;
                    case "XC":
                        bcc.add_bike_xc(brand, bikesize, wheelsize, name, price);
                        break;
                    case "TRAIL":
                        bcc.add_bike_trail(brand, bikesize, wheelsize, name, price);
                        break;
                }
                MessageBox.Show(brand + " " + name + " was added successfully");
            }
        }*/

        private void button4_Click(object sender, EventArgs e)
        {
            //listBox2.Items.Clear();
            string username;
            if (textBox7.Text != "")
            {
                username = textBox7.Text;
            }
            else
            {
                username = "clear";
            }
            int bike_id;
            if (textBox8.Text != "")
            {
                bike_id = Convert.ToInt32(textBox8.Text);
            }
            else
            {
                bike_id = 0;
            }
            int id;
            if (textBox9.Text != "")
            {
                id = Convert.ToInt32(textBox9.Text);
            }
            else
            {
                id = 0;
            }

            List<Book> books = bookcc.search_engine(username, id, bike_id);
            foreach (Book book in books)
            {
                //listBox2.Items.Add("ID: "+ book.return_id()+" Username: "+book.return_username()+" BikeID: "+book.return_bike_id());
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox5.Text == "")
            {
                MessageBox.Show("You need to insert a valid ID");
            }
            else
            {
                int price;
                if (textBox6.Text != "")
                {
                    price = Convert.ToInt32(textBox6.Text);
                }
                else
                {
                    price = 0;
                }

                if (bcc.update_bike(Convert.ToInt32(textBox5.Text), comboBox6.Text, price))
                {
                    MessageBox.Show("Bike was updated successfully");
                }
                else
                {
                    MessageBox.Show("Warning! Bike was not updated");
                }

            }

        }

        private void button2_Click_2(object sender, EventArgs e)
        {
            List<Bike> bikes = bcc.update_bikes();
            Filter filter = new Filter();

            

            int id;
            if (textBox4.Text != "")
            {
                id = Convert.ToInt32(textBox4.Text);

                IFilter cmd = new filter_id(bikes, id);
                bikes = cmd.return_filtered_bikes();
                //Bike bike = filter.filter_id(bikes, id);
            }
            else
            {
                string status;
                if (comboBox4.Text != "")
                {
                    status = comboBox4.Text;
                    IFilter filterStatus = new filter_status(bikes, status);
                    bikes = filterStatus.return_filtered_bikes();
                    //bikes = filter.filter_status(bikes, status);
                }

                string name;
                if (textBox3.Text != "")
                {
                    name = textBox3.Text;
                    IFilter filterName = new filter_name(bikes, name);
                    bikes = filterName.return_filtered_bikes();
                    //bikes = filter.filter_name(bikes, name);
                }

                string brand;
                if (comboBox5.Text != "")
                {
                    brand = comboBox5.Text;
                    IFilter filterBrand = new filter_brand(bikes, brand);
                    bikes = filterBrand.return_filtered_bikes();
                    //bikes = filter.filter_brand(bikes, brand);
                }
            }

            // Create a new DataTable
            DataTable bikesTable = new DataTable();

            // Add columns to the DataTable
            bikesTable.Columns.Add("ID");
            bikesTable.Columns.Add("Brand");
            bikesTable.Columns.Add("Name");
            bikesTable.Columns.Add("Frame Size");
            bikesTable.Columns.Add("Wheel Size");
            bikesTable.Columns.Add("Price (per day)");
            bikesTable.Columns.Add("Status");

            foreach (Bike bike in bikes)
            {
                string brand_raw = bike.return_brand();
                brand_raw = brand_raw.Replace("_", " ");
                string brand_corrected = "";

                List<char> letters = new List<char>();
                for (int i = 0; i < brand_raw.Length; i++)
                {
                    letters.Add(brand_raw[i]);
                }

                for (int i = 1; i < brand_raw.Count(); i++)
                {
                    if (letters[i - 1] != 32)
                    {
                        letters[i] = Char.ToLower(letters[i]);
                    }
                }
                foreach (char c in letters)
                {
                    brand_corrected = brand_corrected + c;
                }

                // Create a new row
                DataRow row = bikesTable.NewRow();

                // Populate the row with data from the bike object
                row["ID"] = bike.return_id();
                row["Brand"] = brand_corrected;
                row["Name"] = bike.return_name();
                row["Frame Size"] = bike.return_bike_size();
                row["Wheel Size"] = bike.return_wheel_size();
                row["Price (per day)"] = bike.return_price();
                row["Status"] = bike.return_status();

                // Add the row to the DataTable
                bikesTable.Rows.Add(row);
            }

            // Set the DataSource property of the DataGridView to the DataTable
            dataGridView1.DataSource = bikesTable;
        }


        private void button1_Click_2(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            int price;
            Brand brand;
            WheelSize wheelsize;
            BikeSize bikesize;
            bool isValid = true;
            bool yesus = Convert.ToBoolean(comboBox11.Text);

            // Check the name input
            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("You need a valid name for the Bike");
                isValid = false;
            }

            // Check the price input
            if (!int.TryParse(textBox2.Text, out price))
            {
                MessageBox.Show("You need a valid price for the Bike");
                isValid = false;
            }

            // Check the brand input
            if (!Enum.TryParse<Brand>(comboBox1.Text, out brand))
            {
                MessageBox.Show("You need to select a valid brand for the Bike");
                isValid = false;
            }

            // Check the wheel size input
            if (!Enum.TryParse<WheelSize>(comboBox3.Text, out wheelsize))
            {
                MessageBox.Show("You need to select a valid Wheel Size for the Bike");
                isValid = false;
            }

            // Check the bike size input
            if (!Enum.TryParse<BikeSize>(comboBox2.Text, out bikesize))
            {
                MessageBox.Show("You need to select a valid Frame Size for the Bike");
                isValid = false;
            }

            if (isValid)
            {
                switch (comboBox7.Text)
                {
                    case "DOWNHILL":
                        bcc.add_bike_downhill(brand, bikesize, wheelsize, name, price, yesus);
                        break;
                    case "ENDURO":
                        bcc.add_bike_enduro(brand, bikesize, wheelsize, name, price, yesus);
                        break;
                    case "XC":
                        bcc.add_bike_xc(brand, bikesize, wheelsize, name, price, yesus);
                        break;
                    case "TRAIL":
                        bcc.add_bike_trail(brand, bikesize, wheelsize, name, price, yesus);
                        break;
                }
                MessageBox.Show(brand + " " + name + " was added successfully");
            }
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Username");
            dt.Columns.Add("BikeID");

            string username;
            if (textBox7.Text != "")
            {
                username = textBox7.Text;
            }
            else
            {
                username = "clear";
            }
            int bike_id;
            if (textBox8.Text != "")
            {
                bike_id = Convert.ToInt32(textBox8.Text);
            }
            else
            {
                bike_id = 0;
            }
            int id;
            if (textBox9.Text != "")
            {
                id = Convert.ToInt32(textBox9.Text);
            }
            else
            {
                id = 0;
            }

            List<Book> books = bookcc.search_engine(username, id, bike_id);
            foreach (Book book in books)
            {
                DataRow row = dt.NewRow();
                row["ID"] = book.return_id();
                row["Username"] = book.return_username();
                row["BikeID"] = book.return_bike_id();
                dt.Rows.Add(row);
            }

            dataGridView2.DataSource = dt;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string username;
            if (textBox16.Text != "")
            {
                username = textBox16.Text;
            }
            else
            {
                username = "clear";
            }
            int bike_id;
            if (textBox15.Text != "")
            {
                bike_id = Convert.ToInt32(textBox15.Text);
            }
            else
            {
                bike_id = 0;
            }
            int id;
            if (textBox14.Text != "")
            {
                id = Convert.ToInt32(textBox14.Text);
            }
            else
            {
                id = 0;
            }

            List<Loan> loans = loancc.search_engine(id, bike_id, username);
            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Username");
            dt.Columns.Add("BikeID");
            dt.Columns.Add("Loan Date");
            dt.Columns.Add("Return Date");
            foreach (Loan loan in loans)
            {
                DataRow row = dt.NewRow();
                row["ID"] = loan.return_id();
                row["Username"] = loan.return_username();
                row["BikeID"] = loan.return_bike_id();
                row["Loan Date"] = loan.return_loan_date();
                row["Return Date"] = loan.return_return_date();
                dt.Rows.Add(row);

            }
            dataGridView3.DataSource = dt;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            List<Loan> loans = loancc.return_active_loans();
            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Username");
            dt.Columns.Add("BikeID");
            dt.Columns.Add("Loan Date");
            dt.Columns.Add("Return Date");
            foreach (Loan loan in loans)
            {
                DataRow row = dt.NewRow();
                row["ID"] = loan.return_id();
                row["Username"] = loan.return_username();
                row["BikeID"] = loan.return_bike_id();
                row["Loan Date"] = loan.return_loan_date();
                row["Return Date"] = loan.return_return_date();
                dt.Rows.Add(row);

            }
            dataGridView3.DataSource = dt;
        }

        private void button9_Click(object sender, EventArgs e)
        {
            List<Loan> loans = loancc.return_past_loans();
            DataTable dt = new DataTable();
            dt.Columns.Add("ID");
            dt.Columns.Add("Username");
            dt.Columns.Add("BikeID");
            dt.Columns.Add("Loan Date");
            dt.Columns.Add("Return Date");
            dt.Columns.Add("Expected Return Date");
            foreach (Loan loan in loans)
            {
                DataRow row = dt.NewRow();
                row["ID"] = loan.return_id();
                row["Username"] = loan.return_username();
                row["BikeID"] = loan.return_bike_id();
                row["Loan Date"] = loan.return_loan_date();
                row["Return Date"] = loan.return_return_date();
                row["Expected Return Date"] = loan.return_expected_return_date();
                dt.Rows.Add(row);

            }
            dataGridView3.DataSource = dt;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(textBox10.Text);
            string username = textBox11.Text;
            DateTime expected_return_date = monthCalendar1.SelectionRange.Start;

            if (bcc.update_bike(Convert.ToInt32(textBox10.Text), "LOANED", 0))
            {
                if (loancc.add_loan(id, username, expected_return_date))
                {
                    MessageBox.Show("Loan was successfull");
                }
                else
                {
                    MessageBox.Show("Warning! Loan was unsuccessfull");
                }
            }
            else
            {
                MessageBox.Show("Warning! Loan was unsuccessfull(bike)");
            }

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (loancc.return_bike(Convert.ToInt32(textBox13.Text)))
            {
                MessageBox.Show("Bike returned successfully");
            }
            else
            {
                MessageBox.Show("Bike was unable to return");
            }
        }
    }
}