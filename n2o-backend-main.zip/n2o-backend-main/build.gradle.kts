plugins {
    id("org.springframework.boot") version "3.1.0"
    id("io.spring.dependency-management") version "1.1.0"
    id("java")
    id("org.sonarqube") version "5.1.0.4882"
    id("jacoco")
}

group = "nl.fontys.s3"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    implementation("org.projectlombok:lombok:1.18.28")
    implementation("org.springframework.boot:spring-boot-starter-data-jpa")
    testImplementation(platform("org.junit:junit-bom:5.9.1"))
    testImplementation("org.junit.jupiter:junit-jupiter")





    implementation("org.springframework.boot:spring-boot-starter")
    implementation("org.springframework.boot:spring-boot-starter-web")
    testImplementation("org.springframework.boot:spring-boot-starter-test")

    implementation("org.projectlombok:lombok:1.18.28")
    annotationProcessor("org.projectlombok:lombok:1.18.28")
    testImplementation("org.projectlombok:lombok:1.18.28")
    testAnnotationProcessor("org.projectlombok:lombok:1.18.28")

    implementation("org.springframework.boot:spring-boot-starter-validation")

    implementation("org.springframework.boot:spring-boot-starter-data-jpa")
    implementation("mysql:mysql-connector-java:8.0.33")


    implementation("org.springframework.boot:spring-boot-starter-security")

    implementation("io.jsonwebtoken:jjwt-api:0.11.5") // For JWT API
    implementation("io.jsonwebtoken:jjwt-impl:0.11.5") // For JWT Implementation
    implementation("io.jsonwebtoken:jjwt-jackson:0.11.5") // Optional: For Jackson support

    implementation("org.springframework.boot:spring-boot-starter-websocket")

    // implementation ("com.redgate.flyway:flyway-mysql")

    implementation("org.flywaydb:flyway-core:10.0.0")
    implementation("org.flywaydb:flyway-mysql:10.0.0")
    implementation("mysql:mysql-connector-java:8.0.33")

    testImplementation("org.assertj:assertj-core:3.24.2")




}
sonar {
    properties {
        property("sonar.projectKey", "Back-End-N2O")
        property("sonar.projectName", "Back-End N2O")
        property("sonar.host.url", "http://host.docker.internal:9000")
        //property("sonar.host.url", "http://localhost:9000")
        property("sonar.token", "sqp_88f11dc92d93e14148470216129547469f1d4e70")
        property("sonar.qualitygate.wait", true)
        property("sonar.tests", "src/test/java") // Adjust if your tests are in a different directory
        //property("sonar.jacoco.reportPaths", "${buildDir}/jacoco/test.exec") // Ensure the path is correct
        property("sonar.kotlin.coverage.reportPaths", "${buildDir}/reports/jacoco/test/jacocoTestReport.xml") // Add this for Kotlin support
        property("sonar.sources", "src/main/java") // Adjust according to your project structure
        property("sonar.inclusions", "src/main/java/n2o/business/**")
    }
}

tasks.named<Test>("test") {
    useJUnitPlatform()
    finalizedBy("jacocoTestReport")
}


tasks.jacocoTestReport {
    // Configure the reports
    reports {
        xml.required.set(true) // Enable XML report
        html.required.set(true) // Enable HTML report (optional)
    }
}


jacoco {
    toolVersion = "0.8.7" // Set this to the latest version available
}