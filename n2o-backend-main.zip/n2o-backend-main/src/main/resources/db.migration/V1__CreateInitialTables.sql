-- Table for Engine
CREATE TABLE dbi500882.engine (
                        code CHAR(10) NOT NULL,
                        capacity BIGINT,
                        cylinders BIGINT,
                        fuelType VARCHAR(50),
                        PRIMARY KEY (code)
);

-- Table for Car
CREATE TABLE dbi500882.car (
                     id BIGINT NOT NULL AUTO_INCREMENT,
                     brand VARCHAR(50),
                     name VARCHAR(50),
                     year BIGINT,
                     engine_code CHAR(10) NOT NULL,
                     PRIMARY KEY (id),
                     FOREIGN KEY (engine_code) REFERENCES engine (code)
);

-- Table for Tune
CREATE TABLE dbi500882.tune (
                      id BIGINT NOT NULL AUTO_INCREMENT,
                      engine_code CHAR(10) NOT NULL,
                      stockHorsepower BIGINT,
                      stockTorque BIGINT,
                      tunedHorsepower BIGINT,
                      tunedTorque BIGINT,
                      price BIGINT,
                      PRIMARY KEY (id),
                      UNIQUE (engine_code),
                      FOREIGN KEY (engine_code) REFERENCES engine (code)
);

-- Table for User
CREATE TABLE dbi500882.user (
                        id BIGINT NOT NULL AUTO_INCREMENT,
                        username VARCHAR(20) NOT NULL,
                        password VARCHAR(100),
                        PRIMARY KEY (id),
                        UNIQUE (username)
);

-- Table for User Role
CREATE TABLE dbi500882.user_role (
                           id BIGINT NOT NULL AUTO_INCREMENT,
                           role_name VARCHAR(50) NOT NULL,
                           user_id BIGINT NOT NULL,
                           PRIMARY KEY (id),
                           FOREIGN KEY (user_id) REFERENCES "user" (id)
);
