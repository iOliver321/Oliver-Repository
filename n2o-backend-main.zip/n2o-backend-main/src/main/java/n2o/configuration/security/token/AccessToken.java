package n2o.configuration.security.token;

import java.util.Set;

public interface AccessToken {
    String getName();

    Set<String> getRoles();



    boolean hasRole(String roleName);
}
