package n2o.configuration.security.token.impl;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import n2o.configuration.security.token.AccessToken;

import java.util.Collection;
import java.util.Collections;
import java.util.Set;

@EqualsAndHashCode
@Getter
public class AccessTokenImpl implements AccessToken {
    private final String Name;
    private final Set<String> roles;

    public AccessTokenImpl(String name,Collection<String> roles) {
        this.Name = name;
        this.roles = roles != null ? Set.copyOf(roles) : Collections.emptySet();
    }

    @Override
    public boolean hasRole(String roleName)
    {
        return this.roles.contains(roleName);
    }
}
