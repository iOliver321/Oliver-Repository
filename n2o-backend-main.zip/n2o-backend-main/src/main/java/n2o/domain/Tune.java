package n2o.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Tune {
    private Engine engine;
    private Long stockHorsepower;
    private Long stockTorque;
    private Long tunedHorsepower;
    private Long tunedTorque;
    private Long price;
}
