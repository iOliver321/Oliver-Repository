package n2o.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class Engine {
    private String code;
    private Long capacity;
    private Long cylinders;
    private String fuelType;
}
