package n2o.persistence;

import n2o.persistence.entity.EngineEntity;
import n2o.persistence.entity.TuneEntity;
import n2o.persistence.entity.UserEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TuneRepository extends JpaRepository<TuneEntity,Long> {
    void deleteByEngine(EngineEntity engineEntity);
    void deleteById(Long id);
    TuneEntity findByEngine(EngineEntity engineEntity);
}
