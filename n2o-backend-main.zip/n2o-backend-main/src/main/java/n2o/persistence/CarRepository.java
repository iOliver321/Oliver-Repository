package n2o.persistence;

import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CarRepository extends JpaRepository<CarEntity, Long> {
    void deleteById(Long Id);
}
