package n2o.persistence.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.boot.autoconfigure.flyway.FlywayDataSource;


@Entity
@Table(name = "engine")
@Data
@Builder
@AllArgsConstructor
public class EngineEntity
{
    @Id
    @NotBlank
    @Column(name = "code")
    String code;

    @Column(name = "capacity")
    Long capacity;

    @Column(name = "cylinders")
    Long cylinders;

    @Column(name = "fuelType")
    String fuelType;

    public EngineEntity(){

    }

}
