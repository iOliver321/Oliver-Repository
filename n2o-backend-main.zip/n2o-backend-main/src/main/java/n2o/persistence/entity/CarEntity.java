package n2o.persistence.entity;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import n2o.domain.Engine;
import org.springframework.boot.autoconfigure.flyway.FlywayDataSource;

@Entity
@Table(name = "car")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@FlywayDataSource
public class CarEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Long id;

    @NotBlank
    @Size(max = 100)
    @Column(name = "brand")
    private String brand;

    @NotBlank
    @Size(max = 100)
    @Column(name = "name")
    private String name;

    @NotNull
    @Column(name = "year")
    private Long year;

    @NotNull
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "engine_code", nullable = false)
    private EngineEntity engine;
}

