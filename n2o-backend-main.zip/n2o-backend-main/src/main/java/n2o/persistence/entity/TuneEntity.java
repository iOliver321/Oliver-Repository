package n2o.persistence.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import org.springframework.boot.autoconfigure.flyway.FlywayDataSource;

@Entity
@Table(name = "tune")
@Data
@Builder
@AllArgsConstructor
public class TuneEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    Long Id;

    @NotNull
    @OneToOne
    @JoinColumn(name = "engine_code")
    EngineEntity engine;

    @Column(name = "stockHorsepower")
    Long stockHorsepower;

    @Column(name = "stockTorque")
    Long stockTorque;

    @Column(name = "tunedHorsepower")
    Long tunedHorsepower;

    @Column(name = "tunedTorque")
    Long tunedTorque;

    @Column(name = "price")
    Long price;


    public TuneEntity(){}
}
