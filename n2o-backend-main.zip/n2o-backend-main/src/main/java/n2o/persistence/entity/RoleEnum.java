package n2o.persistence.entity;

public enum RoleEnum {
    USER,
    ADMIN
}
