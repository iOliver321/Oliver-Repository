package n2o.persistence;

import n2o.persistence.entity.EngineEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface EngineRepository extends JpaRepository<EngineEntity, Long> {
    void deleteByCode(String code);
    EngineEntity findByCode(String code);

    @Query("SELECT COUNT(e) FROM EngineEntity e WHERE e.fuelType = 'Benzine'")
    Long countEnginesWithBenzine();

    @Query("SELECT COUNT(e) FROM EngineEntity e WHERE e.fuelType = 'Diesel'")
    Long countEnginesWithDiesel();


}
