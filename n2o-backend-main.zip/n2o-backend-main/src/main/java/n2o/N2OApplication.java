package n2o;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class N2OApplication {
    public static void main(String[] args) {
        SpringApplication.run(N2OApplication.class, args);
    }
}
