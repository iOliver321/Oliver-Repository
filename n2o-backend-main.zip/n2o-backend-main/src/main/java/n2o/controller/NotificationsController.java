package n2o.controller;

import lombok.AllArgsConstructor;
import n2o.controller.dto.NotificationMessage;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

@RestController
@AllArgsConstructor
@RequestMapping("notifications")
@CrossOrigin(origins = "*")
public class NotificationsController {
    private final SimpMessagingTemplate messagingTemplate;

    @PostMapping
    public ResponseEntity<Void> sendNotificationToUsers(@RequestBody NotificationMessage message) {
        messagingTemplate.convertAndSend("/update", message);
        return ResponseEntity.status(HttpStatus.CREATED).build();
    }//localhost
}
