package n2o.controller;

import jakarta.annotation.security.RolesAllowed;
import n2o.business.engine.*;
import n2o.controller.dto.EngineConverter;
import n2o.controller.dto.CreateEngineRequest;
import n2o.domain.Engine;
import n2o.controller.dto.GetAllEnginesResponse;
import n2o.controller.dto.UpdateEngineRequest;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/engine")
@CrossOrigin("*")
public class EngineController {
    private final CreateEngineUseCase createEngineUseCase;
    private final DeleteEngineUseCase deleteEngineUseCase;
    private final UpdateEngineUseCase updateEngineUseCase;
    private final GetEnginesUseCase getEnginesUseCase;
    private final GetEngineUseCase getEngineUseCase;
    private final CountDieselEngines countDieselEngines;
    private final CountBenzineEngines countBenzineEngines;

    @Autowired
    public EngineController(CreateEngineUseCase createEngineUseCase,
                            DeleteEngineUseCase deleteEngineUseCase,
                            UpdateEngineUseCase updateEngineUseCase,
                            GetEnginesUseCase getEnginesUseCase,
                            GetEngineUseCase getEngineUseCase,
                            CountBenzineEngines countBenzineEngines,
                            CountDieselEngines countDieselEngines){
        this.createEngineUseCase = createEngineUseCase;
        this.deleteEngineUseCase = deleteEngineUseCase;
        this.updateEngineUseCase = updateEngineUseCase;
        this.getEnginesUseCase = getEnginesUseCase;
        this.getEngineUseCase = getEngineUseCase;
        this.countBenzineEngines = countBenzineEngines;
        this.countDieselEngines = countDieselEngines;
    }

    @PostMapping
    public ResponseEntity<Engine> createEngine(@RequestBody CreateEngineRequest engineRequest) {
        // You should perform validation of streetRequest here before passing it to the use case.
        EngineEntity engineEntity = EngineConverter.convertEngineRequesttoEntity(engineRequest);
        createEngineUseCase.createEngine(engineEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body(EngineConverter.convertEngineEntitytoEngine(engineEntity));
    }

    @PutMapping
    @RolesAllowed({"ADMIN"})
    public ResponseEntity<Void> updateEngine(@RequestBody UpdateEngineRequest updateEngineRequest) {
        if (updateEngineRequest.getCode() == null) {
            return ResponseEntity.badRequest().build(); // Return a 400 Bad Request status
        }
        updateEngineUseCase.updateEngine(updateEngineRequest);

        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{code}")
    public ResponseEntity<Void> deleteEngine(@PathVariable("code") String code) {
        deleteEngineUseCase.deleteEngine(code);
        return ResponseEntity.noContent().build();
    }


    @GetMapping
    public ResponseEntity<GetAllEnginesResponse> getAllEngines(){
        List<Engine> engines = getEnginesUseCase.getEngines().getEngineList();
        return ResponseEntity.ok(new GetAllEnginesResponse(engines));
    }

    @GetMapping("/{code}")
    public ResponseEntity<Engine> getEngineByCode(@PathVariable("code") String code) {
        GetAllEnginesResponse response = getEngineUseCase.getOneEngine(code);
        List<Engine> engines = response.getEngineList(); // Assuming getEngineList() returns the list of engines

        if (engines.isEmpty()) {
            return ResponseEntity.notFound().build(); // Return 404 if no engine found
        }
        return ResponseEntity.ok(engines.get(0)); // Return 200 OK with the engine if found
    }

    @GetMapping("/Benzine")
    public ResponseEntity<Long> countBenzineEngines(){
        Long count = countBenzineEngines.countBenzineEngines();
        return ResponseEntity.ok(count);
    }

    @GetMapping("/Diesel")
    public ResponseEntity<Long> countDieselEngines(){
        Long count = countDieselEngines.countDieselEngines();
        return ResponseEntity.ok(count);
    }


}
