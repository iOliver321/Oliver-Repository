package n2o.controller;

import n2o.business.car.CreateCarUseCase;
import n2o.business.car.DeleteCarUseCase;
import n2o.business.car.GetCarsUseCase;
import n2o.business.car.UpdateCarUseCase;
import n2o.controller.dto.CarConverter;
import n2o.controller.dto.CreateCarRequest;
import n2o.controller.dto.UpdateCarRequest;
import n2o.domain.Car;
import n2o.persistence.entity.CarEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/car")
@CrossOrigin("*")
public class CarController {
    private final CreateCarUseCase createCarUseCase;
    private final DeleteCarUseCase deleteCarUseCase;
    private final GetCarsUseCase getCarsUseCase;
    private final UpdateCarUseCase updateCarUseCase;
    private final CarConverter carConverter;

    @Autowired
    public CarController(CreateCarUseCase createCarUseCase, DeleteCarUseCase deleteCarUseCase, GetCarsUseCase getCarsUseCase, UpdateCarUseCase updateCarUseCase, CarConverter carConverter) {
        this.createCarUseCase = createCarUseCase;
        this.deleteCarUseCase = deleteCarUseCase;
        this.getCarsUseCase = getCarsUseCase;
        this.updateCarUseCase = updateCarUseCase;
        this.carConverter = carConverter;
    }

    @PostMapping
    public ResponseEntity<Car> createCar(@RequestBody CreateCarRequest createCarRequest) {
        CarEntity carEntity = carConverter.toEntity(createCarRequest);
        createCarUseCase.createCar(carEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body(carConverter.toDomain(carEntity));
    }

    @PutMapping
    public ResponseEntity<Void> updateCar(@RequestBody UpdateCarRequest updateCarRequest) {
        if (updateCarRequest.getId() == null) {
            return ResponseEntity.badRequest().build(); // Return a 400 Bad Request status
        }
        updateCarUseCase.updateCar(updateCarRequest);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{code}")
    public ResponseEntity<Void> deleteCar(@PathVariable("id") Long id) {
        deleteCarUseCase.deleteCar(id);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<List<Car>> getAllCars() {
        List<Car> cars = getCarsUseCase.getCars().getCarList();
        return ResponseEntity.ok(cars);
    }
}
