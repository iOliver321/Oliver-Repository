package n2o.controller.dto;

import n2o.domain.Engine;
import n2o.persistence.entity.EngineEntity;
import org.springframework.stereotype.Component;

@Component

public class EngineConverter {
    private EngineConverter(){

    }

    public static Engine convertEngineEntitytoEngine(EngineEntity engineEntity)
    {
        return Engine.builder()
                .code(engineEntity.getCode())
                .capacity(engineEntity.getCapacity())
                .cylinders(engineEntity.getCylinders())
                .fuelType(engineEntity.getFuelType())
                .build();
    }

    public static EngineEntity convertEngineRequesttoEntity(CreateEngineRequest engine)
    {
        return EngineEntity.builder()
                .code(engine.getCode())
                .capacity(engine.getCapacity())
                .cylinders(engine.getCylinders())
                .fuelType(engine.getFuelType())
                .build();
    }
    public static EngineEntity convertEngineToEngineEntity(Engine engine) {
        return EngineEntity.builder()
                .code(engine.getCode())
                .capacity(engine.getCapacity())
                .cylinders(engine.getCylinders())
                .fuelType(engine.getFuelType())
                .build();
    }


}
