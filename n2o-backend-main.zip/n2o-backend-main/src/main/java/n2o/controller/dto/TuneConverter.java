package n2o.controller.dto;

import lombok.RequiredArgsConstructor;
import n2o.domain.Engine;
import n2o.domain.Tune;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import n2o.persistence.entity.TuneEntity;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class TuneConverter {

    private final EngineRepository engineRepository;
    private final EngineConverter engineConverter;

    public TuneEntity toEntity(Tune tune) {
        if (tune == null) {
            return null;
        }
        return TuneEntity.builder()
                .engine(engineConverter.convertEngineToEngineEntity(tune.getEngine()))
                .stockHorsepower(tune.getStockHorsepower())
                .stockTorque(tune.getStockTorque())
                .tunedHorsepower(tune.getTunedHorsepower())
                .tunedTorque(tune.getTunedTorque())
                .price(tune.getPrice())
                .build();
    }

    public Tune toDomain(TuneEntity tuneEntity) {
        if (tuneEntity == null) {
            return null;
        }

        // Assuming you are using RestTemplate to call the controller method
        EngineEntity engineEntity = tuneEntity.getEngine();
        Engine engineDomain = engineConverter.convertEngineEntitytoEngine(engineEntity);

        return Tune.builder()
                .engine(engineDomain) // Using the engine retrieved from the response
                .stockHorsepower(tuneEntity.getStockHorsepower())
                .stockTorque(tuneEntity.getStockTorque())
                .tunedHorsepower(tuneEntity.getTunedHorsepower())
                .tunedTorque(tuneEntity.getTunedTorque())
                .price(tuneEntity.getPrice())
                .build();
    }

    public TuneEntity toEntity(CreateTuneRequest createTuneRequest) {
        if (createTuneRequest == null) {
            return null;
        }
        EngineEntity engineEntity = engineRepository.findByCode(createTuneRequest.getEngineCode());
        return TuneEntity.builder()
                .engine(engineEntity)
                .stockHorsepower(createTuneRequest.getStockHorsepower())
                .stockTorque(createTuneRequest.getStockTorque())
                .tunedHorsepower(createTuneRequest.getTunedHorsepower())
                .tunedTorque(createTuneRequest.getTunedTorque())
                .price(createTuneRequest.getPrice())
                .build();
    }
}
