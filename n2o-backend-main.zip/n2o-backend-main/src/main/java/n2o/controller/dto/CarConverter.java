package n2o.controller.dto;

import lombok.RequiredArgsConstructor;
import n2o.domain.Car;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class CarConverter {

    private final EngineRepository engineRepository;
    private final EngineConverter engineConverter;

    public CarEntity toEntity(Car car) {
        if (car == null) {
            return null;
        }
        return CarEntity.builder()
                .id(car.getId())
                .brand(car.getBrand())
                .name(car.getName())
                .year(car.getYear())
                .engine(engineConverter.convertEngineToEngineEntity(car.getEngine()))
                .build();
    }

    public Car toDomain(CarEntity carEntity) {
        if (carEntity == null) {
            return null;
        }
        EngineEntity engineEntity = engineRepository.findByCode(carEntity.getEngine().getCode());
        return Car.builder()
                .id(carEntity.getId())
                .brand(carEntity.getBrand())
                .name(carEntity.getName())
                .year(carEntity.getYear())
                .engine(engineConverter.convertEngineEntitytoEngine(engineEntity)) // Proper instance usage
                .build();
    }

    public CarEntity toEntity(CreateCarRequest car) {
        if (car == null) {
            return null;
        }
        EngineEntity engineEntity = engineRepository.findByCode(car.getEngineCode());
        return CarEntity.builder()
                .brand(car.getBrand())
                .name(car.getName())
                .year(car.getYear())
                .engine(engineEntity)
                .build();
    }
}
