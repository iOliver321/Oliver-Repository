package n2o.controller.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateEngineResponse {
    private String code;
    private Long capacity;
    private Long cylinders;
    private String fuelType;
}
