package n2o.controller.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateTuneRequest {
    private String engineCode;
    private Long stockHorsepower;
    private Long stockTorque;
    private Long tunedHorsepower;
    private Long tunedTorque;
    private Long price;
}
