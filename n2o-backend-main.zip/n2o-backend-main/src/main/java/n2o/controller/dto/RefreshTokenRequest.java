package n2o.controller.dto;

import lombok.Data;

@Data
public class RefreshTokenRequest {
    // Removed refreshToken field
} 