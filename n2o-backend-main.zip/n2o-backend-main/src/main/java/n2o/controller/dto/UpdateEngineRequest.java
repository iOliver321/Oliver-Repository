package n2o.controller.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateEngineRequest {
    @NotNull
    private String code;

    private Long capacity;

    private Long cylinders;

    private String fuelType;
}
