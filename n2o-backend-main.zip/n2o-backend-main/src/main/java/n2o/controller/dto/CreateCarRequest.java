package n2o.controller.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CreateCarRequest {
    private String brand;
    private String name;
    private Long year;
    private String engineCode;
}
