package n2o.controller.dto;

import lombok.Data;

public class NotificationMessage {
    private String text;

    // Getters and Setters
    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
