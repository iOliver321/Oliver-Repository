package n2o.controller.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UpdateTuneRequest {
    @NotNull
    private String engineCode;

    private Long stockHorsepower;

    private Long stockTorque;

    private Long tunedHorsepower;

    private Long tunedTorque;

    private Long price;
}
