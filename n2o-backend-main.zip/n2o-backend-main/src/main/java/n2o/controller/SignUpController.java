package n2o.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import n2o.business.login.SignUpUseCase;
import n2o.controller.dto.LoginResponse;
import n2o.controller.dto.SignUpRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/signup")
@RequiredArgsConstructor
@CrossOrigin("http://localhost:5173/")
public class SignUpController {
    private final SignUpUseCase signUpUseCase;

    @PostMapping
    public ResponseEntity<LoginResponse> signup(@RequestBody @Valid SignUpRequest signUpRequest) {
        LoginResponse loginResponse = signUpUseCase.signup(signUpRequest);
        return ResponseEntity.status(HttpStatus.CREATED).body(loginResponse);
    }
}
