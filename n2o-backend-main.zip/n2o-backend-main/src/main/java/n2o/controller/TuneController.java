package n2o.controller;

import n2o.business.tune.CreateTuneUseCase;
import n2o.business.tune.DeleteTuneUseCase;
import n2o.business.tune.GetTunesUseCase;
import n2o.business.tune.UpdateTunesUseCase;
import n2o.controller.dto.*;
import n2o.domain.Tune;
import n2o.persistence.entity.TuneEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.simp.SimpMessagingTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/tune")
@CrossOrigin("*")
public class TuneController {
    private final CreateTuneUseCase createTuneUseCase;
    private final DeleteTuneUseCase deleteTuneUseCase;
    private final GetTunesUseCase getTunesUseCase;
    private final UpdateTunesUseCase updateTunesUseCase;
    private final TuneConverter tuneConverter;

    private final SimpMessagingTemplate messagingTemplate;

    @Autowired
    public TuneController(CreateTuneUseCase createTuneUseCase, DeleteTuneUseCase deleteTuneUseCase, GetTunesUseCase getTunesUseCase, UpdateTunesUseCase updateTunesUseCase, TuneConverter tuneConverter1, SimpMessagingTemplate simpMessagingTemplate)
    {
        this.createTuneUseCase = createTuneUseCase;
        this.deleteTuneUseCase = deleteTuneUseCase;
        this.getTunesUseCase = getTunesUseCase;
        this.updateTunesUseCase = updateTunesUseCase;
        this.tuneConverter = tuneConverter1;
        this.messagingTemplate = simpMessagingTemplate;
    }

    /*@PostMapping
    public ResponseEntity<Tune> createTune(@RequestBody CreateTuneRequest createTuneRequest){
        TuneEntity tuneEntity = tuneConverter.toEntity(createTuneRequest);
        createTuneUseCase.createTune(tuneEntity);
        return ResponseEntity.status(HttpStatus.CREATED).body(tuneConverter.toDomain(tuneEntity));
    }*/
    @PostMapping
    public ResponseEntity<Tune> createTune(@RequestBody CreateTuneRequest createTuneRequest) {
        TuneEntity tuneEntity = tuneConverter.toEntity(createTuneRequest);
        Tune createdTune = tuneConverter.toDomain(tuneEntity);

        // Create the tune
        createTuneUseCase.createTune(tuneEntity);

        // Send notification about the new tune
        NotificationMessage notificationMessage = new NotificationMessage();
        notificationMessage.setText("A new tune has been created: " + createdTune.getEngine());
        messagingTemplate.convertAndSend("/update", notificationMessage);

        return ResponseEntity.status(HttpStatus.CREATED).body(createdTune);
    }
    @PutMapping
    public ResponseEntity<Void> updateTune(@RequestBody UpdateTuneRequest updateTuneRequest){
        if(updateTuneRequest.getEngineCode() == null){
            return ResponseEntity.badRequest().build();
        }
        updateTunesUseCase.updateTune(updateTuneRequest);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping
    public ResponseEntity<Void> deleteTune (@PathVariable("code")String code){
        deleteTuneUseCase.deleteTune(code);
        return ResponseEntity.noContent().build();
    }

    @GetMapping
    public ResponseEntity<GetAllTunesResponse> getAllTunes(){
        List<Tune> tunes = getTunesUseCase.getTunes().getTuneList();
        return ResponseEntity.ok(new GetAllTunesResponse(tunes));
    }
}
