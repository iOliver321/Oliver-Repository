package n2o.business.login;


import n2o.controller.dto.LoginRequest;
import n2o.controller.dto.LoginResponse;

public interface LoginUseCase {
    LoginResponse login(LoginRequest loginRequest);
}
