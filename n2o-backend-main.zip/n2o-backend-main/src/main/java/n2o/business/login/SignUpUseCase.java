package n2o.business.login;


import n2o.controller.dto.LoginResponse;
import n2o.controller.dto.SignUpRequest;

public interface SignUpUseCase {
    LoginResponse signup(SignUpRequest signUpRequest);
}
