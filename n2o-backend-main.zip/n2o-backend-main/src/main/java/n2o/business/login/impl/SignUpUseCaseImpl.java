package n2o.business.login.impl;

import lombok.RequiredArgsConstructor;
/*import nl.fontys.individual.ecoroute.business.LoginUseCase;
import nl.fontys.individual.ecoroute.business.SignUpUseCase;
import nl.fontys.individual.ecoroute.business.exception.InvalidCredentialsException;
import nl.fontys.individual.ecoroute.domain.LoginRequest;
import nl.fontys.individual.ecoroute.domain.LoginResponse;
import nl.fontys.individual.ecoroute.domain.SignUpRequest;
import nl.fontys.individual.ecoroute.persistence.StreetRepository;
import nl.fontys.individual.ecoroute.persistence.UserRepository;
import nl.fontys.individual.ecoroute.persistence.entity.*;*/
import n2o.business.exception.InvalidCredentialsException;
import n2o.business.login.LoginUseCase;
import n2o.business.login.SignUpUseCase;
import n2o.controller.dto.LoginRequest;
import n2o.controller.dto.LoginResponse;
import n2o.controller.dto.SignUpRequest;
import n2o.persistence.EngineRepository;
import n2o.persistence.UserRepository;
import n2o.persistence.entity.RoleEnum;
import n2o.persistence.entity.UserEntity;
import n2o.persistence.entity.UserRoleEntity;
import org.springframework.stereotype.Service;

import java.util.HashSet;
import java.util.Set;

@Service
@RequiredArgsConstructor
public class SignUpUseCaseImpl implements SignUpUseCase {
    private final UserRepository userRepository;
    private final EngineRepository engineRepository;
    private final LoginUseCase loginUseCase;

    @Override
    public LoginResponse signup(SignUpRequest signUpRequest){
        //check if postal code exists
        boolean postalCodeExists = userRepository.existsByUsername(signUpRequest.getUsername());
        if(postalCodeExists){
            UserRoleEntity userRoleEntity = UserRoleEntity.builder()
                    .role(RoleEnum.USER)
                    .build();
            Set<UserRoleEntity> userRoles = new HashSet<>();
            userRoles.add(userRoleEntity);
            UserEntity userEntity = UserEntity.builder().username(signUpRequest.getUsername())
                    .password(signUpRequest.getPassword())
                    .userRoles(userRoles)
                    .build();

            userRepository.save(userEntity);

            LoginRequest loginRequest = LoginRequest.builder()
                    .username(signUpRequest.getUsername())
                    .password(signUpRequest.getPassword())
                    .build();
            return loginUseCase.login(loginRequest);
        }
        throw new InvalidCredentialsException();
    }
}
