package n2o.business.car.impl;
import n2o.business.car.CreateCarUseCase;
import n2o.controller.dto.CreateCarResponse;
import n2o.controller.dto.CreateEngineResponse;
import n2o.domain.Engine;
import n2o.persistence.CarRepository;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CreateCarUseCaseImpl implements CreateCarUseCase {

    @Autowired
    private CarRepository carRepository;


    @Override
    public CreateCarResponse createCar(CarEntity request)
    {

        CarEntity newCar = CarEntity.builder()
                .brand(request.getBrand())
                .name(request.getName())
                .engine(request.getEngine())
                .year(request.getYear())
                .build();
        CarEntity savedCar = carRepository.save(newCar);

        return CreateCarResponse.builder()
                .brand(savedCar.getBrand())
                .name(savedCar.getName())
                .engineCode(savedCar.getEngine().getCode())
                .year(savedCar.getYear())
                .build();
    }
}
