package n2o.business.car;

import n2o.controller.dto.CreateCarResponse;
import n2o.persistence.entity.CarEntity;

public interface CreateCarUseCase {
    public CreateCarResponse createCar(CarEntity request);
}
