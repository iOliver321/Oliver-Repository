package n2o.business.car;

import n2o.controller.dto.GetAllCarsResponse;

public interface GetCarsUseCase {
    public GetAllCarsResponse getCars();
}
