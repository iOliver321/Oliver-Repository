package n2o.business.car.impl;


import lombok.RequiredArgsConstructor;
import n2o.business.car.UpdateCarUseCase;
import n2o.controller.dto.UpdateCarRequest;
import n2o.controller.dto.UpdateEngineRequest;
import n2o.persistence.CarRepository;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UpdateCarUseCaseImpl implements UpdateCarUseCase {
    @Autowired
    private final CarRepository carRepository;

    @Autowired
    private final EngineRepository engineRepository;

    @Override
    public void updateCar(UpdateCarRequest request)
    {
        CarEntity carEntity = carRepository.findById(request.getId())
                .orElseThrow(() -> new RuntimeException("CarEntity not found with id: " + request.getId()));
        if(carEntity != null){
            EngineEntity engineEntity = engineRepository.findByCode(request.getEngineCode());
            carEntity.setEngine(engineEntity);
            carEntity.setYear(request.getYear());
            carEntity.setName(request.getName());
            carEntity.setBrand(request.getBrand());

            carRepository.save(carEntity);
        }
    }
}
