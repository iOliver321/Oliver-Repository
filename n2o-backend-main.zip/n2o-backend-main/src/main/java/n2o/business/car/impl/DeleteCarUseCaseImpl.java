package n2o.business.car.impl;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import n2o.business.car.DeleteCarUseCase;
import n2o.persistence.CarRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;


@Service
@AllArgsConstructor
@NoArgsConstructor
public class DeleteCarUseCaseImpl implements DeleteCarUseCase {
    @Autowired
    private CarRepository carRepository;


    public void deleteCar(Long id) {
        carRepository.deleteById(id);
    }
}
