package n2o.business.car.impl;

import lombok.RequiredArgsConstructor;
import n2o.business.car.GetCarsUseCase;
import n2o.controller.dto.CarConverter;
import n2o.controller.dto.EngineConverter;
import n2o.controller.dto.GetAllCarsResponse;
import n2o.controller.dto.GetAllEnginesResponse;
import n2o.domain.Car;
import n2o.domain.Engine;
import n2o.persistence.CarRepository;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class GetCarsUseCaseImpl implements GetCarsUseCase {
    @Autowired
    private final CarRepository carRepository;
    private final CarConverter carConverter;

    public GetAllCarsResponse getCars()
    {
        List<CarEntity> results;
        results =carRepository.findAll();
        final GetAllCarsResponse response =new GetAllCarsResponse();
        List<Car> cars = new ArrayList<Car>();
        for(CarEntity carEntity:results)
        {
            cars.add(carConverter.toDomain(carEntity));
        }
        response.setCarList(cars);
        return response;
    }
}
