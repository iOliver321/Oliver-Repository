package n2o.business.car;

import n2o.controller.dto.UpdateCarRequest;

public interface UpdateCarUseCase {
    public void updateCar(UpdateCarRequest request);
}
