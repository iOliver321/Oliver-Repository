package n2o.business.car;

public interface DeleteCarUseCase {
    public void deleteCar(Long id);
}
