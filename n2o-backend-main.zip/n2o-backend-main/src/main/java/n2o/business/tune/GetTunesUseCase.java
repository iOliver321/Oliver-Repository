package n2o.business.tune;

import n2o.controller.dto.GetAllTunesResponse;

public interface GetTunesUseCase {
    public GetAllTunesResponse getTunes();
}
