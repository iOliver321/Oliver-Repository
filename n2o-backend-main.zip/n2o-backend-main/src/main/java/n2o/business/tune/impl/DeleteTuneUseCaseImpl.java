package n2o.business.tune.impl;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import n2o.business.tune.DeleteTuneUseCase;
import n2o.persistence.EngineRepository;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
//@NoArgsConstructor
public class DeleteTuneUseCaseImpl implements DeleteTuneUseCase {
    @Autowired
    private TuneRepository tuneRepository;

    @Autowired
    private EngineRepository engineRepository;


    public void deleteTune(String code){
        EngineEntity engineEntity = engineRepository.findByCode(code);
        tuneRepository.deleteByEngine(engineEntity);
    }

    public void deleteTune(Long id){
        tuneRepository.deleteById(id);
    }
}
