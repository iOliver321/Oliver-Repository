package n2o.business.tune;

public interface DeleteTuneUseCase {
    public void deleteTune(String code);
}
