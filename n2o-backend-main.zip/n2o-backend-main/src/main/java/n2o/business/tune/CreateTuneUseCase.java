package n2o.business.tune;

import n2o.controller.dto.CreateTuneReponse;
import n2o.persistence.entity.TuneEntity;

public interface CreateTuneUseCase {
    public CreateTuneReponse createTune(TuneEntity request);
}
