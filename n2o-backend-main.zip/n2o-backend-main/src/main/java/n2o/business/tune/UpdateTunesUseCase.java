package n2o.business.tune;

import n2o.controller.dto.UpdateTuneRequest;

public interface UpdateTunesUseCase {
    public void updateTune(UpdateTuneRequest request);
}
