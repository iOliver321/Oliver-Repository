package n2o.business.tune.impl;

import lombok.RequiredArgsConstructor;
import n2o.business.tune.GetTunesUseCase;
import n2o.controller.EngineController;
import n2o.controller.dto.GetAllTunesResponse;
import n2o.controller.dto.TuneConverter;
import n2o.domain.Tune;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.TuneEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class GetTunesUseCaseImpl implements GetTunesUseCase {
    private final TuneRepository tuneRepository;
    private final TuneConverter tuneConverter;

    @Autowired
    public GetTunesUseCaseImpl(TuneRepository tuneRepository, TuneConverter tuneConverter) {
        this.tuneRepository = tuneRepository;
        this.tuneConverter = tuneConverter;
    }


    public GetAllTunesResponse getTunes() {
        List<TuneEntity> results = tuneRepository.findAll();  // Get the list of TuneEntities
        final GetAllTunesResponse response = new GetAllTunesResponse();
        List<Tune> tunes = new ArrayList<>();

        for (TuneEntity tuneEntity : results) {
            tunes.add(tuneConverter.toDomain(tuneEntity));  // Convert TuneEntity to Tune
        }

        response.setTuneList(tunes);  // Set the converted list in the response
        return response;
    }

}
