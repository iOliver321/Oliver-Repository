package n2o.business.tune.impl;

import n2o.business.tune.CreateTuneUseCase;
import n2o.controller.dto.CreateEngineResponse;
import n2o.controller.dto.CreateTuneReponse;
import n2o.persistence.EngineRepository;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.EngineEntity;
import n2o.persistence.entity.TuneEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CreateTuneUseCaseImpl implements CreateTuneUseCase {
    @Autowired
    private TuneRepository tuneRepository;

    @Override
    public CreateTuneReponse createTune(TuneEntity request)
    {
        TuneEntity newTune = TuneEntity.builder()
                .engine(request.getEngine())
                .tunedHorsepower(request.getTunedHorsepower())
                .stockHorsepower(request.getStockHorsepower())
                .tunedTorque(request.getTunedTorque())
                .stockTorque(request.getStockTorque())
                .price(request.getPrice())
                .build();
        TuneEntity savedTune = tuneRepository.save(newTune);

        return CreateTuneReponse.builder()
                .engineCode(savedTune.getEngine().getCode())
                .stockHorsepower(savedTune.getStockHorsepower())
                .stockTorque(savedTune.getStockTorque())
                .tunedHorsepower(savedTune.getTunedHorsepower())
                .tunedTorque(savedTune.getTunedTorque())
                .price(savedTune.getPrice())
                .build();
    }
}
