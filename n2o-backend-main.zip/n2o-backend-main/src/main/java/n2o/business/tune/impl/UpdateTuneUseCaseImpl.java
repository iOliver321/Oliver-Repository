package n2o.business.tune.impl;

import lombok.RequiredArgsConstructor;
import n2o.business.tune.UpdateTunesUseCase;
import n2o.controller.dto.UpdateEngineRequest;
import n2o.controller.dto.UpdateTuneRequest;
import n2o.persistence.EngineRepository;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.EngineEntity;
import n2o.persistence.entity.TuneEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UpdateTuneUseCaseImpl implements UpdateTunesUseCase {
    @Autowired
    private final TuneRepository tuneRepository;

    @Autowired
    private final EngineRepository engineRepository;

    @Override
    public void updateTune(UpdateTuneRequest request)
    {
        EngineEntity engineEntity = engineRepository.findByCode(request.getEngineCode());
        TuneEntity tuneEntity = tuneRepository.findByEngine(engineEntity);
        if(tuneEntity != null){
            tuneEntity.setStockHorsepower(request.getStockHorsepower());
            tuneEntity.setStockTorque(request.getStockTorque());
            tuneEntity.setTunedHorsepower(request.getTunedHorsepower());
            tuneEntity.setTunedTorque(request.getTunedTorque());
            tuneEntity.setPrice(request.getPrice());

            tuneRepository.save(tuneEntity);
        }
    }
}
