package n2o.business.engine;

public interface CountDieselEngines {
    Long countDieselEngines();
}
