package n2o.business.engine.impl;

import n2o.business.engine.CountDieselEngines;
import n2o.persistence.EngineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CountDieselEnginesImpl implements CountDieselEngines {
    @Autowired
    private EngineRepository engineRepository;

    public Long countDieselEngines(){
        return engineRepository.countEnginesWithDiesel();
    }
}
