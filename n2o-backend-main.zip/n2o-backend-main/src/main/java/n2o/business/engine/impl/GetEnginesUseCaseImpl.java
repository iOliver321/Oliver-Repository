package n2o.business.engine.impl;

import lombok.RequiredArgsConstructor;
import n2o.business.engine.GetEnginesUseCase;
import n2o.controller.dto.EngineConverter;
import n2o.domain.Engine;
import n2o.controller.dto.GetAllEnginesResponse;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
public class GetEnginesUseCaseImpl implements GetEnginesUseCase {
    @Autowired
    private final EngineRepository engineRepository;

    public GetAllEnginesResponse getEngines()
    {
        List<EngineEntity> results;
        results =(List<EngineEntity>)engineRepository.findAll();
        final GetAllEnginesResponse response =new GetAllEnginesResponse();
        List<Engine> engines = new ArrayList<Engine>();
        for(EngineEntity engineEntity:results)
        {
            engines.add(EngineConverter.convertEngineEntitytoEngine(engineEntity));
        }
        response.setEngineList(engines);
        return response;
    }


}
