package n2o.business.engine.impl;

import n2o.business.engine.CreateEngineUseCase;
import n2o.controller.dto.CreateEngineResponse;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CreateEngineUseCaseImpl implements CreateEngineUseCase
{
    @Autowired
    private EngineRepository engineRepository;

    @Override
    public CreateEngineResponse createEngine(EngineEntity request)
    {
        EngineEntity newEngine = EngineEntity.builder()
                .code(request.getCode())
                .cylinders(request.getCylinders())
                .capacity(request.getCapacity())
                .fuelType(request.getFuelType())
                .build();
        EngineEntity savedEngine = engineRepository.save(newEngine);

        return CreateEngineResponse.builder()
                .code(savedEngine.getCode())
                .capacity(savedEngine.getCapacity())
                .cylinders(savedEngine.getCylinders())
                .fuelType(savedEngine.getFuelType())
                .build();
    }
}
