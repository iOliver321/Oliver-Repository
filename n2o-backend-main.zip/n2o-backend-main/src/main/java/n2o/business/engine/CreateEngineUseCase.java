package n2o.business.engine;

import n2o.controller.dto.CreateEngineResponse;
import n2o.persistence.entity.EngineEntity;

public interface CreateEngineUseCase {
    public CreateEngineResponse createEngine(EngineEntity request);
}
