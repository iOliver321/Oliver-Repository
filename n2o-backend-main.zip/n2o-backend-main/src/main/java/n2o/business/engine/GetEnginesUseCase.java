package n2o.business.engine;

import n2o.controller.dto.GetAllEnginesResponse;

public interface GetEnginesUseCase {
    public GetAllEnginesResponse getEngines();
}
