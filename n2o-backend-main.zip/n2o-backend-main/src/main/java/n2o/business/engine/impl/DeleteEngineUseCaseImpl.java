package n2o.business.engine.impl;

import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import n2o.business.engine.DeleteEngineUseCase;
import n2o.persistence.EngineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@NoArgsConstructor
public class DeleteEngineUseCaseImpl implements DeleteEngineUseCase
{
    @Autowired
    private EngineRepository engineRepository;


    public void deleteEngine(String code){
        engineRepository.deleteByCode(code);
    }

}
