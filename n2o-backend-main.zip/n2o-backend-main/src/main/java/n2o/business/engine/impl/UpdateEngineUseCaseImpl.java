package n2o.business.engine.impl;

import lombok.RequiredArgsConstructor;
import n2o.business.engine.UpdateEngineUseCase;
import n2o.controller.dto.UpdateEngineRequest;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class UpdateEngineUseCaseImpl implements UpdateEngineUseCase
{
    @Autowired
    private final EngineRepository engineRepository;

    @Override
    public void updateEngine(UpdateEngineRequest request)
    {
        EngineEntity engineEntity = engineRepository.findByCode(request.getCode());
        if(engineEntity != null){
            engineEntity.setCapacity(request.getCapacity());
            engineEntity.setCylinders(request.getCylinders());
            engineEntity.setFuelType(request.getFuelType());

            engineRepository.save(engineEntity);
        }
    }
}
