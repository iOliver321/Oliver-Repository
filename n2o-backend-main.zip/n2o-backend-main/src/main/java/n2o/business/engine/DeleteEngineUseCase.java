package n2o.business.engine;

public interface DeleteEngineUseCase {
    public void deleteEngine(String code);
}
