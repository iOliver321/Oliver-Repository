package n2o.business.engine.impl;

import n2o.business.engine.CountBenzineEngines;
import n2o.persistence.EngineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CountBenzineEnginesImpl implements CountBenzineEngines {
    @Autowired
    private EngineRepository engineRepository;

    public Long countBenzineEngines(){
        return engineRepository.countEnginesWithBenzine();
    }
}
