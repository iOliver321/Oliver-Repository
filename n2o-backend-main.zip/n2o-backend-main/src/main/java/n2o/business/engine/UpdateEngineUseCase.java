package n2o.business.engine;

import n2o.controller.dto.UpdateEngineRequest;

public interface UpdateEngineUseCase{
    public void updateEngine(UpdateEngineRequest request);
}
