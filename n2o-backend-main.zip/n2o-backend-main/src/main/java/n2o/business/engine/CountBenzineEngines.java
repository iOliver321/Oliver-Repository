package n2o.business.engine;

public interface CountBenzineEngines {
    Long countBenzineEngines();
}
