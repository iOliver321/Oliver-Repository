package n2o.business.impl;

import n2o.business.engine.impl.UpdateEngineUseCaseImpl;
import n2o.controller.dto.UpdateEngineRequest;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class UpdateEngineUseCaseImplTest {
    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    private UpdateEngineUseCaseImpl updateEngineUseCase;

    @Test
    void testUpdateEngine(){
        UpdateEngineRequest updateEngineRequest = new UpdateEngineRequest();
        updateEngineRequest.setCode("S63Test");
        updateEngineRequest.setCapacity(3999L);
        updateEngineRequest.setCylinders(7L);
        updateEngineRequest.setFuelType("Diesel");

        EngineEntity existingEngineEntity = EngineEntity.builder()
                .code(updateEngineRequest.getCode())
                .capacity(updateEngineRequest.getCapacity())
                .cylinders(updateEngineRequest.getCylinders())
                .fuelType(updateEngineRequest.getFuelType())
                .build();
        when(engineRepository.findByCode(updateEngineRequest.getCode())).thenReturn(existingEngineEntity);

        //Act
        updateEngineUseCase.updateEngine(updateEngineRequest);

        // Assert
        // Verify that the save method of engineRepository is called with the updated EngineEntity
        Mockito.verify(engineRepository).save(existingEngineEntity);

        // Additional assertions based on the expected behavior
        assertEquals("S63Test", existingEngineEntity.getCode());
    }
}
