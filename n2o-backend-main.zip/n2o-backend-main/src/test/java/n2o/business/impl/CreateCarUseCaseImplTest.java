package n2o.business.impl;

import n2o.business.car.impl.CreateCarUseCaseImpl;
import n2o.controller.dto.CreateCarResponse;
import n2o.persistence.CarRepository;
import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class CreateCarUseCaseImplTest {
    @Mock
    private CarRepository carRepository;

    @InjectMocks
    private CreateCarUseCaseImpl createCarUseCase;

    @Test
    void testCreateCar_Success() {
        // Arrange Engines
        EngineEntity engine = EngineEntity.builder()
                .cylinders(6L)
                .capacity(2999L)
                .fuelType("Benzine")
                .code("S58")
                .build();

        // Arrange
        CarEntity request = CarEntity.builder()
                .brand("BMW")
                .name("M4")
                .engine(engine)
                .year(2023L)
                .build();
        CarEntity savedCar = CarEntity.builder()
                .brand("BMW")
                .name("M4")
                .engine(engine)
                .year(2023L)
                .build();
        when(carRepository.save(Mockito.any(CarEntity.class))).thenReturn(savedCar);

        // Act
        CreateCarResponse response = createCarUseCase.createCar(request);

        // Assert
        Mockito.verify(carRepository).save(Mockito.any(CarEntity.class));

        assertEquals(request.getBrand(), response.getBrand());
        assertEquals(request.getName(), response.getName());
        assertEquals(request.getEngine().getCode(), response.getEngineCode());
        assertEquals(request.getYear(), response.getYear());
    }

    @Test
    void testCreateCar_InvalidData() {
        // Arrange: Missing required fields (e.g., brand and name)
        CarEntity invalidRequest = CarEntity.builder()
                .brand(null)
                .name("")
                .engine(null)
                .year(-1L)
                .build();

        // Act & Assert: Expect an exception or error
        Exception exception = null;
        try {
            createCarUseCase.createCar(invalidRequest);
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Cannot invoke \"n2o.persistence.entity.CarEntity.getBrand()\" because \"savedCar\" is null", exception.getMessage());
    }

    @Test
    void testCreateCar_NullRequest() {
        // Act & Assert: Expect an exception when input is null
        Exception exception = null;
        try {
            createCarUseCase.createCar(null);
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Cannot invoke \"n2o.persistence.entity.CarEntity.getBrand()\" because \"request\" is null", exception.getMessage());
    }
}

