package n2o.business.impl;

import n2o.business.car.impl.GetCarsUseCaseImpl;
import n2o.controller.dto.GetAllCarsResponse;
import n2o.domain.Car;
import n2o.persistence.CarRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;

@SpringBootTest
public class GetCarsUseCaseImpIT {
    @Autowired
    private GetCarsUseCaseImpl getCarsUseCase;

    @Autowired
    private CarRepository carRepository;

    @Test
    void getCars_shouldReturnAllCarsFromDatabase() {
        // Act
        GetAllCarsResponse response = getCarsUseCase.getCars();

        // Assert
        List<Car> carList = response.getCarList();
        assertThat(carList).hasSize(5);

        Car car1 = carList.get(0);
        assertThat(car1.getName()).isEqualTo("M340i");


        Car car2 = carList.get(1);
        assertThat(car2.getName()).isEqualTo("330i");
    }
}
