package n2o.business.impl;

import n2o.business.engine.impl.CreateEngineUseCaseImpl;
import n2o.controller.dto.CreateEngineResponse;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class CreateEngineUseCaseImplTest {

    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    CreateEngineUseCaseImpl createEngineUseCase;

    @Test
    void testCreateEngine_Success() {
        EngineEntity request = EngineEntity.builder()
                .code("S63Test")
                .cylinders(8L)
                .capacity(4000L)
                .fuelType("Benzine")
                .build();
        EngineEntity savedEngine = EngineEntity.builder()
                .code("S63Test")
                .cylinders(8L)
                .capacity(4000L)
                .fuelType("Benzine")
                .build();
        when(engineRepository.save(Mockito.any(EngineEntity.class))).thenReturn(savedEngine);

        // Act
        CreateEngineResponse response = createEngineUseCase.createEngine(request);

        // Assert
        Mockito.verify(engineRepository).save(Mockito.any(EngineEntity.class));

        assertEquals(request.getCode(), response.getCode());
        assertEquals(request.getCapacity(), response.getCapacity());
        assertEquals(request.getCylinders(), response.getCylinders());
        assertEquals(request.getFuelType(), response.getFuelType());
    }


    @Test
    void testCreateEngine_InvalidData() {
        // Arrange: Missing required fields (e.g., code and fuelType is null)
        EngineEntity invalidRequest = EngineEntity.builder()
                .code(null)
                .cylinders(0L)
                .capacity(-1L)
                .fuelType(null)
                .build();

        // Act & Assert: Expect an exception or error due to invalid data
        Exception exception = null;
        try {
            createEngineUseCase.createEngine(invalidRequest);
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Cannot invoke \"n2o.persistence.entity.EngineEntity.getCode()\" because \"savedEngine\" is null", exception.getMessage());
    }

    @Test
    void testCreateEngine_NullRequest() {
        // Act & Assert: Expect an exception when the input is null
        Exception exception = null;
        try {
            createEngineUseCase.createEngine(null);
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Cannot invoke \"n2o.persistence.entity.EngineEntity.getCode()\" because \"request\" is null", exception.getMessage());
    }
}

