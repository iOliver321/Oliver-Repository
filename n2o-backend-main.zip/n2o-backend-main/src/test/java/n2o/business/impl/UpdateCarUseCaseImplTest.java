package n2o.business.impl;

import n2o.business.car.impl.UpdateCarUseCaseImpl;
import n2o.controller.dto.UpdateCarRequest;
import n2o.persistence.CarRepository;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.CarEntity;
import n2o.persistence.entity.EngineEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class UpdateCarUseCaseImplTest {

    @Mock
    private CarRepository carRepository;

    @Mock
    private EngineRepository engineRepository;
    @InjectMocks
    private UpdateCarUseCaseImpl updateCarUseCase;

    @Test
    void testUpdateCar() {
        // Arrange Engines
        // Arrange
        UpdateCarRequest updateCarRequest = new UpdateCarRequest();
        updateCarRequest.setId(1L);
        updateCarRequest.setYear(2024L);
        updateCarRequest.setName("UpdatedCarName");
        updateCarRequest.setBrand("UpdatedBrand");

        EngineEntity engineEntity = engineRepository.findByCode(updateCarRequest.getEngineCode());
        CarEntity existingCarEntity = CarEntity.builder()
                .id(1L)
                .engine(engineEntity)
                .year(2023L)
                .name("OldCarName")
                .brand("OldBrand")
                .build();

        when(carRepository.findById(updateCarRequest.getId())).thenReturn(Optional.of(existingCarEntity));

        // Act
        updateCarUseCase.updateCar(updateCarRequest);

        // Assert
        // Verify that the save method of carRepository is called with the updated CarEntity
        Mockito.verify(carRepository).save(existingCarEntity);

        // Additional assertions based on the expected updates
        assertEquals(engineEntity, existingCarEntity.getEngine());
        assertEquals(2024, existingCarEntity.getYear());
        assertEquals("UpdatedCarName", existingCarEntity.getName());
        assertEquals("UpdatedBrand", existingCarEntity.getBrand());
    }
}
