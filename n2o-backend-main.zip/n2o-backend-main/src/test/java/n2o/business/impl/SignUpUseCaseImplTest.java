package n2o.business.impl;

import n2o.business.exception.InvalidCredentialsException;
import n2o.business.login.LoginUseCase;
import n2o.business.login.impl.SignUpUseCaseImpl;
import n2o.controller.dto.LoginRequest;
import n2o.controller.dto.LoginResponse;
import n2o.controller.dto.SignUpRequest;
import n2o.persistence.UserRepository;
import n2o.persistence.entity.RoleEnum;
import n2o.persistence.entity.UserEntity;
import n2o.persistence.entity.UserRoleEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashSet;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
class SignUpUseCaseImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private LoginUseCase loginUseCase;

    @InjectMocks
    private SignUpUseCaseImpl signUpUseCase;

    @Test
    void testSignup_Success() {
        // Arrange
        String username = "oliver_test";
        String password = "testPassword";

        SignUpRequest signUpRequest = SignUpRequest.builder()
                .username(username)
                .password(password)
                .build();

        LoginRequest loginRequest = LoginRequest.builder()
                .username(username)
                .password(password)
                .build();

        LoginResponse loginResponse = LoginResponse.builder()
                .accessToken("mockAccessToken")
                .build();

        when(userRepository.existsByUsername(username)).thenReturn(true); // Simulate username exists
        when(loginUseCase.login(loginRequest)).thenReturn(loginResponse);

        // Act
        LoginResponse response = signUpUseCase.signup(signUpRequest);

        // Assert
        verify(userRepository).existsByUsername(username);
        verify(userRepository).save(Mockito.any(UserEntity.class));
        verify(loginUseCase).login(loginRequest);

        assertEquals("mockAccessToken", response.getAccessToken());
    }


    @Test
    void testSignup_InvalidCredentials() {
        // Arrange
        String username = "testUser";
        String password = "testPassword";

        SignUpRequest signUpRequest = SignUpRequest.builder()
                .username(username)
                .password(password)
                .build();

        when(userRepository.existsByUsername(username)).thenReturn(false); // Simulate username doesn't exist

        // Act & Assert
        assertThrows(InvalidCredentialsException.class, () -> signUpUseCase.signup(signUpRequest));

        verify(userRepository).existsByUsername(username);
        verify(userRepository, never()).save(Mockito.any(UserEntity.class));
        verify(loginUseCase, never()).login(Mockito.any(LoginRequest.class));
    }
}

