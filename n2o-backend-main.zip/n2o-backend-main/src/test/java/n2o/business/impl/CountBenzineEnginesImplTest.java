package n2o.business.impl;

import n2o.business.engine.CountBenzineEngines;
import n2o.business.engine.impl.CountBenzineEnginesImpl;
import n2o.persistence.EngineRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class CountBenzineEnginesImplTest {

    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    private CountBenzineEnginesImpl countBenzineEngines;

    @Test
    public void testCountBenzineEngines() {
        // Arrange: Define the behavior of the mock
        when(engineRepository.countEnginesWithBenzine()).thenReturn(7L);

        // Act: Call the method under test (you need to implement this in the service)
        Long result = countBenzineEngines.countBenzineEngines();

        // Assert: Verify the result
        assertEquals(7L, result, "The benzine engine count should be 7");
    }
}
