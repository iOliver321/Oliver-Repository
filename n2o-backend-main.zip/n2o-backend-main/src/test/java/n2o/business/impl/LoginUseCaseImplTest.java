package n2o.business.login.impl;

import n2o.business.exception.InvalidCredentialsException;
import n2o.configuration.security.token.AccessTokenEncoder;
import n2o.configuration.security.token.impl.AccessTokenImpl;
import n2o.controller.dto.LoginRequest;
import n2o.controller.dto.LoginResponse;
import n2o.persistence.UserRepository;
import n2o.persistence.entity.RoleEnum;
import n2o.persistence.entity.UserEntity;
import n2o.persistence.entity.UserRoleEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@SpringBootTest
class LoginUseCaseImplTest {

    @Mock
    private UserRepository userRepository;

    @Mock
    private AccessTokenEncoder accessTokenEncoder;

    @InjectMocks
    private LoginUseCaseImpl loginUseCase;

    @Test
    void testLogin_Success() {
        // Arrange
        String username = "testUser";
        String password = "testPassword";
        String encodedPassword = "testPassword"; // Simulate stored password
        String mockAccessToken = "mockAccessToken";

        Set<UserRoleEntity> roles = new HashSet<>();
        roles.add(UserRoleEntity.builder().role(RoleEnum.USER).build());

        UserEntity userEntity = UserEntity.builder()
                .id(1L)
                .username(username)
                .password(encodedPassword)
                .userRoles(roles)
                .build();

        LoginRequest loginRequest = LoginRequest.builder()
                .username(username)
                .password(password)
                .build();

        when(userRepository.findByUsername(username)).thenReturn(userEntity);
        when(accessTokenEncoder.encode(Mockito.any(AccessTokenImpl.class))).thenReturn(mockAccessToken);

        // Act
        LoginResponse response = loginUseCase.login(loginRequest);

        // Assert
        verify(userRepository).findByUsername(username);
        verify(accessTokenEncoder).encode(Mockito.any(AccessTokenImpl.class));

        assertEquals(mockAccessToken, response.getAccessToken());
    }

    @Test
    void testLogin_UserNotFound() {
        // Arrange
        String username = "testUser";
        String password = "testPassword";

        LoginRequest loginRequest = LoginRequest.builder()
                .username(username)
                .password(password)
                .build();

        when(userRepository.findByUsername(username)).thenReturn(null); // Simulate user not found

        // Act & Assert
        assertThrows(InvalidCredentialsException.class, () -> loginUseCase.login(loginRequest));

        verify(userRepository).findByUsername(username);
        verifyNoInteractions(accessTokenEncoder);
    }

    @Test
    void testLogin_InvalidPassword() {
        // Arrange
        String username = "testUser";
        String password = "wrongPassword";
        String encodedPassword = "correctPassword";

        Set<UserRoleEntity> roles = new HashSet<>();
        roles.add(UserRoleEntity.builder().role(RoleEnum.USER).build());

        UserEntity userEntity = UserEntity.builder()
                .id(1L)
                .username(username)
                .password(encodedPassword)
                .userRoles(roles)
                .build();

        LoginRequest loginRequest = LoginRequest.builder()
                .username(username)
                .password(password)
                .build();

        when(userRepository.findByUsername(username)).thenReturn(userEntity);

        // Act & Assert
        assertThrows(InvalidCredentialsException.class, () -> loginUseCase.login(loginRequest));

        verify(userRepository).findByUsername(username);
        verifyNoInteractions(accessTokenEncoder);
    }
}
