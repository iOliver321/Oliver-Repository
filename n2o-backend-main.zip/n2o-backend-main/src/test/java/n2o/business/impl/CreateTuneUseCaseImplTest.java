package n2o.business.impl;

import n2o.business.tune.impl.CreateTuneUseCaseImpl;
import n2o.controller.dto.CreateTuneReponse;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.EngineEntity;
import n2o.persistence.entity.TuneEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class CreateTuneUseCaseImplTest {

    @Mock
    private TuneRepository tuneRepository;

    @InjectMocks
    private CreateTuneUseCaseImpl createTuneUseCase;

    @Test
    void testCreateTune_Success() {
        // Arrange Engines
        EngineEntity engine = EngineEntity.builder()
                .cylinders(6L)
                .capacity(2999L)
                .fuelType("Benzine")
                .code("S58")
                .build();

        // Arrange Tune request
        TuneEntity request = TuneEntity.builder()
                .engine(engine)
                .tunedHorsepower(500L)
                .stockHorsepower(400L)
                .tunedTorque(600L)
                .stockTorque(500L)
                .price(1500L)
                .build();

        TuneEntity savedTune = TuneEntity.builder()
                .engine(engine)
                .tunedHorsepower(500L)
                .stockHorsepower(400L)
                .tunedTorque(600L)
                .stockTorque(500L)
                .price(1500L)
                .build();

        when(tuneRepository.save(Mockito.any(TuneEntity.class))).thenReturn(savedTune);

        // Act
        CreateTuneReponse response = createTuneUseCase.createTune(request);

        // Assert
        Mockito.verify(tuneRepository).save(Mockito.any(TuneEntity.class));

        // Additional assertions based on the expected behavior
        assertEquals(request.getEngine().getCode(), response.getEngineCode());
        assertEquals(request.getStockHorsepower(), response.getStockHorsepower());
        assertEquals(request.getStockTorque(), response.getStockTorque());
        assertEquals(request.getTunedHorsepower(), response.getTunedHorsepower());
        assertEquals(request.getTunedTorque(), response.getTunedTorque());
        assertEquals(request.getPrice(), response.getPrice());
    }

    @Test
    void testCreateTune_InvalidData() {
        // Arrange: Invalid data such as negative values or null fields
        EngineEntity engine = EngineEntity.builder()
                .cylinders(6L)
                .capacity(2999L)
                .fuelType("Benzine")
                .code("S58")
                .build();

        // Invalid request with negative horsepower and torque values
        TuneEntity invalidRequest = TuneEntity.builder()
                .engine(engine)
                .tunedHorsepower(-500L)
                .stockHorsepower(400L)
                .tunedTorque(600L)
                .stockTorque(-500L)
                .price(-1500L)
                .build();

        // Act & Assert: Expect an exception or error due to invalid data
        Exception exception = null;
        try {
            createTuneUseCase.createTune(invalidRequest);
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Cannot invoke \"n2o.persistence.entity.TuneEntity.getEngine()\" because \"savedTune\" is null", exception.getMessage());
    }

    @Test
    void testCreateTune_NullRequest() {
        // Act & Assert: Expect an exception when the input is null
        Exception exception = null;
        try {
            createTuneUseCase.createTune(null);
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Cannot invoke \"n2o.persistence.entity.TuneEntity.getEngine()\" because \"request\" is null", exception.getMessage());
    }
}

