package n2o.business.impl;

import n2o.business.engine.impl.DeleteEngineUseCaseImpl;
import n2o.persistence.EngineRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.Mockito.verify;

@SpringBootTest
class DeleteEngineUseCaseImplTest {

    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    private DeleteEngineUseCaseImpl deleteEngineUseCase;

    @Test
    void deleteTest(){
        //Arrange
        String code = "S63Test";

        //Act
        deleteEngineUseCase.deleteEngine(code);

        //Assert
        verify(engineRepository).deleteByCode(code);
    }
}
