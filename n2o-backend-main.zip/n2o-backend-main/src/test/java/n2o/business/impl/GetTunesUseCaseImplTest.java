package n2o.business.impl;

import n2o.business.tune.impl.GetTunesUseCaseImpl;
import n2o.controller.dto.GetAllTunesResponse;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.TuneEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class GetTunesUseCaseImplTest {

    @Mock
    private TuneRepository tuneRepository;

    @InjectMocks
    private GetTunesUseCaseImpl getTunesUseCase;

    @Test
    void testGetTunes() {
        // Arrange
        List<TuneEntity> tuneEntities = new ArrayList<>();
        when(tuneRepository.findAll()).thenReturn(tuneEntities);

        // Act
        GetAllTunesResponse response = getTunesUseCase.getTunes();

        // Assert
        // Verify that the findAll method of tuneRepository is called
        Mockito.verify(tuneRepository).findAll();
        // Check the response size matches the mocked size
        assertEquals(tuneEntities.size(), response.getTuneList().size());
    }

    @Test
    void testGetTunes_NoTunesFound() {
        // Arrange: Set up an empty list to simulate no tunes in the database
        List<TuneEntity> tuneEntities = new ArrayList<>();
        when(tuneRepository.findAll()).thenReturn(tuneEntities);

        // Act: Call the method
        GetAllTunesResponse response = getTunesUseCase.getTunes();

        // Assert: Verify the findAll method was called and the response has no tunes
        Mockito.verify(tuneRepository).findAll();
        assertEquals(0, response.getTuneList().size());
    }

    @Test
    void testGetTunes_ExceptionHandling() {
        // Arrange: Simulate an exception thrown by the repository (e.g., database failure)
        when(tuneRepository.findAll()).thenThrow(new RuntimeException("Database error"));

        // Act & Assert: Expect an exception to be thrown when calling the method
        Exception exception = null;
        try {
            getTunesUseCase.getTunes();
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Database error", exception.getMessage());
    }
}
