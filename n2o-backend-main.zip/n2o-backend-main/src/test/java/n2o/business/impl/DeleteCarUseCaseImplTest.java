package n2o.business.impl;

import n2o.business.car.impl.DeleteCarUseCaseImpl;
import n2o.persistence.CarRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.verify;

@SpringBootTest
class DeleteCarUseCaseImplTest {

    @Mock
    private CarRepository carRepository;

    @InjectMocks
    private DeleteCarUseCaseImpl deleteCarUseCase;

    @Test
    void deleteCar_Success() {
        // Arrange
        Long carId = 1L;

        // Act
        deleteCarUseCase.deleteCar(carId);

        // Assert: Verify that the deleteById method is called with the correct carId
        verify(carRepository).deleteById(carId);
    }
}


