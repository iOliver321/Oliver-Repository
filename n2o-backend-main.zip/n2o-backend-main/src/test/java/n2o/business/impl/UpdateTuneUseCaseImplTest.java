package n2o.business.impl;

import n2o.business.tune.impl.UpdateTuneUseCaseImpl;
import n2o.controller.dto.UpdateTuneRequest;
import n2o.persistence.EngineRepository;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.EngineEntity;
import n2o.persistence.entity.TuneEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.Mockito.when;

@SpringBootTest
class UpdateTuneUseCaseImplTest {

    @Mock
    private EngineRepository engineRepository;

    @Mock
    private TuneRepository tuneRepository;

    @InjectMocks
    private UpdateTuneUseCaseImpl updateTuneUseCase;

    @Test
    void testUpdateTune() {
        // Arrange
        UpdateTuneRequest request = new UpdateTuneRequest();
        request.setStockHorsepower(450L);
        request.setStockTorque(500L);
        request.setTunedHorsepower(550L);
        request.setTunedTorque(600L);
        request.setPrice(2000L);

        TuneEntity existingTuneEntity = TuneEntity.builder()
                .stockHorsepower(request.getStockHorsepower())
                .stockTorque(request.getStockTorque())
                .tunedHorsepower(request.getTunedHorsepower())
                .tunedTorque(request.getTunedTorque())
                .price(request.getPrice())
                .build();
        EngineEntity engineEntity = engineRepository.findByCode(request.getEngineCode());

        when(tuneRepository.findByEngine(engineEntity)).thenReturn(existingTuneEntity);

        // Act
        updateTuneUseCase.updateTune(request);

        // Assert
        // Verify that the save method was called on the mock repository
        Mockito.verify(tuneRepository).save(existingTuneEntity);

    }
}
