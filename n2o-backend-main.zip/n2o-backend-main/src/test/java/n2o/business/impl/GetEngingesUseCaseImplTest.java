package n2o.business.impl;

import n2o.business.engine.impl.GetEnginesUseCaseImpl;
import n2o.controller.dto.GetAllEnginesResponse;
import n2o.persistence.EngineRepository;
import n2o.persistence.entity.EngineEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest

class GetEngingesUseCaseImplTest {
    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    private GetEnginesUseCaseImpl getEnginesUseCase;

    @Test
    void testGetEngines(){
        //Arrange
        List<EngineEntity> engineEntities = new ArrayList<>();

        when(engineRepository.findAll()).thenReturn(engineEntities);

        //Act
        GetAllEnginesResponse response = getEnginesUseCase.getEngines();

        // Assert
        // Verify that the findAll method is called
        Mockito.verify(engineRepository).findAll();
        assertEquals(engineEntities.size(), response.getEngineList().size());
    }
    @Test
    void testGetEngines_NoEnginesFound() {
        // Arrange: Set up an empty list to simulate no engines in the database
        List<EngineEntity> engineEntities = new ArrayList<>();
        when(engineRepository.findAll()).thenReturn(engineEntities);

        // Act: Call the method
        GetAllEnginesResponse response = getEnginesUseCase.getEngines();

        // Assert: Verify the findAll method was called and the response has no engines
        Mockito.verify(engineRepository).findAll();
        assertEquals(0, response.getEngineList().size());
    }

    @Test
    void testGetEngines_ExceptionHandling() {
        // Arrange: Simulate an exception thrown by the repository (e.g., database failure)
        when(engineRepository.findAll()).thenThrow(new RuntimeException("Database error"));

        // Act & Assert: Expect an exception to be thrown when calling the method
        Exception exception = null;
        try {
            getEnginesUseCase.getEngines();
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Database error", exception.getMessage());
    }
}
