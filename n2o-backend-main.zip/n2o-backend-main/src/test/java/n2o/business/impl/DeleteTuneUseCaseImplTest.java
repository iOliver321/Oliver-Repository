package n2o.business.impl;

import n2o.business.tune.impl.DeleteTuneUseCaseImpl;
import n2o.persistence.EngineRepository;
import n2o.persistence.TuneRepository;
import n2o.persistence.entity.EngineEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@SpringBootTest
class DeleteTuneUseCaseImplTest {

    @Mock
    private TuneRepository tuneRepository;

    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    private DeleteTuneUseCaseImpl deleteTuneUseCase;

    @Test
    void testDeleteTune_ById() {
        // Arrange
        Long tuneID = 1L;

        // Act
        deleteTuneUseCase.deleteTune(tuneID);

        // Assert
        // Verify that the deleteById method of tuneRepository is called with the correct ID
        verify(tuneRepository).deleteById(tuneID);
    }

    @Test
    void testDeleteTune_ByCode() {
        // Arrange
        String code = "S63B44T4";
        EngineEntity mockEngine = EngineEntity.builder()
                .code(code)
                .build();

        when(engineRepository.findByCode(code)).thenReturn(mockEngine);

        // Act
        deleteTuneUseCase.deleteTune(code);

        // Assert
        // Verify that findByCode is called with the correct code
        verify(engineRepository).findByCode(code);

        // Verify that the deleteByEngine method of tuneRepository is called with the correct engine
        verify(tuneRepository).deleteByEngine(mockEngine);
    }
}
