package n2o.business.impl;

import n2o.business.engine.impl.CountDieselEnginesImpl;
import n2o.persistence.EngineRepository;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
public class CountDieselEnginesImplTest {

    @Mock
    private EngineRepository engineRepository;

    @InjectMocks
    private CountDieselEnginesImpl countDieselEnginesImpl;

    @Test
    public void testCountDieselEngines() {
        // Arrange: Define the behavior of the mock
        when(engineRepository.countEnginesWithDiesel()).thenReturn(0L);

        // Act: Call the method under test
        Long result = countDieselEnginesImpl.countDieselEngines();

        // Assert: Verify the result
        assertEquals(0L, result, "The diesel engine count should be 0");
    }
}

