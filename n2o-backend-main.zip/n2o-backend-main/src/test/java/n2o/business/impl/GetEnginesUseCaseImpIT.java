package n2o.business.impl;

import n2o.business.engine.impl.GetEnginesUseCaseImpl;
import n2o.controller.dto.GetAllEnginesResponse;
import n2o.domain.Engine;
import n2o.persistence.EngineRepository;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;

import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;


@SpringBootTest
public class GetEnginesUseCaseImpIT {
    @Autowired
    private GetEnginesUseCaseImpl getEnginesUseCase;

    @Autowired
    private EngineRepository engineRepository;

    @Test
    void getEngines_shouldReturnAllEnginesFromDatabase() {
        // Act
        GetAllEnginesResponse response = getEnginesUseCase.getEngines();

        // Assert
        List<Engine> engineList = response.getEngineList();
        assertThat(engineList).hasSize(7);

        Engine engine1 = engineList.get(0);
        assertThat(engine1.getCode()).isEqualTo("177980");

        Engine engine2 = engineList.get(1);
        assertThat(engine2.getCode()).isEqualTo("B48");
    }
}
