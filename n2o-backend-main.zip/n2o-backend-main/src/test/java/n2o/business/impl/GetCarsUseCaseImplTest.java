package n2o.business.impl;

import n2o.business.car.impl.GetCarsUseCaseImpl;
import n2o.controller.dto.GetAllCarsResponse;
import n2o.persistence.CarRepository;
import n2o.persistence.entity.CarEntity;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@SpringBootTest
class GetCarsUseCaseImplTest {

    @Mock
    private CarRepository carRepository;

    @InjectMocks
    private GetCarsUseCaseImpl getCarsUseCase;

    @Test
    void testGetCars() {
        // Arrange
        List<CarEntity> carEntities = new ArrayList<>();
        when(carRepository.findAll()).thenReturn(carEntities);

        // Act
        GetAllCarsResponse response = getCarsUseCase.getCars();

        // Assert
        // Verify that the findAll method is called
        Mockito.verify(carRepository).findAll();
        assertEquals(carEntities.size(), response.getCarList().size());
    }

    @Test
    void testGetCars_NoCarsFound() {
        // Arrange: Set up an empty list to simulate no cars in the database
        List<CarEntity> carEntities = new ArrayList<>();
        when(carRepository.findAll()).thenReturn(carEntities);

        // Act: Call the method
        GetAllCarsResponse response = getCarsUseCase.getCars();

        // Assert: Verify the findAll method was called and the response has no cars
        Mockito.verify(carRepository).findAll();
        assertEquals(0, response.getCarList().size());
    }

    @Test
    void testGetCars_ExceptionHandling() {
        // Arrange: Simulate an exception thrown by the repository (e.g., database failure)
        when(carRepository.findAll()).thenThrow(new RuntimeException("Database error"));

        // Act & Assert: Expect an exception to be thrown when calling the method
        Exception exception = null;
        try {
            getCarsUseCase.getCars();
        } catch (Exception e) {
            exception = e;
        }

        assertEquals("Database error", exception.getMessage());
    }
}
