package n2o.controller;

import n2o.business.login.LoginUseCase;
import n2o.controller.dto.LoginRequest;
import n2o.controller.dto.LoginResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

public class LoginControllerTest {

    private MockMvc mockMvc;

    @Mock
    private LoginUseCase loginUseCase;

    @InjectMocks
    private LoginController loginController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(loginController).build();
    }

    @Test
    void testLogin_Success() throws Exception {
        // Prepare mock response data
        String mockAccessToken = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJvbGl2ZXJfYWRtaW4iLCJpYXQiOjE3MzczMzIwMjQsImV4cCI6MTczNzMzMzgyNCwicm9sZXMiOlsiQURNSU4iXSwibmFtZSI6Im9saXZlcl9hZG1pbiJ9.PhUmsIBOFTKh-J1edht3MV35peA8sulnKk1fH8zHL3U";

        // Mock the loginUseCase behavior
        when(loginUseCase.login(any(LoginRequest.class))).thenReturn(new LoginResponse(mockAccessToken));

        // Perform the POST request and verify response
        mockMvc.perform(post("/tokens")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{ \"username\": \"admin\", \"password\": \"password\" }"))
                .andExpect(status().isCreated())  // Check if status is CREATED (201)
                .andExpect(jsonPath("$.accessToken").value(mockAccessToken));  // Check if the accessToken matches
    }


    @Test
    void testLogin_InvalidRequest() throws Exception {
        // Act & Assert
        mockMvc.perform(post("/tokens")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"username\": \"\", \"password\": \"\"}"))  // Invalid request
                .andExpect(status().isBadRequest());
    }
}
